import React, { useCallback, useEffect, useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { createChart, ColorType, CrosshairMode } from 'lightweight-charts';
import ReactMarkdown from 'react-markdown';
import {
  Activity, ArrowDownLeft, ArrowDownRight, ArrowRight, ArrowUpRight, BarChart3,
  Bell, BookOpen, BrainCircuit, Check, CheckCircle2, ChevronDown, ChevronRight,
  CircleHelp, Clock3, Download, ExternalLink, FileText, FlaskConical, Globe2,
  LayoutDashboard, LoaderCircle, LockKeyhole, LogOut, Menu, Plus, RefreshCw,
  Search, Settings2, ShieldCheck, Sparkles, TrendingUp, Wallet, X, Copy, Play,
} from 'lucide-react';
import './styles.css';

const ANALYSTS = [
  { key: 'market', name: 'Technical', Icon: BarChart3 },
  { key: 'news', name: 'News', Icon: Globe2 },
  { key: 'fundamentals', name: 'Fundamentals', Icon: BookOpen },
  { key: 'social', name: 'Sentiment', Icon: Activity },
];
const REPORT_NAMES = {
  market_report: 'Technical analysis', sentiment_report: 'Sentiment analysis',
  news_report: 'News & macro', fundamentals_report: 'Fundamentals',
  investment_plan: 'Research plan', research_debate: 'Research debate', risk_debate: 'Risk debate', trader_investment_plan: 'Trader proposal',
  final_trade_decision: 'Portfolio decision',
};
const NAV = [
  ['overview', 'Overview', LayoutDashboard], ['research', 'AI research', BrainCircuit],
  ['portfolio', 'Paper portfolio', Wallet], ['reports', 'Research history', FileText],
];
const money = (v, currency = 'USD') => {
  if (!Number.isFinite(Number(v)) || v === null) return '—';
  if (typeof currency !== 'string' || !/^[A-Z]{3}$/.test(currency)) return `${number(v)} ${currency || '(currency unknown)'}`;
  try { return new Intl.NumberFormat('en-US', { style: 'currency', currency, maximumFractionDigits: 2 }).format(v); }
  catch { return `${number(v)} ${currency}`; }
};
const number = (v, digits = 2) => Number.isFinite(Number(v)) && v !== null
  ? new Intl.NumberFormat('en-US', { maximumFractionDigits: digits }).format(v) : '—';
const pct = (v) => v === undefined || v === null ? '—' : `${v >= 0 ? '+' : ''}${Number(v).toFixed(2)}%`;
const today = () => new Intl.DateTimeFormat('en-CA', { timeZone: 'America/New_York', year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date());
const friendlyDate = (value) => value ? new Intl.DateTimeFormat('en-US', { month: 'short', day: 'numeric', year: 'numeric', timeZone: 'America/New_York' }).format(new Date(value.length === 10 ? `${value}T12:00:00Z` : value)) : '—';
const isBusy = (run) => ['queued', 'running'].includes(run?.status);
const dateTime = (value, timeZone = 'America/New_York') => {
  if (!value) return 'Not supplied by provider';
  if (typeof value === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(value)) return `${friendlyDate(value)} · exact time unavailable`;
  try { return new Intl.DateTimeFormat('en-US', { month: 'short', day: 'numeric', year: 'numeric', hour: 'numeric', minute: '2-digit', second: '2-digit', timeZone: timeZone || 'America/New_York', timeZoneName: 'short' }).format(new Date(value)); }
  catch { return 'Timestamp unavailable'; }
};
const sessionLabel = (market) => ({ regular: 'Regular session', pre: 'Before market open', post: 'After market close', closed: 'Market closed', unknown: 'Session unconfirmed' }[market?.session_state] || 'Session unconfirmed');
const quoteLabel = (market) => !market ? 'Provider quote' : market.mode === 'demo' ? 'Generated demo price' : market.quote_kind === 'regular_session' ? 'Latest regular-session quote' : 'Latest daily-bar price';

async function api(path, options = {}) {
  const response = await fetch(`/api${path}`, {
    credentials: 'same-origin', ...options,
    headers: { ...(options.body ? { 'Content-Type': 'application/json' } : {}), ...options.headers },
  });
  if (!response.ok) {
    let detail = `Request failed (${response.status}). Please try again.`;
    let failure = {};
    try {
      const data = await response.json(); failure = data;
      if (typeof data.detail === 'string') detail = data.detail;
      else if (Array.isArray(data.detail)) detail = data.detail.map((e) => `${e.loc?.at(-1) || 'Input'}: ${e.msg}`).join('; ');
    } catch { /* Preserve the useful HTTP status when a proxy returns HTML. */ }
    const error = new Error(detail); error.status = response.status; error.code = failure.error_code; error.action = failure.error_action; error.stage = failure.error_stage; error.retryable = failure.retryable; throw error;
  }
  return response.json();
}

function Brand({ compact = false }) {
  return <div className={`brand ${compact ? 'compact' : ''}`}><span className="brand-mark"><BarChart3 size={23} strokeWidth={2.4} /></span><div><strong>Trading<span>Agents</span></strong><small>RESEARCH DESK</small></div></div>;
}
function Spinner({ label = 'Loading' }) { return <span className="loading-inline"><LoaderCircle className="spin" size={16} />{label}</span>; }
function StatusPill({ status }) { return <span className={`status-pill ${status}`}><span />{status === 'completed' ? 'Complete' : status === 'running' ? 'Analyzing' : status === 'queued' ? 'Queued' : 'Failed'}</span>; }
function ErrorBox({ children, action, onAction }) { return <div className="error-box" role="alert"><CircleHelp size={17} /><span>{children}</span>{action && <button className="text-button" onClick={onAction}>{action}</button>}</div>; }
function Empty({ Icon = FileText, title, text, children }) { return <div className="empty-state"><div className="empty-icon"><Icon size={25} /></div><h3>{title}</h3><p>{text}</p>{children}</div>; }
function ModeBadge({ mode }) { return <span className={`mode-badge ${mode}`}>{mode === 'demo' ? <FlaskConical size={11} /> : <Globe2 size={11} />}{mode === 'demo' ? 'GENERATED DEMO' : 'REAL MARKET DATA'}</span>; }

function RequestError({ error }) {
  if (!error) return null;
  return <div className="request-error"><ErrorBox>{typeof error === 'string' ? error : error.message}</ErrorBox>{error.action && <p className="error-next-step"><strong>Next step:</strong> {error.action}</p>}{error.code && <span className="error-reference">Reference: {error.code}{error.stage ? ` · ${error.stage.replaceAll('_', ' ')}` : ''}</span>}</div>;
}

function ModelSelect({ id, label, value, onChange, options = [], disabled = false, discovery = false }) {
  const present = options.some((option) => option.id === value);
  const groups = options.reduce((all, option) => { const family = option.family || 'Other'; (all[family] ||= []).push(option); return all; }, {});
  return <div className="model-picker"><label htmlFor={id}>{label}</label><select id={id} value={value || ''} onChange={(event) => onChange(event.target.value)} disabled={disabled || !options.length}>
    <option value="">{discovery ? 'Discover available models when analysis starts' : 'Test connection to load your available models'}</option>
    {value && !present && <option value={value} disabled>{value} · not available in this model list</option>}
    {Object.entries(groups).map(([family, entries]) => <optgroup key={family} label={family}>{entries.map((option) => <option key={option.id} value={option.id}>{option.label || option.id}{option.recommended_for?.length ? ' · recommended' : ''}</option>)}</optgroup>)}
  </select><small>{value ? <code>{value}</code> : 'No model ID is assumed before account discovery.'}</small></div>;
}

function ModelAvailability({ connection }) {
  if (!connection) return null;
  return <div className="model-availability">
    {connection.requires_reverification && <p className="connection-note"><RefreshCw size={14} /><span>The model list needs refreshing. Starting analysis will recheck it automatically before any paid analysis.</span></p>}
    {connection.unavailable_requested_options?.map((item) => <p className="model-unavailable" key={item.family}><CircleHelp size={14} /><span>{item.message || `${item.label || item.family} is not listed for this API key.`}</span></p>)}
    {connection.selection_issues?.map((issue, index) => <p className="error-text" key={`${issue.role}-${index}`}>{issue.message}</p>)}
    <p className="small muted">Only analysis model IDs returned for your API key appear here. Sol and Astra are available only when your account lists them. A model-list check does not prove generation or billing access.</p>
  </div>;
}

function Login({ onLogin, required }) {
  const [password, setPassword] = useState(''); const [busy, setBusy] = useState(false); const [error, setError] = useState('');
  async function submit(e) { e.preventDefault(); setBusy(true); setError(''); try { await api('/login', { method: 'POST', body: JSON.stringify({ password }) }); setPassword(''); onLogin(); } catch (e) { setError(e.message); } finally { setBusy(false); } }
  return <div className="login-page"><div className="login-orbit orbit-one" /><div className="login-orbit orbit-two" /><div className="login-wrap"><Brand /><div className="login-card"><div className="eyebrow"><LockKeyhole size={13} /> PRIVATE WORKSPACE</div><h1>Your edge begins<br />with better research.</h1><p>A dedicated desk for market intelligence, multi-agent analysis, and thoughtful decisions.</p><form onSubmit={submit}><label htmlFor="workspace-password">Workspace password</label><input id="workspace-password" name="password" type="password" autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Enter your workspace password" required autoFocus />{error && <ErrorBox>{error}</ErrorBox>}<button className="button primary full" disabled={busy || !password}>{busy ? <Spinner label="Signing in" /> : <>Open research desk<ArrowRight size={17} /></>}</button></form><div className="login-foot"><ShieldCheck size={15} />Your password stays in your private workspace.</div></div><p className="login-note">TradingAgents research · Simulated trading · No broker connection</p></div></div>;
}

function PriceChart({ market, loading, error, period, setPeriod, onRetry }) {
  const host = useRef(null); const [hover, setHover] = useState(null);
  const savedRange = useRef(null); const rangeKey = useRef('');
  useEffect(() => {
    if (!host.current || !market?.bars?.length) return;
    setHover(null);
    const chart = createChart(host.current, {
      layout: { background: { type: ColorType.Solid, color: '#111821' }, textColor: '#7d8b9c', fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif', fontSize: 11 },
      grid: { vertLines: { color: '#1c2530' }, horzLines: { color: '#1c2530', style: 1 } },
      rightPriceScale: { borderVisible: false, scaleMargins: { top: 0.12, bottom: 0.22 } },
      timeScale: { borderVisible: false, timeVisible: false, rightOffset: 4 },
      crosshair: { mode: CrosshairMode.Normal, vertLine: { color: '#4d796a', width: 1, style: 2, labelBackgroundColor: '#274538' }, horzLine: { color: '#4d796a', labelBackgroundColor: '#274538' } },
      handleScroll: { mouseWheel: false, pressedMouseMove: true, horzTouchDrag: true, vertTouchDrag: false },
      handleScale: { mouseWheel: true, pinch: true, axisPressedMouseMove: true },
      height: 325,
    });
    const candles = chart.addCandlestickSeries({ upColor: '#50cfa1', downColor: '#e77684', borderVisible: false, wickUpColor: '#50cfa1', wickDownColor: '#e77684', priceLineColor: '#50cfa1', priceLineStyle: 2 });
    const volumes = chart.addHistogramSeries({ priceFormat: { type: 'volume' }, priceScaleId: 'volume', lastValueVisible: false, priceLineVisible: false });
    chart.priceScale('volume').applyOptions({ scaleMargins: { top: 0.87, bottom: 0.0 } });
    const bars = market.bars.map((b) => ({ ...b, time: b.date }));
    candles.setData(bars); volumes.setData(bars.map((b) => ({ time: b.time, value: b.volume, color: b.close >= b.open ? '#23453e' : '#422d39' })));
    const currentKey = `${market.mode}:${market.symbol}:${period}`;
    if (rangeKey.current === currentKey && savedRange.current) chart.timeScale().setVisibleLogicalRange(savedRange.current);
    else chart.timeScale().fitContent();
    chart.subscribeCrosshairMove((p) => { const b = p.seriesData.get(candles); setHover(b ? { ...b, date: p.time } : null); });
    const observer = new ResizeObserver((entries) => chart.applyOptions({ width: entries[0].contentRect.width })); observer.observe(host.current);
    return () => { savedRange.current = chart.timeScale().getVisibleLogicalRange(); rangeKey.current = currentKey; observer.disconnect(); chart.remove(); };
  }, [market, loading, error, period]);
  const shown = hover || market?.bars?.at(-1);
  return <section className="panel chart-panel"><div className="panel-heading"><div className="instrument-heading"><span className="ticker-avatar">{market?.symbol?.slice(0, 1) || 'T'}</span><div><h2>{market?.symbol || 'Price chart'} <span className="instrument-name">{market?.name || 'Historical price action'}</span></h2><span className="muted small">{market ? `${market.exchange || 'Market'} · ${market.currency || 'Currency unknown'} · Daily candles` : 'Choose a symbol from your watchlist'}</span></div></div><div className="range-control" aria-label="Chart time range">{[['1mo', '1M'], ['3mo', '3M'], ['6mo', '6M'], ['1y', '1Y']].map(([key, label]) => <button className={period === key ? 'selected' : ''} onClick={() => setPeriod(key)} key={key}>{label}</button>)}</div></div>
    <div className="ohlc-bar">{shown ? <><span>{hover?.date || shown.date}</span>{[['O', shown.open], ['H', shown.high], ['L', shown.low], ['C', shown.close]].map(([label, value]) => <span key={label}>{label} <b className={label === 'C' ? 'positive' : ''}>{number(value)}</b></span>)}<span className="volume-label">Vol <b>{number(shown.volume, 0)}</b></span></> : <span>Historical OHLCV</span>}</div>
    <div className="chart-frame" aria-label="Interactive price and volume chart">{loading ? <div className="chart-message"><Spinner label="Loading price history" /></div> : error ? <div className="chart-message"><ErrorBox action="Retry" onAction={onRetry}>{error}</ErrorBox><p>Prices are never replaced with demo data automatically.</p></div> : !market?.bars?.length ? <div className="chart-message">No price history available.</div> : <div ref={host} className="chart-host" />}</div>
    <div className="chart-footer"><span><span className="legend-dot" />{market?.mode === 'demo' ? 'Generated demonstration data' : market?.provider || 'Awaiting market data'}</span><span>{market?.mode === 'demo' ? 'Generated prices · Never use for trading' : `Daily historical bars · ${market?.latest_bar_date || 'Date unavailable'}`}<span className="desktop-only"> · Quote above may differ from the daily-bar close</span><a className="chart-attribution" href="https://www.tradingview.com/" target="_blank" rel="noopener noreferrer">Charts by TradingView</a></span></div>
  </section>;
}

function Watchlist({ symbols, quotes, selected, onSelect, onAdd, onRemove, loading }) {
  const [adding, setAdding] = useState(false); const [input, setInput] = useState(''); const [error, setError] = useState(''); const [busy, setBusy] = useState(false);
  async function submit(e) { e.preventDefault(); setBusy(true); setError(''); try { await onAdd(input.trim().toUpperCase()); setInput(''); setAdding(false); } catch (e) { setError(e.message); } finally { setBusy(false); } }
  return <section className="panel watchlist-panel"><div className="panel-heading"><div><h2>Watchlist <span className="count-badge">{symbols.length}</span></h2><p className="small muted">Your market, in focus</p></div><button className="icon-button" aria-label="Add symbol to watchlist" title="Add symbol" onClick={() => setAdding(!adding)}>{adding ? <X size={17} /> : <Plus size={17} />}</button></div>{adding && <form className="watchlist-add" onSubmit={submit}><label className="sr-only" htmlFor="watch-symbol">Symbol</label><input id="watch-symbol" value={input} placeholder="e.g. AAPL or BTC-USD" maxLength={20} onChange={(e) => setInput(e.target.value.toUpperCase())} autoFocus /><button className="button primary compact-button" disabled={busy || !input}>{busy ? <LoaderCircle size={15} className="spin" /> : <Plus size={16} />}</button>{error && <p role="alert" className="error-text">{error}</p>}</form>}<div className="watchlist-table"><div className="watchlist-columns"><span>ASSET</span><span>PRICE / CHANGE</span></div>{symbols.map((symbol, i) => { const quote = quotes[symbol]; return <div className={`watch-row ${selected === symbol ? 'active' : ''}`} key={symbol}><button className="watch-select" onClick={() => onSelect(symbol)} aria-label={`View ${symbol}`}><span className={`asset-dot asset-${i % 5}`}>{symbol.slice(0, 1)}</span><span className="watch-name"><strong>{symbol}</strong><small>{quote?.name || (quote?.error ? 'Quote unavailable' : 'Loading quote…')}</small></span><span className="watch-price"><strong>{quote?.error ? '—' : money(quote?.price, quote?.currency)}</strong><small className={quote?.change_percent >= 0 ? 'positive' : 'negative'}>{pct(quote?.change_percent)}</small></span></button><button className="watch-remove" aria-label={`Remove ${symbol} from watchlist`} onClick={() => onRemove(symbol)}><X size={12} /></button></div>; })}{loading && !symbols.length ? <div className="padded"><Spinner label="Loading watchlist" /></div> : !symbols.length && <div className="padded muted small">Add a symbol to begin your watchlist.</div>}</div><div className="watchlist-note"><ShieldCheck size={14} />Independent research. Your decisions.</div></section>;
}

function AnalysisForm({ symbol, mode, status, onRun, busy, onSettings, onStatusRefresh }) {
  const [date, setDate] = useState(today());
  const [analysts, setAnalysts] = useState(['market']);
  const [rounds, setRounds] = useState(1);
  const [quick, setQuick] = useState(status?.quick_model || '');
  const [deep, setDeep] = useState(status?.deep_model || '');
  const [error, setError] = useState(null);
  const [checking, setChecking] = useState(false); const [checkResult, setCheckResult] = useState(null);
  useEffect(() => { setQuick(status?.quick_model || ''); setDeep(status?.deep_model || ''); setCheckResult(null); }, [status?.quick_model, status?.deep_model]);
  useEffect(() => { setError(null); setCheckResult(null); }, [symbol, mode, date, quick, deep, analysts, rounds]);
  const options = status?.model_options || [];
  const keyReady = Boolean(status?.ai_available || status?.live_available);
  const knownInvalid = options.length > 0 && (!options.some((item) => item.id === quick) || !options.some((item) => item.id === deep));
  const canAttempt = mode === 'demo' || (keyReady && !knownInvalid && (options.length > 0 || status?.can_attempt_analysis === true));
  const inputs = () => ({ symbol, date, analysts, mode, ...(quick ? { quick_model: quick } : {}), ...(deep ? { deep_model: deep } : {}), rounds: Number(rounds) });
  async function submit(event) { event.preventDefault(); setError(null); try { await onRun(inputs()); } catch (failure) { setError(failure); } }
  async function check() {
    setChecking(true); setError(null); setCheckResult(null);
    try { const result = await api('/analysis/check', { method: 'POST', body: JSON.stringify(inputs()) }); await onStatusRefresh(); setCheckResult(result); }
    catch (failure) { setError(failure); }
    finally { setChecking(false); }
  }
  function toggle(key) { setAnalysts((old) => old.includes(key) ? old.filter((item) => item !== key) : [...old, key]); }
  return <section className="panel analysis-form-panel"><div className="panel-heading"><div className="heading-with-icon"><span className="subtle-icon"><BrainCircuit size={20} /></span><div><h2>Let the team do the research</h2><p className="small muted">Multiple perspectives. One informed decision.</p></div></div><span className="tag">MULTI-AGENT</span></div>
    <form onSubmit={submit}><div className="analysis-inputs"><div><label>Research symbol</label><div className="static-input"><Search size={15} /><strong>{symbol}</strong><span className="muted">Selected asset</span></div></div><div><label htmlFor="analysis-date">Analysis date</label><input type="date" id="analysis-date" value={date} max={today()} onChange={(event) => setDate(event.target.value)} required /></div></div>
      <label className="analyst-label">Build your analyst team</label><p className="small muted analyst-data-note">Technical uses market history. News and sentiment need available feeds; US fundamentals need your SEC contact.</p>
      <div className="analyst-choices">{ANALYSTS.map(({ key, name, Icon }) => <button type="button" aria-pressed={analysts.includes(key)} className={`analyst-choice ${analysts.includes(key) ? 'selected' : ''}`} onClick={() => toggle(key)} key={key}><Icon size={17} /><span>{name}</span><span className="check-box">{analysts.includes(key) && <Check size={10} strokeWidth={3} />}</span></button>)}</div>
      {mode === 'live' && <div className="analysis-model-selection"><div className="model-section-heading"><strong>Your analysis models</strong><button type="button" className="text-button" onClick={onSettings}>Manage models<ArrowRight size={13} /></button></div><div className="connection-models"><ModelSelect id="quick-model" label="Analyst model" value={quick} onChange={setQuick} options={options} disabled={busy} discovery={keyReady && !status?.ai_verified} /><ModelSelect id="deep-model" label="Decision model" value={deep} onChange={setDeep} options={options} disabled={busy} discovery={keyReady && !status?.ai_verified} /></div><ModelAvailability connection={status} /></div>}
      <details className="advanced-settings"><summary><Settings2 size={14} /> Research depth<ChevronDown size={13} /></summary><div className="advanced-grid"><div><label htmlFor="research-depth">Debate rounds</label><select id="research-depth" value={rounds} onChange={(event) => setRounds(event.target.value)}><option value="1">1 · Focused</option><option value="2">2 · Balanced</option><option value="3">3 · Extended</option></select></div><p className="small muted model-hint">More rounds use more API requests. Real analysis incurs OpenAI API charges.</p></div></details>
      <RequestError error={error} />
      {mode === 'live' && !keyReady && <div className="connection-note"><LockKeyhole size={14} /><span>Add your API key in Connections & settings to run the real team.</span><button className="text-button" type="button" onClick={onSettings}>Connect OpenAI<ArrowRight size={13} /></button></div>}
      {mode === 'live' && keyReady && knownInvalid && <div className="connection-note"><CircleHelp size={14} /><span>Choose two models from your account list, or use the recommended models in settings.</span><button className="text-button" type="button" onClick={onSettings}>Choose models<ArrowRight size={13} /></button></div>}
      {mode === 'live' && keyReady && !canAttempt && !knownInvalid && <div className="connection-note"><CircleHelp size={14} /><span>No usable analysis models have been discovered for this key yet.</span><button className="text-button" type="button" onClick={onSettings}>Check model access<ArrowRight size={13} /></button></div>}
      {checkResult?.ready && <div className="success-box" role="status"><CheckCircle2 size={15} /><span>Free readiness checks passed. Actual model generation is a separate paid request.</span></div>}
      <div className="analysis-bottom"><span className="small muted"><ShieldCheck size={14} />{mode === 'demo' ? 'Generated example · Never a real trade signal' : 'Your explicit run uses billable OpenAI API requests'}</span><div className="analysis-actions">{mode === 'live' && <button className="button secondary" type="button" disabled={busy || checking || !analysts.length || !canAttempt} onClick={check}>{checking ? <Spinner label="Checking" /> : <>Check readiness<CheckCircle2 size={15} /></>}</button>}<button className="button primary" disabled={busy || checking || !analysts.length || !canAttempt}>{busy ? <Spinner label="Research in progress" /> : <><Sparkles size={16} />{mode === 'demo' ? 'Run demo analysis' : 'Run AI analysis'}<ArrowRight size={15} /></>}</button></div></div>
    </form></section>;
}

function TradeTicket({ symbol, market, portfolio, mode, onOrder }) {
  const [side, setSide] = useState('buy'); const [quantity, setQuantity] = useState('1'); const [error, setError] = useState(''); const [success, setSuccess] = useState(''); const [busy, setBusy] = useState(false);
  const quantityNumber = Number(quantity); const total = market?.price * quantityNumber;
  const held = portfolio?.positions?.find((p) => p.symbol === symbol)?.quantity || 0;
  const tradable = market?.currency === 'USD';
  useEffect(() => { setError(''); setSuccess(''); }, [symbol, mode]);
  async function submit(e) { e.preventDefault(); setBusy(true); setError(''); setSuccess(''); try { const r = await onOrder({ symbol, side, quantity: quantityNumber, mode }); setSuccess(`Simulated ${side}: ${number(r.order.quantity, 6)} ${symbol} at ${money(r.order.price, market?.currency)}.`); } catch (e) { setError(e.message); } finally { setBusy(false); } }
  return <section className="panel ticket-panel"><div className="panel-heading"><h2>Paper trade</h2><span className="paper-tag"><FlaskConical size={12} /> SIMULATED</span></div><form onSubmit={submit}><div className="trade-side"><button type="button" className={side === 'buy' ? 'selected buy' : ''} onClick={() => { setSide('buy'); setSuccess(''); }}>Buy</button><button type="button" className={side === 'sell' ? 'selected sell' : ''} onClick={() => { setSide('sell'); setSuccess(''); }}>Sell</button></div><div className="ticket-instrument"><strong>{symbol}</strong><span>{money(market?.price, market?.currency)}</span></div><label htmlFor="trade-quantity">Quantity <span>{number(held, 6)} held</span></label><div className="quantity-control"><button type="button" aria-label="Decrease quantity" onClick={() => setQuantity(String(Math.max(1, quantityNumber - 1)))}>−</button><input id="trade-quantity" type="number" min="0.000001" max="1000000" step="any" value={quantity} onChange={(e) => setQuantity(e.target.value)} required /><button type="button" aria-label="Increase quantity" onClick={() => setQuantity(String(quantityNumber + 1))}>+</button></div><div className="ticket-estimate"><span>Estimated {side === 'buy' ? 'cost' : 'proceeds'}</span><strong>{market ? money(total, market.currency) : '—'}</strong></div><div className="buying-power"><span>{side === 'buy' ? 'Buying power' : 'Shares available'}</span><span>{side === 'buy' ? money(portfolio?.buying_power) : number(held, 6)}</span></div>{error && <ErrorBox>{error}</ErrorBox>}{success && <div className="success-box" role="status"><CheckCircle2 size={16} />{success}</div>}<button className={`button full ${side === 'buy' ? 'primary' : 'sell-button'}`} disabled={busy || !market || !tradable || quantityNumber <= 0 || !Number.isFinite(quantityNumber)}>{busy ? <Spinner label="Placing simulated order" /> : <>{side === 'buy' ? <ArrowUpRight size={17} /> : <ArrowDownRight size={17} />}Simulate {side} order</>}</button><p className="ticket-disclaimer">{market && !tradable && <><strong>USD instruments only. This symbol cannot be paper traded.</strong><br /></>}{mode === 'demo' ? 'Generated demonstration prices.' : `${quoteLabel(market)}.`} No fees or slippage. No real money or broker orders.</p></form></section>;
}

function SourceCoverage({ coverage }) {
  const names = { get_stock_data: 'Market history', get_indicators: 'Technical indicators', get_verified_market_snapshot: 'Market snapshot', get_fundamentals: 'Company fundamentals', get_balance_sheet: 'Balance sheet', get_cashflow: 'Cash flow', get_income_statement: 'Income statement', get_news: 'Company news', get_global_news: 'Global news', get_insider_transactions: 'Insider transactions', get_macro_indicators: 'Macro indicators', get_prediction_markets: 'Prediction markets', unrecognized_tool: 'Unrecognized data tool' };
  const label = (tool) => names[tool] || 'Unrecognized data tool';
  if (!coverage) return <div className="source-coverage coverage-incomplete" role="note"><strong>Source coverage is unverified</strong><p>This saved report has no data-tool availability record. A completed report does not prove its data sources were available.</p></div>;
  const incomplete = coverage.summary_status === 'incomplete';
  return <section className={`source-coverage ${incomplete ? 'coverage-incomplete' : ''}`} aria-label="Report source availability"><strong>{incomplete ? 'Source availability needs review' : 'Data-tool output observed · Accuracy not independently verified'}</strong>
    {coverage.unavailable_tools?.length > 0 && <p>Unavailable or error results: {coverage.unavailable_tools.map(label).join(', ')}.</p>}
    {coverage.empty_output_tools?.length > 0 && <p>No visible output: {coverage.empty_output_tools.map(label).join(', ')}.</p>}
    {coverage.no_tools_warning && <p>No data-tool results were captured. Retrieval of the selected sources is not established.</p>}
    {coverage.unobserved_analysts?.length > 0 && <p>No corresponding data-tool result for: {coverage.unobserved_analysts.map((a) => ANALYSTS.find((item) => item.key === a)?.name || a).join(', ')}.</p>}
    <details><summary>Data availability and limitations</summary>{coverage.attempted_tools?.length > 0 && <p>Observed calls: {coverage.attempted_tools.map(label).join(', ')}.</p>}<ul>{(coverage.limitations || []).map((item, i) => <li key={i}>{item}</li>)}</ul></details>
  </section>;
}

function RunResult({ run, onRetry, onSettings, busy }) {
  const [diagnosticNotice, setDiagnosticNotice] = useState('');
  const [retryError, setRetryError] = useState(null);
  useEffect(() => { setDiagnosticNotice(''); setRetryError(null); }, [run?.id]);
  async function copyDiagnostics() { try { const data = await api(`/runs/${run.id}/diagnostics`); await navigator.clipboard.writeText(JSON.stringify(data, null, 2)); setDiagnosticNotice('Safe diagnostics copied. The file contains no API key or raw provider response.'); } catch { setDiagnosticNotice('Clipboard unavailable. Use Download diagnostics below.'); } }
  async function retry() { setRetryError(null); try { await onRetry(run); } catch (failure) { setRetryError(failure); } }
  const keys = Object.keys(REPORT_NAMES).filter((key) => run?.reports?.[key]); const [section, setSection] = useState('final_trade_decision');
  useEffect(() => { setSection(run?.reports?.final_trade_decision ? 'final_trade_decision' : Object.keys(REPORT_NAMES).find((key) => run?.reports?.[key]) || 'final_trade_decision'); }, [run?.id, run?.status]);
  if (!run) return <section className="panel result-panel"><Empty Icon={BrainCircuit} title="A research team, on your side" text="Start an analysis to see the technical view, investment debate, and portfolio decision in one place."><div className="agent-preview"><span><BarChart3 size={16} />Analysts</span><ChevronRight size={14} /><span><BrainCircuit size={16} />Research</span><ChevronRight size={14} /><span><ShieldCheck size={16} />Risk review</span></div></Empty></section>;
  return <section className="panel result-panel"><div className="panel-heading"><div><h2>{run.symbol} <span className="muted">research brief</span></h2><p className="small muted">As of {friendlyDate(run.date)} · {run.analysts?.length || 1} analyst{run.analysts?.length > 1 ? 's' : ''}</p></div><div className="heading-actions"><ModeBadge mode={run.mode} /><StatusPill status={run.status} />{run.status === 'completed' && <a className="icon-button" href={`/api/runs/${run.id}/report`} title="Download research report" aria-label="Download research report"><Download size={16} /></a>}</div></div>{run.mode === 'live' && <div className="report-provenance"><span><strong>{run.status === 'completed' ? 'Generated:' : 'Started:'}</strong> {dateTime(run.status === 'completed' ? run.provenance?.generated_at || run.updated_at : run.provenance?.started_at || run.created_at)}</span><span><strong>Models:</strong> {run.provenance?.quick_model || run.quick_model || 'Not recorded'} / {run.provenance?.deep_model || run.deep_model || 'Not recorded'}</span><span><strong>Analysis date:</strong> {friendlyDate(run.date)} · Quote time and report time are different.</span>{run.data_snapshot && <span><strong>Run-start quote:</strong> {money(run.data_snapshot.price, run.data_snapshot.currency)} · {run.data_snapshot.provider || run.data_snapshot.source} · {dateTime(run.data_snapshot.quote_as_of || run.data_snapshot.quote_date)}</span>}<p>{run.provenance?.source_coverage_note || 'AI output reflects the sources available during this run. Review source dates and any missing-data statements before acting.'} An older saved report does not update with the market.</p></div>}{run.mode === 'live' && run.status === 'completed' && <SourceCoverage coverage={run.source_coverage} />}{run.mode === 'demo' && <div className="illustrative-note"><FlaskConical size={15} />Illustrative demo report. This is not an AI run or an investment recommendation.</div>}{isBusy(run) ? <div className="research-progress"><div className="research-pulse"><BrainCircuit size={28} /></div><h3>{run.status === 'queued' ? 'Your team is getting ready' : 'Your research team is at work'}</h3><p>{run.progress || 'Gathering evidence and considering different perspectives.'}</p><div className="progress-track"><span /></div><span className="small muted">You can explore your workspace while the analysis runs.</span></div> : run.status === 'failed' ? <div className="padded failed-run-details"><ErrorBox>{run.error || 'The analysis could not be completed.'}</ErrorBox><p className="error-next-step"><strong>Next step:</strong> {run.error_action || 'Open connection settings to check your models and provider access, then try again.'}</p><dl className="failure-reference"><div><dt>Reference</dt><dd>{run.error_code || 'analysis_failed'}</dd></div><div><dt>Stage</dt><dd>{(run.error_stage || 'analysis').replaceAll('_', ' ')}</dd></div></dl><div className="failure-actions"><button className="button secondary" onClick={onSettings}>Connection & model settings<Settings2 size={14} /></button>{/quota|billing|credit|payment/.test(run.error_code || '') && <a className="button secondary" href="https://platform.openai.com/settings/organization/billing/overview" target="_blank" rel="noopener noreferrer">Open API billing<ExternalLink size={14} /></a>}<button className="button primary" disabled={busy} onClick={retry}>{busy ? <Spinner label="Starting" /> : <>Retry with saved models<RefreshCw size={14} /></>}</button></div><p className="small muted">Fix the cause first. Retrying is your choice and can incur API charges; the app never retries paid analyses automatically.</p><RequestError error={retryError} /><div className="diagnostic-actions"><button className="text-button" onClick={copyDiagnostics}><Copy size={14} />Copy safe diagnostics</button><a className="text-button" href={`/api/runs/${run.id}/diagnostics`} download><Download size={14} />Download diagnostics</a></div>{diagnosticNotice && <p className="small muted" role="status">{diagnosticNotice}</p>}</div> : <>{run.rating && <div className="decision-line"><span className="small muted">PORTFOLIO VIEW</span><span className={`rating ${(run.rating || '').toLowerCase()}`}>{run.rating}</span><span className="small muted">{run.mode === 'demo' ? 'Illustrative example only' : 'AI-generated · Review the reasoning'}</span></div>}<div className="report-tabs" role="tablist" aria-label="Research report sections">{keys.map((key) => <button role="tab" aria-selected={section === key} className={section === key ? 'selected' : ''} onClick={() => setSection(key)} key={key}>{REPORT_NAMES[key]}</button>)}</div><div className="markdown report-content"><ReactMarkdown components={{ img: ({ alt }) => <span className="muted">[Image omitted{alt ? `: ${alt}` : ''}]</span>, a: ({ children, href }) => <a href={href} target="_blank" rel="noopener noreferrer">{children}</a> }}>{run.reports?.[section] || 'No report was produced for this section.'}</ReactMarkdown></div></>}</section>;
}

function Portfolio({ portfolio, error, loading, mode, onSelect }) {
  return <><div className="section-title"><div><div className="eyebrow">PRACTICE WITH PURPOSE</div><h1>Your paper portfolio</h1><p>Build conviction before you commit capital.</p></div><ModeBadge mode={mode} /></div><div className="metrics-grid"><Metric label="Portfolio value" value={money(portfolio?.equity)} icon={Wallet} foot={`Starting balance ${money(portfolio?.initial_cash)}`} /><Metric label="Cash available" value={money(portfolio?.cash)} icon={Wallet} foot="No leverage or margin" /><Metric label="Unrealized P&L" value={money(portfolio?.unrealized_pnl)} icon={TrendingUp} positive={portfolio?.unrealized_pnl >= 0} foot="Open paper positions" /><Metric label="Realized P&L" value={money(portfolio?.realized_pnl)} icon={CheckCircle2} positive={portfolio?.realized_pnl >= 0} foot="Closed paper positions" /></div>{error && <ErrorBox>{error}</ErrorBox>}{portfolio?.quote_errors?.length > 0 && <ErrorBox>Some position quotes are unavailable. Unavailable valuations are omitted; total equity is unavailable until quotes return. {portfolio.quote_errors.join(' ')}</ErrorBox>}<section className="panel"><div className="panel-heading"><h2>Your positions <span className="count-badge">{portfolio?.positions?.length || 0}</span></h2><span className="small muted">Long positions only</span></div>{portfolio?.positions?.length ? <div className="table-scroll"><table><thead><tr><th>ASSET</th><th>SHARES</th><th>AVG. COST</th><th>REFERENCE PRICE</th><th>MARKET VALUE</th><th>UNREALIZED P&L</th><th /></tr></thead><tbody>{portfolio.positions.map((p) => <tr key={p.symbol}><td><strong>{p.symbol}</strong><small>{dateTime(p.as_of)}</small></td><td>{number(p.quantity, 6)}</td><td>{money(p.average_price)}</td><td>{money(p.price)}</td><td>{money(p.market_value)}</td><td className={p.unrealized_pnl >= 0 ? 'positive' : 'negative'}>{money(p.unrealized_pnl)}</td><td><button className="text-button" onClick={() => onSelect(p.symbol)}>View<ArrowRight size={13} /></button></td></tr>)}</tbody></table></div> : <Empty Icon={Wallet} title={loading ? 'Loading your portfolio' : 'Your next idea starts here'} text="Place a simulated order from the overview to open your first paper position. This balance is virtual money." />}</section><section className="panel orders-panel"><div className="panel-heading"><h2>Order activity</h2><span className="paper-tag">SIMULATED FILLS</span></div>{portfolio?.orders?.length ? <div className="table-scroll"><table><thead><tr><th>TIME</th><th>ASSET</th><th>SIDE</th><th>QUANTITY</th><th>FILL PRICE</th><th>TOTAL</th></tr></thead><tbody>{portfolio.orders.map((o) => <tr key={o.id}><td>{friendlyDate(o.created_at)}</td><td><strong>{o.symbol}</strong></td><td><span className={`side-badge ${o.side}`}>{o.side}</span></td><td>{number(o.quantity, 6)}</td><td>{money(o.price)}</td><td>{money(o.total)}</td></tr>)}</tbody></table></div> : <div className="padded muted small">Your simulated orders will appear here. No broker connection is active.</div>}</section></>;
}
function Metric({ label, value, foot, icon: Icon, positive, children }) { return <div className="metric"><div className="metric-top"><span>{label}</span><Icon size={17} /></div><strong className={positive === undefined ? '' : positive ? 'positive' : 'negative'}>{value}</strong><div className="metric-foot">{children || foot}</div></div>; }
function History({ runs, mode, onView }) { const visible = runs.filter((r) => r.mode === mode); return <section className="panel"><div className="panel-heading"><div><h2>Research history</h2><p className="small muted">Your decisions deserve a paper trail.</p></div><ModeBadge mode={mode} /></div>{visible.length ? <div className="table-scroll"><table><thead><tr><th>ASSET</th><th>ANALYSIS DATE</th><th>TEAM</th><th>STATUS</th><th>VIEW</th><th /></tr></thead><tbody>{visible.map((run) => <tr key={run.id}><td><strong>{run.symbol}</strong></td><td>{friendlyDate(run.date)}</td><td>{run.analysts?.map((a) => ANALYSTS.find((x) => x.key === a)?.name || a).join(', ') || 'Technical'}</td><td><StatusPill status={run.status} /></td><td><span className={`rating small-rating ${(run.rating || '').toLowerCase()}`}>{run.rating || '—'}</span></td><td><div className="table-actions"><button className="text-button" onClick={() => onView(run)}>Open<ArrowRight size={13} /></button>{run.status === 'completed' && <a href={`/api/runs/${run.id}/report`} className="icon-button" aria-label={`Download ${run.symbol} report`}><Download size={14} /></a>}</div></td></tr>)}</tbody></table></div> : <Empty title="Every insight, in one place" text="Run an analysis to start your research history. Reports are saved in your private workspace." />}</section>; }

function Settings({ status, onRefresh }) {
  const [connection, setConnection] = useState(null); const [key, setKey] = useState('');
  const [quick, setQuick] = useState(''); const [deep, setDeep] = useState(''); const [modelsDirty, setModelsDirty] = useState(false);
  const [contact, setContact] = useState(''); const [busy, setBusy] = useState(''); const [error, setError] = useState(null); const [message, setMessage] = useState('');
  const [probe, setProbe] = useState(null);
  function applyConnection(data) { setConnection(data); setQuick(data.quick_model || ''); setDeep(data.deep_model || ''); setContact(data.sec_edgar_user_agent || ''); setProbe(data.execution_test || null); }
  const load = useCallback(async () => { try { applyConnection(await api('/connections')); } catch (failure) { setError(failure); } }, []);
  useEffect(() => { load(); }, [load]);
  async function test() { setBusy('test'); setError(null); setMessage(''); try { const data = await api('/connections/test', { method: 'POST' }); applyConnection(data); setMessage(data.message); await onRefresh(); } catch (failure) { setError(failure); } finally { setBusy(''); } }
  async function save(event) {
    event.preventDefault(); setBusy('save'); setError(null); setMessage(''); setProbe(null);
    try {
      const body = { sec_edgar_user_agent: contact };
      if (modelsDirty) { body.quick_model = quick || null; body.deep_model = deep || null; }
      if (key.trim()) body.openai_api_key = key.trim();
      let data = await api('/connections', { method: 'PUT', body: JSON.stringify(body) });
      setKey(''); applyConnection(data);
      if (data.key_configured) data = await api('/connections/test', { method: 'POST' });
      applyConnection(data); setMessage(data.message || 'Settings saved.'); setModelsDirty(false); await onRefresh();
    } catch (failure) { setError(failure); } finally { setBusy(''); }
  }
  async function recommend() { setBusy('recommend'); setError(null); setMessage(''); setProbe(null); try { const data = await api('/connections/recommendations', { method: 'POST' }); applyConnection(data); setModelsDirty(false); setMessage('Recommended models saved from the models available to your API key.'); await onRefresh(); } catch (failure) { setError(failure); } finally { setBusy(''); } }
  async function testExecution() { setBusy('probe'); setError(null); setProbe(null); try { setProbe(await api('/connections/probe', { method: 'POST' })); await onRefresh(); } catch (failure) { setError(failure); } finally { setBusy(''); } }
  async function clearKey() { setBusy('clear'); setError(null); setMessage(''); setProbe(null); try { applyConnection(await api('/connections/key', { method: 'DELETE' })); setKey(''); setMessage('Saved local key removed.'); await onRefresh(); } catch (failure) { setError(failure); } finally { setBusy(''); } }
  const listChecked = Boolean(connection?.verified); const selectedValid = Boolean(connection?.model_selection_validated);
  const pendingModelChanges = modelsDirty || Boolean(key.trim());
  const pendingContactChange = contact !== (connection?.sec_edgar_user_agent || '');
  const canProbe = Boolean(connection?.key_configured && (selectedValid || connection?.can_attempt_analysis));
  return <><div className="section-title"><div><div className="eyebrow">REAL DATA, YOUR RESEARCH TEAM</div><h1>Connections & settings</h1><p>Choose capable models your API account actually offers, then check the execution path when needed.</p></div></div>
    <div className="settings-grid"><section className="panel"><div className="panel-heading"><h2>OpenAI connection</h2><span className={`status-pill ${listChecked && selectedValid ? 'completed' : 'queued'}`}><span />{listChecked && selectedValid ? 'Model list checked' : connection?.key_configured ? 'Key saved' : 'Key needed for AI'}</span></div>
      <div className="settings-body"><p>API usage is billed separately from ChatGPT. A saved key or model-list check does not prove that paid generation is enabled.</p><div className="connection-help-links"><a className="text-button" href="https://platform.openai.com/api-keys" target="_blank" rel="noopener noreferrer">Manage API keys<ExternalLink size={13} /></a><a className="text-button" href="https://platform.openai.com/settings/organization/billing/overview" target="_blank" rel="noopener noreferrer">API billing<ExternalLink size={13} /></a></div>
      {!connection && !error ? <Spinner label="Loading connection settings" /> : <form className="provider-form" onSubmit={save}>
        <label htmlFor="provider-key">OpenAI API key {connection?.key_configured && <span className="positive small">Saved · never displayed</span>}</label>
        <input id="provider-key" type="password" autoComplete="off" spellCheck="false" value={key} onChange={(event) => { setKey(event.target.value); setProbe(null); }} placeholder={connection?.key_configured ? 'Enter a new key only to replace your saved key' : 'Paste your key here on your own computer'} disabled={connection?.key_editable === false || Boolean(busy)} />
        <p className="small muted">{connection?.key_source === 'environment' ? 'This key is supplied by your system or host. Change it there.' : connection?.key_storage === 'windows_dpapi' ? 'Your saved key is encrypted for your Windows account and never included in report downloads.' : 'The key stays in this local workspace and is never returned by the API or included in reports.'}</p>
        <div className="model-section-heading"><strong>Account-available analysis models</strong><button className="text-button" type="button" disabled={Boolean(busy) || !connection?.key_configured || Boolean(key.trim()) || pendingContactChange} onClick={recommend}>{busy === 'recommend' ? <Spinner label="Finding models" /> : <>Use recommended models<Sparkles size={14} /></>}</button></div>
        <div className="connection-models"><ModelSelect id="connection-quick-model" label="Analyst model" value={quick} onChange={(value) => { setQuick(value); setModelsDirty(true); setProbe(null); }} options={connection?.model_options} disabled={Boolean(busy)} /><ModelSelect id="connection-deep-model" label="Decision model" value={deep} onChange={(value) => { setDeep(value); setModelsDirty(true); setProbe(null); }} options={connection?.model_options} disabled={Boolean(busy)} /></div>
        <ModelAvailability connection={connection} />
        <label htmlFor="sec-contact">SEC contact (for US company fundamentals)</label><input id="sec-contact" value={contact} onChange={(event) => setContact(event.target.value)} placeholder="Your name your@email.com" maxLength={200} />
        <p className="small muted">Leave this blank for technical-only analysis. SEC filings need your real contact details.</p>
        <RequestError error={error} />{message && <div className={connection?.verified ? 'success-box' : 'connection-note'} role="status"><CircleHelp size={15} /><span>{message}</span></div>}
        <div className="connection-actions"><button className="button primary" disabled={Boolean(busy)}>{busy === 'save' ? <Spinner label="Saving and checking" /> : <><CheckCircle2 size={15} />Save & test connection</>}</button><button className="button secondary" type="button" disabled={Boolean(busy) || !connection?.key_configured || pendingModelChanges || pendingContactChange} onClick={test}>{busy === 'test' ? <Spinner label="Checking model list" /> : <><RefreshCw size={15} />Refresh model list</>}</button></div>
        {connection?.key_source === 'local_saved' && <button className="text-button danger-text" type="button" disabled={Boolean(busy)} onClick={clearKey}>Remove saved local key</button>}
        {connection?.verified_at && <p className="small muted">Last model-list check: {dateTime(connection.verified_at)}. An expired list refreshes automatically when you start analysis.</p>}
      </form>}</div></section>
      <section className="panel"><div className="panel-heading"><h2>Test the actual AI path</h2><span className="tag">OPTIONAL · PAID REQUESTS</span></div><div className="settings-body"><Brand compact /><p>This optional test sends small generation requests using your saved analyst and decision models. It checks tool calling and structured output, which a model-list request cannot check.</p>
        <button className="button secondary" type="button" disabled={Boolean(busy) || !connection?.key_configured || pendingModelChanges || !canProbe} onClick={testExecution}>{busy === 'probe' ? <Spinner label="Testing model execution" /> : <><Play size={15} />Test AI execution (API charges apply)</>}</button>
        {pendingModelChanges && <p className="small muted">Save your key and model changes before testing execution.</p>}
        <p className="small muted">Only runs when you click. A failed provider request may still incur charges. This is a short compatibility check, not a complete research analysis.</p>
        {probe && <div className={`execution-probe ${probe.success ? 'passed' : 'failed'}`} role="status"><h3>{probe.success ? 'Small execution checks passed' : 'Execution check needs attention'}</h3><p>{probe.message}</p><span className="small muted">Checked {dateTime(probe.tested_at)} · {probe.request_count ?? 'Recorded'} request(s)</span>{probe.results?.map((result) => <div className={`probe-role ${result.status}`} key={result.role}><div><strong>{result.role === 'quick' ? 'Analyst model' : 'Decision model'}</strong><code>{result.model}</code><span>{result.status}</span></div><p>{result.message}</p>{result.error_action && <p className="error-next-step"><strong>Next step:</strong> {result.error_action}</p>}{result.error_code && <span className="error-reference">Reference: {result.error_code}</span>}</div>)}</div>}
        <dl className="settings-list"><div><dt>Dashboard version</dt><dd>{status.app_version || '1.2.0'}</dd></div><div><dt>Framework version</dt><dd>{status.version || '—'}</dd></div><div><dt>Broker connection</dt><dd>None · You place your own trades</dd></div></dl><p>Check market-data timestamps before running your research. Execution-test success does not verify Yahoo feeds or every analyst source.</p>
      </div></section></div>
      <section className="panel"><div className="panel-heading"><h2>Understand each check</h2><ShieldCheck size={18} className="positive" /></div><div className="settings-body privacy-grid"><div><h3>Key and model list</h3><p>A free model-list check identifies the IDs available to your account. Sol and Astra appear only if returned for your key.</p></div><div><h3>Actual generation</h3><p>The optional paid test checks a small tool-call and structured-output request. Full research is a separate, larger run.</p></div><div><h3>Your research run</h3><p>If a run fails, its error code, next action and safe diagnostics remain available. Paid research is never retried automatically.</p></div></div></section></>;
}

function QuoteProvenance({ market, mode, loading, onRefresh }) {
  const caution = Boolean(market && (market.stale || ['old_quote', 'clock_warning', 'timestamp_unavailable'].includes(market.freshness)));
  if (mode === 'demo') return <div className="demo-explanation"><FlaskConical size={18} /><div><strong>Generated demonstration data</strong><p>These prices are fictional, even when the chart date is today. Switch to real market data before researching an actual trade.</p></div></div>;
  return <section className={`quote-provenance ${caution ? 'quote-stale' : ''}`} aria-label="Market data provenance"><div className="quote-source-title"><Globe2 size={17} /><strong>{market?.provider || 'Yahoo Finance'}</strong><span className="quote-state">{market ? sessionLabel(market) : 'Waiting for a verified provider response'}</span><button className="button secondary compact-button" onClick={onRefresh} disabled={loading}>{loading ? <Spinner label="Refreshing" /> : <><RefreshCw size={14} />Refresh prices</>}</button></div><div className="quote-provenance-grid"><div><span>Provider quote timestamp</span><strong>{market ? dateTime(market.quote_as_of || market.as_of, market.exchange_timezone) : 'No current quote available'}</strong></div><div><span>Retrieved from source</span><strong>{market?.fetched_at ? dateTime(market.fetched_at) : 'Not retrieved'}</strong></div><div><span>Last completed daily bar</span><strong>{market?.last_completed_session_date ? `${friendlyDate(market.last_completed_session_date)} · ${money(market.last_completed_close, market.currency)}` : 'Not confirmed by provider'}</strong></div></div><p className="small muted">{market?.freshness_note || 'Only real provider responses appear here. A missing response is never replaced with generated prices.'} Auto-refresh every 60 seconds while this tab is visible.</p>{caution && <div className="quote-warning" role="alert">{market.stale ? 'This provider quote is older than expected for the current session.' : 'The freshness of this provider quote cannot be confirmed.'} Verify the timestamp and your broker quote before using it.</div>}</section>;
}

function App() {
  const [status, setStatus] = useState(null); const [initialError, setInitialError] = useState(''); const [nav, setNav] = useState('overview'); const [mobileNav, setMobileNav] = useState(false);
  const [mode, setMode] = useState(() => { try { return localStorage.getItem('tradingagents-mode-v2') === 'demo' ? 'demo' : 'live'; } catch { return 'live'; } });
  const modeRef = useRef(mode); modeRef.current = mode;
  const portfolioGeneration = useRef(0);
  const [symbol, setSymbol] = useState('NVDA'); const [search, setSearch] = useState(''); const [period, setPeriod] = useState('3mo');
  const [marketData, setMarket] = useState(null); const [marketError, setMarketError] = useState(''); const [marketLoading, setMarketLoading] = useState(true); const [marketRefresh, setMarketRefresh] = useState(0);
  const [marketRefreshing, setMarketRefreshing] = useState(false); const marketQuery = useRef('');
  const [watchlist, setWatchlist] = useState([]); const [quotes, setQuotes] = useState({}); const [watchLoading, setWatchLoading] = useState(true);
  const [portfolioData, setPortfolio] = useState(null); const [portfolioError, setPortfolioError] = useState(''); const [portfolioLoading, setPortfolioLoading] = useState(false);
  const [runs, setRuns] = useState([]); const [activeRun, setActiveRun] = useState(null); const [runSubmitting, setRunSubmitting] = useState(false); const [notice, setNotice] = useState('');
  const market = marketData?.mode === mode && marketData?.symbol === symbol && marketData?.requested_period === period ? marketData : null;
  const portfolio = portfolioData?.mode === mode ? portfolioData : null;
  const currentQuotes = Object.fromEntries(Object.entries(quotes).filter(([, quote]) => quote.mode === mode));
  const authorized = status && (status.authenticated || !status.auth_required);
  const refreshStatus = useCallback(async () => { try { setInitialError(''); setStatus(await api('/status')); } catch (e) { setInitialError(e.message); } }, []);
  useEffect(() => { refreshStatus(); }, [refreshStatus]);
  useEffect(() => { try { localStorage.setItem('tradingagents-mode-v2', mode); } catch { /* Preferences are optional. */ } setActiveRun(null); }, [mode]);
  const handleError = useCallback((e) => { if (e.status === 401) refreshStatus(); }, [refreshStatus]);
  useEffect(() => {
    if (!authorized || mode !== 'live') return;
    const refreshVisible = () => { if (document.visibilityState === 'visible') setMarketRefresh((x) => x + 1); };
    const timer = setInterval(refreshVisible, 60000);
    document.addEventListener('visibilitychange', refreshVisible);
    return () => { clearInterval(timer); document.removeEventListener('visibilitychange', refreshVisible); };
  }, [authorized, mode]);
  useEffect(() => {
    if (!authorized) return; let alive = true;
    const query = `${mode}:${symbol}:${period}`;
    const backgroundRefresh = marketQuery.current === query && Boolean(marketData);
    marketQuery.current = query;
    setMarketLoading(!backgroundRefresh); setMarketRefreshing(backgroundRefresh); setMarketError('');
    if (!backgroundRefresh) setMarket(null);
    api(`/market/${encodeURIComponent(symbol)}?period=${period}&mode=${mode}&refresh=${marketRefresh > 0 ? 'true' : 'false'}`).then((data) => { if (alive) { setMarket({ ...data, requested_period: period }); setQuotes((q) => ({ ...q, [symbol]: data })); } }).catch((e) => { if (alive) { setMarket(null); setMarketError(e.message); setQuotes((q) => ({ ...q, [symbol]: { error: true, mode } })); handleError(e); } }).finally(() => { if (alive) { setMarketLoading(false); setMarketRefreshing(false); } });
    return () => { alive = false; };
  }, [authorized, symbol, mode, period, marketRefresh, handleError]);
  useEffect(() => { if (!authorized) return; setWatchLoading(true); api('/watchlist').then((r) => setWatchlist(r.symbols)).catch((e) => { setNotice(e.message); handleError(e); }).finally(() => setWatchLoading(false)); }, [authorized, handleError]);
  useEffect(() => {
    if (!authorized) return; let alive = true;
    watchlist.forEach((s) => api(`/market/${encodeURIComponent(s)}?period=1mo&mode=${mode}&refresh=${marketRefresh > 0 ? 'true' : 'false'}`).then((r) => { if (alive) setQuotes((q) => ({ ...q, [s]: r })); }).catch((e) => { if (alive) setQuotes((q) => ({ ...q, [s]: { error: true, mode } })); }));
    return () => { alive = false; };
  }, [authorized, watchlist, mode, marketRefresh]);
  const refreshPortfolio = useCallback(async () => {
    if (!authorized) return;
    const requestedMode = mode;
    const generation = ++portfolioGeneration.current;
    setPortfolioLoading(true); setPortfolioError('');
    try {
      const result = await api(`/portfolio?mode=${requestedMode}`);
      if (modeRef.current === requestedMode && portfolioGeneration.current === generation) setPortfolio(result);
    } catch (e) { if (modeRef.current === requestedMode && portfolioGeneration.current === generation) { setPortfolioError(e.message); handleError(e); } }
    finally { if (modeRef.current === requestedMode && portfolioGeneration.current === generation) setPortfolioLoading(false); }
  }, [authorized, mode, handleError]);
  useEffect(() => { setPortfolio(null); refreshPortfolio(); }, [refreshPortfolio]);
  const refreshRuns = useCallback(async () => { if (!authorized) return; try { const data = await api('/runs'); setRuns(data.runs); return data.runs; } catch (e) { handleError(e); } }, [authorized, handleError]);
  useEffect(() => { refreshRuns(); }, [refreshRuns]);
  const viewRun = useCallback(async (run) => { try { const result = await api(`/runs/${run.id}`); if (result.mode === modeRef.current) setActiveRun(result); } catch (e) { setNotice(e.message); handleError(e); } }, [handleError]);
  useEffect(() => { if (!activeRun) { const recent = runs.find((r) => r.mode === mode); if (recent) viewRun(recent); } }, [runs, mode, activeRun, viewRun]);
  useEffect(() => { if (!isBusy(activeRun)) return; const timer = setInterval(async () => { await viewRun(activeRun); await refreshRuns(); }, 1500); return () => clearInterval(timer); }, [activeRun, viewRun, refreshRuns]);
  useEffect(() => { if (!notice) return; const timer = setTimeout(() => setNotice(''), 7000); return () => clearTimeout(timer); }, [notice]);
  async function addSymbol(s) { const result = await api('/watchlist', { method: 'POST', body: JSON.stringify({ symbol: s }) }); setWatchlist(result.symbols); setSymbol(s); }
  async function removeSymbol(s) { try { const result = await api(`/watchlist/${encodeURIComponent(s)}`, { method: 'DELETE' }); setWatchlist(result.symbols); } catch (e) { setNotice(e.message); } }
  async function runAnalysis(inputs) { setRunSubmitting(true); try { const run = await api('/runs', { method: 'POST', body: JSON.stringify(inputs) }); if (inputs.mode === modeRef.current) { setActiveRun(run); setNav('research'); } await refreshRuns(); await refreshStatus(); } catch (failure) { await refreshStatus(); throw failure; } finally { setRunSubmitting(false); } }
  async function order(inputs) { const result = await api('/orders', { method: 'POST', body: JSON.stringify(inputs) }); if (inputs.mode === modeRef.current) { portfolioGeneration.current += 1; setPortfolio(result.portfolio); setPortfolioLoading(false); setPortfolioError(''); } return result; }
  function searchSubmit(e) { e.preventDefault(); const value = search.trim().toUpperCase(); if (!value) return; if (!/^[A-Z0-9^][A-Z0-9.^=-]{0,19}$/.test(value)) { setNotice('Enter a valid market symbol, such as AAPL, BRK-B, or BTC-USD.'); return; } setSymbol(value); setSearch(''); setNav('overview'); }
  async function logout() { try { await api('/logout', { method: 'POST' }); setStatus(null); refreshStatus(); } catch (e) { setNotice(e.message); } }
  if (!status) return <div className="boot-screen"><Brand />{initialError ? <ErrorBox action="Retry" onAction={refreshStatus}>{initialError}</ErrorBox> : <Spinner label="Opening your research desk" />}</div>;
  if (!authorized) return <Login onLogin={refreshStatus} required={status.auth_required} />;
  const currentNav = NAV.find((n) => n[0] === nav)?.[1] || 'Settings';
  return <div className="app-shell"><aside className={`sidebar ${mobileNav ? 'open' : ''}`}><Brand /><button className="sidebar-workspace" onClick={() => { setNav('overview'); setMobileNav(false); }}><span className="workspace-avatar">P</span><span><strong>Personal workspace</strong><small>Private research desk</small></span><ChevronDown size={14} /></button><div className="nav-eyebrow">WORKSPACE</div><nav>{NAV.map(([key, label, Icon]) => <button className={nav === key ? 'active' : ''} onClick={() => { setNav(key); setMobileNav(false); }} key={key}><Icon size={19} /><span>{label}</span>{key === 'research' && <span className="nav-spark"><Sparkles size={12} /></span>}</button>)}</nav><div className="sidebar-bottom"><div className="sidebar-note"><div className="note-spark"><Sparkles size={18} /></div><strong>Better inputs.<br />Better decisions.</strong><p>Let your research team see the market from every angle.</p><button onClick={() => { setNav('research'); setMobileNav(false); }}>Explore AI research<ArrowUpRight size={14} /></button></div><button className={`settings-nav ${nav === 'settings' ? 'active' : ''}`} onClick={() => { setNav('settings'); setMobileNav(false); }}><Settings2 size={18} />Connections & settings</button><div className="sidebar-profile"><span className="profile-avatar">YO</span><span><strong>Your workspace</strong><small><span className="tiny-dot" />Private session</small></span>{status.auth_required && <button className="icon-button" title="Sign out" aria-label="Sign out" onClick={logout}><LogOut size={16} /></button>}</div></div></aside>{mobileNav && <button className="mobile-backdrop" aria-label="Close navigation" onClick={() => setMobileNav(false)} />}
    <div className="main-shell"><header className="topbar"><div className="breadcrumbs"><button className="icon-button mobile-menu" onClick={() => setMobileNav(!mobileNav)} aria-label="Open navigation"><Menu size={20} /></button><span className="desktop-only">Workspace</span><ChevronRight size={13} className="desktop-only" /><strong>{currentNav}</strong></div><div className="header-controls"><div className="mode-toggle" aria-label="Data source"><button aria-pressed={mode === 'demo'} className={mode === 'demo' ? 'selected' : ''} onClick={() => setMode('demo')}><FlaskConical size={13} />Demo examples</button><button aria-pressed={mode === 'live'} className={mode === 'live' ? 'selected' : ''} onClick={() => setMode('live')}><Globe2 size={13} />Real market data</button></div><button className="icon-button header-settings" title="Connection settings" aria-label="Connection settings" onClick={() => setNav('settings')}><Settings2 size={19} /></button><div className="header-avatar">YO</div></div></header>
      <div className={`mode-notice ${mode}`}><span>{mode === 'demo' ? <FlaskConical size={14} /> : <Clock3 size={14} />}<strong>{mode === 'demo' ? 'Demo: generated prices — never use for trading' : 'Real market-data workspace'}</strong><span className="mode-notice-description">{mode === 'demo' ? 'Fictional quotes and example reports, regardless of the displayed date.' : 'Source and quote time shown below. Place any real orders in your own broker account.'}</span></span><span className="paper-only"><ShieldCheck size={13} />MANUAL EXECUTION · NO BROKER CONNECTION</span></div>
      <main>{(nav === 'overview' || nav === 'research') && <><div className="section-title"><div><div className="eyebrow">{nav === 'research' ? 'INTELLIGENCE, FROM EVERY ANGLE' : 'YOUR RESEARCH WORKSPACE'}</div><h1>{nav === 'research' ? 'Meet your research team' : 'Markets at a glance'}<span className="heading-dot">.</span></h1><p>{nav === 'research' ? 'From evidence to a considered portfolio view.' : 'A clearer view of the market. A more informed next move.'}</p></div><form className="symbol-search" onSubmit={searchSubmit}><Search size={16} /><label htmlFor="symbol-search" className="sr-only">Find a symbol</label><input id="symbol-search" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Find a symbol…" maxLength={20} /><kbd>↵</kbd></form></div>{nav === 'overview' && <><div className="metrics-grid"><Metric label={mode === 'demo' ? `${symbol} · Generated demo price` : `${symbol} · Last completed daily close`} value={money(mode === 'demo' ? market?.price : market?.last_completed_close, market?.currency)} icon={BarChart3} foot={mode === 'demo' ? 'Fictional example · Never use for trading' : market?.last_completed_session_date ? `${friendlyDate(market.last_completed_session_date)} · ${market.provider || 'Yahoo Finance'}` : 'No completed close confirmed by provider'} /><Metric label={`${symbol} · ${quoteLabel(market)}`} value={money(market?.price, market?.currency)} icon={TrendingUp} foot={mode === 'demo' ? 'Generated demonstration data' : market ? dateTime(market.quote_as_of || market.as_of, market.exchange_timezone) : 'Provider timestamp unavailable'} /><Metric label="Market session" value={mode === 'demo' ? 'Demonstration' : market ? sessionLabel(market) : 'Unavailable'} icon={Clock3} foot={market?.exchange_timezone || 'No session timezone supplied'} /><Metric label="Research completed" value={number(runs.filter((r) => r.mode === mode && r.status === 'completed').length, 0)} icon={BrainCircuit} foot={mode === 'demo' ? 'Illustrative demo reports' : 'Saved AI research reports'} /></div><QuoteProvenance market={market} mode={mode} loading={marketLoading || marketRefreshing} onRefresh={() => setMarketRefresh((x) => x + 1)} /><div className="workspace-grid"><PriceChart market={market} loading={marketLoading} error={marketError} period={period} setPeriod={setPeriod} onRetry={() => setMarketRefresh((x) => x + 1)} /><Watchlist symbols={watchlist} quotes={currentQuotes} selected={symbol} onSelect={setSymbol} onAdd={addSymbol} onRemove={removeSymbol} loading={watchLoading} /><AnalysisForm symbol={symbol} mode={mode} status={status} onRun={runAnalysis} busy={runSubmitting || isBusy(activeRun)} onSettings={() => setNav('settings')} onStatusRefresh={refreshStatus} /><TradeTicket key={`${mode}:${symbol}`} symbol={symbol} market={market} portfolio={portfolio} mode={mode} onOrder={order} /></div>{portfolioError && <ErrorBox>{portfolioError}</ErrorBox>}<div className="research-history-heading"><div><h2>Recent research</h2><p className="small muted">Keep your reasoning within reach.</p></div><button className="text-button" onClick={() => setNav('reports')}>View all reports<ArrowRight size={14} /></button></div><div className="recent-research">{runs.filter((r) => r.mode === mode).slice(0, 3).map((run) => <button className="recent-card" key={run.id} onClick={() => { viewRun(run); setNav('research'); }}><div><span className="ticker-avatar small-avatar">{run.symbol[0]}</span><strong>{run.symbol}</strong><StatusPill status={run.status} /></div><span className="small muted">{friendlyDate(run.date)} · {run.mode === 'demo' ? 'Illustrative research' : 'AI research'}</span><div><span className={`rating small-rating ${(run.rating || '').toLowerCase()}`}>{run.rating || 'In progress'}</span><ArrowUpRight size={17} /></div></button>)}{!runs.some((r) => r.mode === mode) && <div className="recent-empty"><BrainCircuit size={20} /><span>Your next insight starts with a question. Run your first analysis above.</span></div>}</div></>}{nav === 'research' && <div className="research-layout"><div><AnalysisForm symbol={symbol} mode={mode} status={status} onRun={runAnalysis} busy={runSubmitting || isBusy(activeRun)} onSettings={() => setNav('settings')} onStatusRefresh={refreshStatus} /><RunResult run={activeRun?.mode === mode ? activeRun : null} onSettings={() => setNav('settings')} busy={runSubmitting || isBusy(activeRun)} onRetry={(previous) => runAnalysis({ symbol: previous.symbol, date: previous.date, analysts: previous.analysts || ['market'], mode: previous.mode, rounds: previous.rounds || 1 })} /></div><div><Watchlist symbols={watchlist} quotes={currentQuotes} selected={symbol} onSelect={setSymbol} onAdd={addSymbol} onRemove={removeSymbol} loading={watchLoading} /><div className="research-method panel"><div className="panel-heading"><h2>A team, not a single take</h2></div>{[['01', 'Analysts gather the evidence', 'Technical, news, fundamentals, and sentiment perspectives.'], ['02', 'Researchers test the thesis', 'Bull and bear researchers debate the investment case.'], ['03', 'Risk shapes the decision', 'A trader and risk team consider sizing and the final portfolio view.']].map(([n, title, text]) => <div className="method-step" key={n}><span>{n}</span><div><strong>{title}</strong><p>{text}</p></div></div>)}</div></div></div>}</>}
      {nav === 'portfolio' && <Portfolio portfolio={portfolio} error={portfolioError} loading={portfolioLoading} mode={mode} onSelect={(s) => { setSymbol(s); setNav('overview'); }} />}
      {nav === 'reports' && <><div className="section-title"><div><div className="eyebrow">YOUR RESEARCH, REMEMBERED</div><h1>The thinking behind the trade</h1><p>Revisit the evidence. Refine your process.</p></div><button className="button secondary" onClick={refreshRuns}><RefreshCw size={15} />Refresh</button></div><History runs={runs} mode={mode} onView={(r) => { viewRun(r); setNav('research'); }} /></>}
      {nav === 'settings' && <Settings status={status} onRefresh={async () => { await refreshStatus(); setNotice('Connection status refreshed.'); }} />}
      <footer className="app-footer"><span><span className="tiny-dot" />TradingAgents research desk</span><span>Research to inform. Judgment to decide.</span><span>You execute real trades with your own broker.</span></footer></main></div>{notice && <div className="toast" role="status"><CircleHelp size={17} /><span>{notice}</span><button className="icon-button" aria-label="Dismiss notification" onClick={() => setNotice('')}><X size={14} /></button></div>}</div>;
}

createRoot(document.getElementById('root')).render(<React.StrictMode><App /></React.StrictMode>);
