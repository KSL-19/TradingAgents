"""Offline UI contract check; market/model data are fixtures, not provider verification."""
import copy
import json
import os
from pathlib import Path
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from threading import Thread
from urllib.parse import parse_qs, urlsplit

from playwright.sync_api import expect, sync_playwright

ROOT = Path(__file__).resolve().parents[1]


class Static(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT / 'dist'), **kwargs)

    def log_message(self, *args):
        pass


def run():
    state = {'key': False, 'verified': False, 'refreshes': 0, 'saved': [], 'mode_requests': [], 'runs': []}
    connection = {
        'provider': 'openai', 'key_configured': False, 'key_source': 'none', 'key_storage': 'none',
        'key_editable': True, 'verified': False, 'verified_at': None, 'verification_kind': 'model_list_only',
        'quick_model': 'gpt-4.1-mini', 'deep_model': 'gpt-4.1', 'sec_edgar_user_agent': '',
        'available_models': [], 'model_selection_validated': False, 'message': 'Add and test your API key.',
    }
    server = ThreadingHTTPServer(('127.0.0.1', 0), Static)
    thread = Thread(target=server.serve_forever, daemon=True)
    thread.start()
    base = f'http://127.0.0.1:{server.server_port}'

    def route_api(route):
        parsed = urlsplit(route.request.url)
        path = parsed.path.removeprefix('/api')
        method = route.request.method
        query = parse_qs(parsed.query)
        data = None
        if path == '/status':
            data = {'authenticated': True, 'auth_required': False, 'live_available': state['key'],
                    'ai_available': state['key'], 'ai_verified': state['verified'], 'provider': 'openai',
                    'default_mode': 'live', 'version': '0.7.1', 'app_version': '1.1.0',
                    'quick_model': connection['quick_model'], 'deep_model': connection['deep_model']}
        elif path == '/connections':
            if method == 'PUT':
                body = route.request.post_data_json
                state['saved'].append(body)
                if body.get('openai_api_key'):
                    state['key'] = True
                    connection.update(key_configured=True, key_source='local_saved', key_storage='windows_dpapi')
                for key in ('quick_model', 'deep_model', 'sec_edgar_user_agent'):
                    if key in body:
                        connection[key] = body[key]
            data = copy.deepcopy(connection)
        elif path == '/connections/test':
            state['verified'] = True
            connection.update(verified=True, verified_at='2026-10-27T20:10:00Z', model_selection_validated=True,
                              available_models=['gpt-4.1', 'gpt-4.1-mini'], message='Model-list access checked. Full analysis is a separate billed request.')
            data = copy.deepcopy(connection)
        elif path == '/connections/key':
            state.update(key=False, verified=False)
            connection.update(key_configured=False, verified=False, key_source='none', key_storage='none', model_selection_validated=False)
            data = copy.deepcopy(connection)
        elif path == '/watchlist':
            data = {'symbols': ['NVDA', 'AAPL']}
        elif path.startswith('/market/'):
            mode = query.get('mode', ['live'])[0]
            state['mode_requests'].append(mode)
            if query.get('refresh') == ['true']:
                state['refreshes'] += 1
            synthetic = mode == 'demo'
            price = 261.06 if synthetic else 218.11
            bars = [{'date': f'2026-10-{day:02d}', 'open': 210 + day / 10,
                     'high': 220 + day / 10, 'low': 208 + day / 10, 'close': 212 + day / 10, 'volume': 1000000}
                    for day in range(1, 28)]
            data = {'symbol': path.rsplit('/', 1)[1], 'name': 'Fixture instrument', 'currency': 'USD',
                    'exchange': 'SIMULATED' if synthetic else 'NASDAQ', 'mode': mode,
                    'source': 'Synthetic demo data' if synthetic else 'Yahoo Finance',
                    'provider': None if synthetic else 'Yahoo Finance', 'as_of': '2026-10-27T20:05:00Z',
                    'quote_as_of': '2026-10-27T20:05:00Z', 'quote_kind': 'regular_session', 'quote_date': '2026-10-27',
                    'fetched_at': '2026-10-27T20:10:00Z', 'session_state': 'post',
                    'exchange_timezone': 'America/New_York', 'freshness': 'outside_regular_hours', 'stale': False,
                    'freshness_note': 'Fixture regular-session quote; not a broker execution feed.',
                    'price': price, 'change': 0.22, 'change_percent': 0.1, 'bars': bars,
                    'last_completed_close': None if synthetic else 217.89,
                    'last_completed_session_date': None if synthetic else '2026-10-27',
                    'latest_bar_date': '2026-10-27', 'latest_bar_close': 217.89}
        elif path == '/portfolio':
            data = {'mode': query.get('mode', ['live'])[0], 'cash': 100000, 'buying_power': 100000,
                    'equity': 100000, 'unrealized_pnl': 0, 'realized_pnl': 0,
                    'initial_cash': 100000, 'positions': [], 'orders': [], 'quote_errors': []}
        elif path == '/runs':
            if method == 'POST':
                body = route.request.post_data_json
                data = dict(body, id='fixture-run', status='completed', created_at='2026-10-27T20:10:00Z',
                            updated_at='2026-10-27T20:11:00Z', rating='Hold', progress='Complete',
                            reports={'market_report': 'Fixture-only technical research.', 'final_trade_decision': 'Fixture-only rating: Hold'},
                            source_coverage={'summary_status': 'incomplete', 'attempted_tools': ['get_stock_data', 'get_indicators'],
                                             'unavailable_tools': ['get_indicators'], 'empty_output_tools': [],
                                             'no_tools_warning': False, 'unobserved_analysts': [],
                                             'limitations': ['Fixture unavailable indicator source. Output does not establish source accuracy.']})
                state['runs'] = [data]
            else:
                data = {'runs': state['runs']}
        elif path == '/runs/fixture-run':
            data = state['runs'][0]
        if data is None:
            route.fulfill(status=404, content_type='application/json', body='{"detail":"Fixture route not found"}')
        else:
            route.fulfill(status=200, content_type='application/json', body=json.dumps(data))

    try:
        with sync_playwright() as p:
            browser = p.chromium.launch(executable_path=os.getenv('CHROMIUM_BIN', '/usr/bin/chromium'),
                                        headless=True, args=['--no-sandbox', '--disable-dev-shm-usage'])
            page = browser.new_page(viewport={'width': 1440, 'height': 1000})
            errors = []
            page.on('pageerror', lambda error: errors.append(str(error)))
            page.add_init_script("localStorage.setItem('tradingagents-mode', 'demo')")
            page.route('**/api/**', route_api)
            page.goto(base, wait_until='networkidle')
            expect(page.get_by_role('button', name='Real market data', exact=True)).to_have_attribute('aria-pressed', 'true')
            expect(page.locator('.metrics-grid .metric').first).to_contain_text('Last completed daily close')
            expect(page.locator('.metrics-grid .metric').first).to_contain_text('$217.89')
            expect(page.locator('.metrics-grid .metric').nth(1)).to_contain_text('$218.11')
            assert '261.06' not in page.inner_text('body')
            assert set(state['mode_requests']) == {'live'}
            expect(page.get_by_role('button', name='Run AI analysis')).to_be_disabled()
            expect(page.get_by_label('Market data provenance')).to_contain_text('Provider quote timestamp')
            page.get_by_role('button', name='Refresh prices', exact=True).click()
            expect(page.get_by_role('button', name='Refresh prices', exact=True)).to_be_enabled()
            assert state['refreshes'] > 0
            page.get_by_role('button', name='Connections & settings', exact=True).click()
            page.locator('#provider-key').fill('sk-browser-fixture-not-a-real-key')
            page.get_by_role('button', name='Save & test connection', exact=True).click()
            expect(page.get_by_text('Model access checked', exact=True).first).to_be_visible()
            expect(page.locator('#provider-key')).to_have_value('')
            assert 'quick_model' not in state['saved'][0], 'Initial fallback models must not override actual account auto-selection'
            assert 'sk-browser-fixture-not-a-real-key' not in page.evaluate('JSON.stringify(localStorage)')
            page.get_by_role('button', name='AI research', exact=True).click()
            expect(page.get_by_role('button', name='Run AI analysis')).to_be_enabled()
            page.get_by_role('button', name='Run AI analysis').click()
            expect(page.get_by_label('Report source availability')).to_contain_text('Source availability needs review')
            expect(page.get_by_label('Report source availability')).to_contain_text('Technical indicators')
            page.get_by_role('button', name='Demo examples', exact=True).click()
            expect(page.locator('.mode-notice.demo')).to_contain_text('never use for trading')
            page.get_by_role('button', name='Real market data', exact=True).click()
            expect(page.get_by_role('button', name='Run AI analysis')).to_be_enabled()
            page.get_by_role('button', name='Overview', exact=True).click()
            expect(page.get_by_label('Market data provenance')).to_be_visible()
            assert not errors, errors
            mobile = browser.new_page(viewport={'width': 390, 'height': 844}, is_mobile=True, has_touch=True)
            mobile.route('**/api/**', route_api)
            mobile.goto(base, wait_until='networkidle')
            assert mobile.evaluate('document.documentElement.scrollWidth <= window.innerWidth + 1'), 'Mobile page must not overflow horizontally'
            expect(mobile.get_by_role('button', name='Real market data', exact=True)).to_have_attribute('aria-pressed', 'true')
            output = Path(os.getenv('DASHBOARD_FRONTEND_ARTIFACTS', '/tmp/dashboard-real-frontend'))
            output.mkdir(parents=True, exist_ok=True)
            mobile.screenshot(path=str(output / 'real-mobile.png'), full_page=True)
            page.screenshot(path=str(output / 'real-overview.png'), full_page=True)
            browser.close()
        print('Real-data UI contract passed: legacy-demo migration, distinct daily-close/quote provenance, refresh, key save/test/no browser persistence, AI gating, explicit demo selection, mobile layout. Provider responses were fixtures.')
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=2)


if __name__ == '__main__':
    run()
