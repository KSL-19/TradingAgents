"""Durable paper ledger with decimal arithmetic and atomic cash/position updates."""

import json
import sqlite3
import uuid
from contextlib import contextmanager
from datetime import UTC, datetime
from decimal import ROUND_HALF_UP, Decimal
from pathlib import Path

INITIAL_CASH_CENTS = 10_000_000


def now() -> str:
    return datetime.now(UTC).isoformat()


def cents(amount: Decimal) -> int:
    return int((amount * 100).quantize(Decimal(1), rounding=ROUND_HALF_UP))


class LedgerError(Exception):
    pass


class Store:
    def __init__(self, data_dir: Path):
        data_dir.mkdir(parents=True, exist_ok=True)
        self.path = data_dir / "dashboard.sqlite3"
        with self.connection() as db:
            db.executescript("""
                PRAGMA journal_mode=WAL;
                CREATE TABLE IF NOT EXISTS accounts(mode TEXT PRIMARY KEY, cash_cents INTEGER NOT NULL,
                    realized_cents INTEGER NOT NULL DEFAULT 0);
                CREATE TABLE IF NOT EXISTS positions(mode TEXT, symbol TEXT, quantity TEXT NOT NULL,
                    cost_basis_cents INTEGER NOT NULL, PRIMARY KEY(mode,symbol));
                CREATE TABLE IF NOT EXISTS orders(id TEXT PRIMARY KEY, mode TEXT NOT NULL,
                    symbol TEXT NOT NULL, side TEXT NOT NULL, quantity TEXT NOT NULL,
                    price TEXT NOT NULL, total_cents INTEGER NOT NULL, as_of TEXT NOT NULL,
                    source TEXT NOT NULL, created_at TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS watchlist(symbol TEXT PRIMARY KEY, created_at TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS runs(id TEXT PRIMARY KEY, symbol TEXT NOT NULL, mode TEXT NOT NULL,
                    status TEXT NOT NULL, created_at TEXT NOT NULL, updated_at TEXT NOT NULL, payload TEXT NOT NULL);
            """)
            for mode in ("demo", "live"):
                db.execute("INSERT OR IGNORE INTO accounts(mode,cash_cents) VALUES(?,?)", (mode, INITIAL_CASH_CENTS))
            if not db.execute("SELECT 1 FROM settings WHERE key='watchlist_initialized'").fetchone():
                for symbol in ("AAPL", "NVDA", "MSFT", "GOOGL", "SPY"):
                    db.execute("INSERT OR IGNORE INTO watchlist VALUES(?,?)", (symbol, now()))
                db.execute("INSERT INTO settings VALUES('watchlist_initialized','1')")
            # An interrupted background process cannot still own an active run.
            for row in db.execute("SELECT id,payload FROM runs WHERE status IN ('running','queued')").fetchall():
                payload = json.loads(row["payload"])
                payload.update(status="failed", error="The server restarted before this analysis finished. Start a new run.", progress="Interrupted", updated_at=now())
                db.execute("UPDATE runs SET status='failed', updated_at=?,payload=? WHERE id=?", (now(), json.dumps(payload), row["id"]))

    @contextmanager
    def connection(self):
        db = sqlite3.connect(self.path, timeout=10)
        db.row_factory = sqlite3.Row
        try:
            yield db
            db.commit()
        except Exception:
            db.rollback()
            raise
        finally:
            db.close()

    def watchlist(self) -> list[str]:
        with self.connection() as db:
            return [row[0] for row in db.execute("SELECT symbol FROM watchlist ORDER BY created_at,symbol")]

    def add_symbol(self, symbol: str) -> list[str]:
        with self.connection() as db:
            if db.execute("SELECT COUNT(*) FROM watchlist").fetchone()[0] >= 30:
                raise LedgerError("The watchlist can contain up to 30 symbols.")
            db.execute("INSERT OR IGNORE INTO watchlist VALUES(?,?)", (symbol, now()))
        return self.watchlist()

    def remove_symbol(self, symbol: str) -> list[str]:
        with self.connection() as db:
            db.execute("DELETE FROM watchlist WHERE symbol=?", (symbol,))
        return self.watchlist()

    @staticmethod
    def order_json(row) -> dict:
        return {"id": row["id"], "symbol": row["symbol"], "side": row["side"],
                "quantity": float(row["quantity"]), "price": float(row["price"]),
                "total": row["total_cents"] / 100, "created_at": row["created_at"],
                "mode": row["mode"], "as_of": row["as_of"], "source": row["source"]}

    def account(self, mode: str) -> tuple[dict, list[dict], list[dict]]:
        with self.connection() as db:
            account = dict(db.execute("SELECT * FROM accounts WHERE mode=?", (mode,)).fetchone())
            positions = [dict(row) for row in db.execute("SELECT * FROM positions WHERE mode=? ORDER BY symbol", (mode,))]
            orders = [self.order_json(row) for row in db.execute("SELECT * FROM orders WHERE mode=? ORDER BY created_at DESC LIMIT 100", (mode,))]
        return account, positions, orders

    def fill(self, mode: str, symbol: str, side: str, quantity: Decimal, quote: dict) -> dict:
        if quote.get("currency") != "USD":
            raise LedgerError("The paper account supports USD-quoted instruments only; currency conversion is not configured.")
        price = Decimal(str(quote["price"]))
        if not price.is_finite() or price <= 0:
            raise LedgerError("A valid positive price is required to simulate an order.")
        total = cents(price * quantity)
        if total <= 0:
            raise LedgerError("The simulated order value must be at least $0.01.")
        with self.connection() as db:
            db.execute("BEGIN IMMEDIATE")
            cash, realized = db.execute("SELECT cash_cents,realized_cents FROM accounts WHERE mode=?", (mode,)).fetchone()
            position = db.execute("SELECT quantity,cost_basis_cents FROM positions WHERE mode=? AND symbol=?", (mode, symbol)).fetchone()
            held = Decimal(position["quantity"]) if position else Decimal(0)
            basis = position["cost_basis_cents"] if position else 0
            if side == "buy":
                if cash < total:
                    raise LedgerError("Insufficient paper cash for this order.")
                if not position and db.execute("SELECT COUNT(*) FROM positions WHERE mode=?", (mode,)).fetchone()[0] >= 30:
                    raise LedgerError("The paper account supports up to 30 positions.")
                cash -= total
                held += quantity
                basis += total
            else:
                if held < quantity:
                    raise LedgerError("Insufficient shares. Paper trading does not support short selling.")
                sold_basis = int((Decimal(basis) * quantity / held).quantize(Decimal(1), rounding=ROUND_HALF_UP))
                cash += total
                realized += total - sold_basis
                held -= quantity
                basis -= sold_basis
            db.execute("UPDATE accounts SET cash_cents=?,realized_cents=? WHERE mode=?", (cash, realized, mode))
            if held > 0:
                db.execute("INSERT INTO positions VALUES(?,?,?,?) ON CONFLICT(mode,symbol) DO UPDATE SET quantity=excluded.quantity,cost_basis_cents=excluded.cost_basis_cents", (mode, symbol, str(held), basis))
            else:
                db.execute("DELETE FROM positions WHERE mode=? AND symbol=?", (mode, symbol))
            order_id = uuid.uuid4().hex
            db.execute("INSERT INTO orders VALUES(?,?,?,?,?,?,?,?,?,?)", (order_id, mode, symbol, side, str(quantity), str(price), total, quote["as_of"], quote["source"], now()))
            row = db.execute("SELECT * FROM orders WHERE id=?", (order_id,)).fetchone()
            return self.order_json(row)

    def save_run(self, payload: dict):
        with self.connection() as db:
            db.execute("INSERT INTO runs VALUES(?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET status=excluded.status,updated_at=excluded.updated_at,payload=excluded.payload", (payload["id"], payload["symbol"], payload["mode"], payload["status"], payload["created_at"], payload["updated_at"], json.dumps(payload)))

    def get_run(self, run_id: str) -> dict | None:
        with self.connection() as db:
            row = db.execute("SELECT payload FROM runs WHERE id=?", (run_id,)).fetchone()
        return json.loads(row[0]) if row else None

    def list_runs(self, mode: str | None = None) -> list[dict]:
        with self.connection() as db:
            rows = db.execute("SELECT payload FROM runs WHERE (? IS NULL OR mode=?) ORDER BY created_at DESC LIMIT 100", (mode, mode)).fetchall()
        return [{key: value for key, value in json.loads(row[0]).items() if key != "reports"} for row in rows]
