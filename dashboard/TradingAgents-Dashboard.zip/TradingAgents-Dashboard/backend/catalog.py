"""Account-observed research model choices, not a static access promise.

The provider's model list does not describe tool/structured-output support or
generation billing. These candidates still need an actual analysis request.
"""

import re

_EXCLUDED = re.compile(
    r"(?:embed|audio|tts|transcri|whisper|realtime|image|dall[-_]?e|moderation|"
    r"(?:^|[-_/:])search(?:$|[-_/:])|computer[-_]?use|deep[-_]?research|codex)", re.IGNORECASE,
)
_LEGACY_COMPLETION = re.compile(r"^(?:text-|code-|davinci|babbage|curie|ada(?:$|[-_]))", re.IGNORECASE)
_MODEL_ID = re.compile(r"^[A-Za-z0-9_.:/\-]{1,100}$")


def is_research_candidate(model: str) -> bool:
    """Filter known non-research modalities without inventing unknown model IDs."""
    return bool(isinstance(model, str) and _MODEL_ID.fullmatch(model) and not credential_like_model(model)
                and not _EXCLUDED.search(model) and not _LEGACY_COMPLETION.search(model))


def credential_like_model(value: str) -> bool:
    return isinstance(value, str) and value.lower().startswith(("sk-", "bearer"))


def family(model: str) -> str:
    value = model.lower()
    for name in ("Astra", "Sol", "Luna"):
        if re.search(r"(?:^|[-_/.])" + name.lower() + r"(?:$|[-_/.])", value):
            return name
    if re.search(r"(?:^|[:/])gpt-", value) or value.startswith("chatgpt-"):
        return "GPT"
    if re.match(r"^o\d(?:$|[-.])", value):
        return "Reasoning"
    return "Other"


def _version(model: str) -> tuple[int, ...]:
    value = re.search(r"(?:gpt-|^o)(\d+(?:\.\d+)*)", model, re.IGNORECASE)
    return tuple(int(part) for part in value.group(1).split(".")) if value else (0,)


def _rank(model: str, role: str):
    category = family(model)
    preferences = {"quick": {"Sol": 5, "Luna": 4, "Astra": 3},
                   "deep": {"Astra": 5, "Sol": 4, "Luna": 3}}[role]
    # Unknown model IDs remain selectable, but known research families win
    # automatic selection. Within a family prefer the newest returned version.
    category_rank = preferences.get(category, 2 if category in ("GPT", "Reasoning") else 1)
    small = bool(re.search(r"(?:^|[-_])(mini|nano)(?:$|[-_])", model, re.IGNORECASE))
    size_rank = int(small) if role == "quick" else int(not small)
    date = re.search(r"(20\d{2})[-_](\d{2})[-_](\d{2})", model)
    snapshot = tuple(map(int, date.groups())) if date else (9999, 0, 0)
    return category_rank, _version(model), size_rank, snapshot, model


def model_catalog(available: list[str], *, observed: bool = True) -> dict:
    candidates = sorted({model for model in available if is_research_candidate(model)})
    quick = max(candidates, key=lambda model: _rank(model, "quick")) if candidates else None
    deep = max(candidates, key=lambda model: _rank(model, "deep")) if candidates else None
    options = []
    for model in sorted(candidates, key=lambda model: _rank(model, "deep"), reverse=True):
        category = family(model)
        label = f"{category} · {model}" if category in ("Astra", "Sol", "Luna") else model
        options.append({"id": model, "label": label, "family": category,
                        "recommended_for": [role for role, selected in (("quick", quick), ("deep", deep)) if model == selected],
                        "capability_status": "listed_not_generation_tested"})
    unavailable = [
        {"family": category, "label": f"{category} unavailable for this key",
         "message": f"The current API model list did not include an eligible {category} research candidate. An app label or subscription does not grant API access."}
        for category in ("Sol", "Astra") if observed and not any(option["family"] == category for option in options)
    ]
    return {"model_options": options, "recommended_quick_model": quick,
            "recommended_deep_model": deep, "unavailable_requested_options": unavailable}


def selection_issues(quick: str, deep: str, available: list[str], *, observed: bool) -> list[dict]:
    if not observed:
        return []
    listed = set(available)
    issues = []
    for role, selected in (("quick", quick), ("deep", deep)):
        name = "analyst" if role == "quick" else "decision"
        if not selected:
            code, message = "model_not_selected", f"Choose an {name} model from this account's research model list, or apply the recommendations."
        elif selected not in listed:
            code, message = "model_not_listed", f"The selected {name} model is not in this key's API model list. Choose an available model or apply the recommendations."
        elif not is_research_candidate(selected):
            code, message = "model_not_research_candidate", f"The selected {name} model is a non-research modality or specialized endpoint. Choose an available research model."
        else:
            continue
        issues.append({"role": role, "model": selected, "code": code, "message": message})
    return issues
