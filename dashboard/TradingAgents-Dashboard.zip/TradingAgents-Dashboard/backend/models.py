"""Validated public API inputs; no credential fields are accepted."""

from datetime import date, datetime
from decimal import Decimal
from typing import Literal
from zoneinfo import ZoneInfo

from pydantic import BaseModel, ConfigDict, Field, field_validator

Mode = Literal["demo", "live"]


def today() -> date:
    return datetime.now(ZoneInfo("America/New_York")).date()


class Input(BaseModel):
    model_config = ConfigDict(extra="forbid")


class SymbolInput(Input):
    symbol: str = Field(min_length=1, max_length=20, pattern=r"^[A-Za-z0-9^][A-Za-z0-9.^=\-]{0,19}$")

    @field_validator("symbol")
    @classmethod
    def uppercase(cls, value: str) -> str:
        return value.upper()


class LoginInput(Input):
    password: str = Field(min_length=1, max_length=1024)


class RunInput(SymbolInput):
    date: str = Field(default_factory=lambda: today().isoformat())
    mode: Mode = "demo"
    analysts: list[Literal["market", "news", "fundamentals", "social"]] = Field(
        default_factory=lambda: ["market"], min_length=1, max_length=4
    )
    quick_model: str = Field(default="gpt-6-luna", min_length=1, max_length=100, pattern=r"^[A-Za-z0-9_.:/\-]+$")
    deep_model: str = Field(default="gpt-6-sol", min_length=1, max_length=100, pattern=r"^[A-Za-z0-9_.:/\-]+$")
    rounds: int = Field(default=1, ge=1, le=3)

    @field_validator("date")
    @classmethod
    def canonical_date(cls, value: str) -> str:
        parsed = date.fromisoformat(value)
        if parsed.isoformat() != value or parsed > today():
            raise ValueError("Use a YYYY-MM-DD analysis date no later than today.")
        return value

    @field_validator("analysts")
    @classmethod
    def unique_analysts(cls, value: list[str]) -> list[str]:
        if len(set(value)) != len(value):
            raise ValueError("Select each analyst once.")
        return value


class OrderInput(SymbolInput):
    mode: Mode = "demo"
    side: Literal["buy", "sell"]
    quantity: Decimal = Field(gt=0, le=1_000_000, max_digits=13, decimal_places=6, allow_inf_nan=False)
