"""Connection wizard tests use fake provider responses and no external traffic.

The Windows storage test exercises the DPAPI-selected branch with mocked
protection helpers. It does not claim to test Windows APIs on this Linux host.
"""

import json
import os
import socket
import stat
from datetime import UTC, datetime, timedelta

import pytest
from fastapi.testclient import TestClient

from backend import connections
from backend.app import create_app

TEST_KEY = "sk-proj-test-only-not-a-real-credential-12345678901234567890"
OTHER_KEY = "sk-proj-another-test-only-value-09876543210987654321"
MODELS = ["gpt-4.1-mini", "gpt-4.1"]


@pytest.fixture(autouse=True)
def no_external_traffic_or_credentials(monkeypatch):
    for name in (
        "OPENAI_API_KEY", "TRADINGAGENTS_OPENAI_API_KEY", "DASHBOARD_PASSWORD",
        "DASHBOARD_LOCAL_MODE", "DASHBOARD_PUBLIC_ORIGIN", "DASHBOARD_SECURE_COOKIES",
        "SEC_EDGAR_USER_AGENT", "TRADINGAGENTS_QUICK_THINK_LLM", "TRADINGAGENTS_DEEP_THINK_LLM",
    ):
        monkeypatch.delenv(name, raising=False)

    def refuse(*args, **kwargs):
        raise AssertionError("Connection tests must not make external requests")

    monkeypatch.setattr(socket.socket, "connect", refuse)
    monkeypatch.setattr(socket.socket, "connect_ex", refuse)


@pytest.fixture
def client(tmp_path):
    with TestClient(create_app(tmp_path, local_mode=True)) as value:
        yield value


def save_key(client, key=TEST_KEY, **extra):
    response = client.put("/api/connections", json={"openai_api_key": key, **extra})
    assert response.status_code == 200, response.text
    assert key not in response.text
    return response.json()


def test_new_workspace_has_real_data_default_and_unverified_ai(client):
    state = client.get("/api/connections")
    assert state.status_code == 200
    value = state.json()
    assert value["provider"] == "openai"
    assert value["key_configured"] is False
    assert value["key_source"] == "none"
    assert value["verified"] is False
    assert value["verified_at"] is None
    assert value["available_models"] == []
    assert value["verification_kind"] == "model_list_only"
    status = client.get("/api/status").json()
    assert status["default_mode"] == "live"
    assert status["ai_available"] is False
    assert status["app_version"] == "1.2.0"


def test_save_key_returns_metadata_only_and_does_not_claim_validation(client, monkeypatch, tmp_path):
    def do_not_call_provider(key):
        raise AssertionError("Saving settings must not silently contact OpenAI")

    monkeypatch.setattr(connections, "_list_models", do_not_call_provider)
    value = save_key(client, quick_model="custom-analyst", deep_model="custom-decision")
    assert value["key_configured"] is True
    assert value["key_source"] == "local_saved"
    assert value["verified"] is False
    assert value["quick_model"] == "custom-analyst"
    assert value["deep_model"] == "custom-decision"
    assert TEST_KEY not in json.dumps(client.get("/api/status").json())
    config = tmp_path / "config.json"
    assert config.is_file()
    assert TEST_KEY not in config.read_text()
    assert connections.ConnectionSettings(tmp_path).get_key() == TEST_KEY


def test_local_settings_persist_without_resetting_other_workspace_files(tmp_path):
    account = tmp_path / "keep-user-notes.txt"
    account.write_text("keep these notes")
    with TestClient(create_app(tmp_path, local_mode=True)) as first:
        save_key(first, sec_edgar_user_agent="Test Operator operator@example.test")
        watchlist = first.get("/api/watchlist").json()
    with TestClient(create_app(tmp_path, local_mode=True)) as second:
        value = second.get("/api/connections").json()
        assert value["key_configured"] is True
        assert value["sec_edgar_user_agent"] == "Test Operator operator@example.test"
        assert second.get("/api/watchlist").json() == watchlist
        assert TEST_KEY not in json.dumps(value)
    assert account.read_text() == "keep these notes"


def test_posix_local_secret_file_permissions_are_private(tmp_path, monkeypatch):
    monkeypatch.setattr(connections, "_is_windows", lambda: False)
    service = connections.ConnectionSettings(tmp_path)
    service.save({"openai_api_key": TEST_KEY}, allow_key_edit=True)
    secret = tmp_path / "openai.key"
    assert secret.is_file()
    if os.name != "nt":
        assert stat.S_IMODE(secret.stat().st_mode) == 0o600
    assert service.get_key() == TEST_KEY


def test_mocked_windows_storage_branch_uses_protection_helpers(tmp_path, monkeypatch):
    monkeypatch.setattr(connections, "_is_windows", lambda: True)
    protected = b"protected-DPAPI-fixture-bytes"
    calls = []

    def protect(value):
        calls.append(("protect", value))
        return protected

    def unprotect(value):
        calls.append(("unprotect", value))
        assert value == protected
        return TEST_KEY.encode()

    monkeypatch.setattr(connections, "_protect_windows", protect)
    monkeypatch.setattr(connections, "_unprotect_windows", unprotect)
    service = connections.ConnectionSettings(tmp_path)
    service.save({"openai_api_key": TEST_KEY}, allow_key_edit=True)
    assert TEST_KEY.encode() not in (tmp_path / "openai.key").read_bytes()
    assert service.get_key() == TEST_KEY
    assert ("protect", TEST_KEY.encode()) in calls
    assert ("unprotect", protected) in calls
    assert service.public()["key_storage"] == "windows_dpapi"


def test_test_connection_uses_real_boundary_and_only_lists_models(client, monkeypatch):
    calls = []

    def model_list(key):
        calls.append(key)
        return MODELS

    monkeypatch.setattr(connections, "_list_models", model_list)
    save_key(client)
    result = client.post("/api/connections/test")
    assert result.status_code == 200
    value = result.json()
    assert calls == [TEST_KEY]
    assert value["verified"] is True
    assert value["verified_at"]
    assert value["verification_kind"] == "model_list_only"
    assert set(value["available_models"]) == set(MODELS)
    assert value["model_selection_validated"] is True
    assert value["quick_model"] in MODELS and value["deep_model"] in MODELS
    assert TEST_KEY not in result.text
    assert client.get("/api/status").json()["ai_verified"] is True


@pytest.mark.parametrize("status", [401, 403, 429, None])
def test_provider_failures_are_actionable_unverified_and_never_echo_secrets(client, monkeypatch, status):
    class ProviderFailure(Exception):
        status_code = status

    def fail(key):
        raise ProviderFailure("SDK error including a sensitive value: " + key)

    monkeypatch.setattr(connections, "_list_models", fail)
    save_key(client)
    response = client.post("/api/connections/test")
    assert response.status_code in (200, 400, 401, 403, 429, 503)
    value = response.json()
    # Status codes may distinguish a failed provider test, but its result must
    # never advertise successful validation or expose the underlying SDK error.
    assert value.get("verified", False) is False
    assert TEST_KEY not in response.text
    assert "sensitive value" not in response.text
    assert value.get("error_code") or value.get("detail")
    assert client.get("/api/connections").json()["verified"] is False


def test_changing_key_invalidates_previous_model_verification(client, monkeypatch):
    monkeypatch.setattr(connections, "_list_models", lambda key: MODELS)
    save_key(client)
    assert client.post("/api/connections/test").json()["verified"] is True
    state = save_key(client, OTHER_KEY)
    assert state["verified"] is False
    assert state["model_selection_validated"] is False
    assert client.get("/api/status").json()["ai_verified"] is False


def test_unavailable_explicit_model_is_preserved_without_false_validation(client, monkeypatch):
    monkeypatch.setattr(connections, "_list_models", lambda key: MODELS)
    save_key(client, quick_model="model-not-in-provider-list", deep_model="gpt-4.1")
    value = client.post("/api/connections/test").json()
    assert value["quick_model"] == "model-not-in-provider-list"
    assert value["model_selection_validated"] is False
    assert "model-not-in-provider-list" not in value["available_models"]


def test_environment_binding_takes_priority_and_cannot_be_deleted_through_ui(client, monkeypatch):
    save_key(client)
    monkeypatch.setenv("TRADINGAGENTS_OPENAI_API_KEY", OTHER_KEY)
    before = client.get("/api/connections").json()
    assert before["key_source"] == "environment"
    assert before["key_editable"] is False
    response = client.delete("/api/connections/key")
    assert response.status_code in (200, 403, 409)
    assert client.get("/api/connections").json()["key_source"] == "environment"
    assert client.get("/api/connections").json()["key_configured"] is True
    assert os.environ["TRADINGAGENTS_OPENAI_API_KEY"] == OTHER_KEY
    assert OTHER_KEY not in response.text


def test_deleting_local_key_removes_credential_and_validation(client, monkeypatch, tmp_path):
    monkeypatch.setattr(connections, "_list_models", lambda key: MODELS)
    save_key(client)
    assert client.post("/api/connections/test").json()["verified"] is True
    response = client.delete("/api/connections/key")
    assert response.status_code == 200
    state = response.json()
    assert state["key_configured"] is False
    assert state["verified"] is False
    assert not (tmp_path / "openai.key").exists()
    assert TEST_KEY not in response.text


def test_hosted_authenticated_ui_cannot_write_a_local_api_key(tmp_path):
    password = "a-private-hosted-password"
    with TestClient(create_app(tmp_path, password=password, local_mode=False)) as client:
        assert client.get("/api/connections").status_code == 401
        headers = {"Origin": "http://testserver"}
        assert client.post("/api/login", json={"password": password}, headers=headers).status_code == 200
        response = client.put("/api/connections", json={"openai_api_key": TEST_KEY}, headers=headers)
        assert response.status_code == 403
        assert TEST_KEY not in response.text
        assert not (tmp_path / "openai.key").exists()
        assert client.get("/api/connections").json()["key_editable"] is False


def test_cross_origin_key_write_and_invalid_inputs_are_rejected_without_echo(client):
    foreign = client.put("/api/connections", json={"openai_api_key": TEST_KEY}, headers={"Origin": "https://attacker.invalid"})
    assert foreign.status_code == 403
    assert TEST_KEY not in foreign.text
    invalid = client.put("/api/connections", json={"openai_api_key": TEST_KEY, "unsupported_field": TEST_KEY})
    assert invalid.status_code == 422
    assert TEST_KEY not in invalid.text
    assert client.get("/api/connections").json()["key_configured"] is False


def test_worker_loads_saved_key_without_serializing_it_in_public_result(tmp_path, monkeypatch):
    import tradingagents.graph.trading_graph as graph_module

    from backend.worker import execute_live

    service = connections.ConnectionSettings(tmp_path)
    service.save({"openai_api_key": TEST_KEY}, allow_key_edit=True)
    monkeypatch.setenv("OPENAI_API_KEY", "")  # Restore the worker's process-local mutation after this direct boundary test.
    observed = {}

    class FakeGraph:
        def __init__(self, selected_analysts, config, callbacks=None):
            observed["key"] = os.getenv("OPENAI_API_KEY")
            observed["config"] = config

        def propagate(self, symbol, analysis_date, asset_type):
            return {"market_report": "Provider adapter test", "final_trade_decision": "Rating: Hold"}, "Hold"

    class Output:
        value = None

        def put(self, value):
            self.value = value

    monkeypatch.setattr(graph_module, "TradingAgentsGraph", FakeGraph)
    payload = {
        "symbol": "AAPL", "date": "2026-10-27", "analysts": ["market"],
        "quick_model": "gpt-4.1-mini", "deep_model": "gpt-4.1", "rounds": 1,
    }
    output = Output()
    execute_live(payload, str(tmp_path), output)
    assert output.value["ok"] is True
    assert observed["key"] == TEST_KEY
    assert TEST_KEY not in json.dumps(payload)
    assert TEST_KEY not in json.dumps(output.value)
    assert TEST_KEY not in json.dumps(observed["config"])


def test_invalid_optional_setting_does_not_partially_replace_saved_key(client, tmp_path):
    save_key(client)
    response = client.put("/api/connections", json={
        "openai_api_key": OTHER_KEY, "sec_edgar_user_agent": "not-a-valid-contact",
    })
    assert response.status_code in (400, 422)
    assert connections.ConnectionSettings(tmp_path).get_key() == TEST_KEY
    assert OTHER_KEY not in response.text


def test_live_run_automatically_rechecks_unverified_models_before_market_and_submission(client, monkeypatch):
    save_key(client)
    calls = []
    def list_models(key):
        assert key == TEST_KEY
        calls.append("models")
        return MODELS
    def market(*args, **kwargs):
        calls.append("market")
        return {"price": 100.25, "currency": "USD", "source": "Provider fixture", "mode": "live",
                "quote_as_of": "2026-10-27T20:00:00+00:00", "fetched_at": "2026-10-27T20:01:00+00:00"}
    def submit(body):
        calls.append("submit")
        assert body["quick_model"] in MODELS and body["deep_model"] in MODELS
        return {"id": "rechecked-fixture", **body, "status": "queued"}
    monkeypatch.setattr(connections, "_list_models", list_models)
    monkeypatch.setattr(client.app.state.market, "get", market)
    monkeypatch.setattr(client.app.state.manager, "submit", submit)
    response = client.post("/api/runs", json={"symbol": "AAPL"})
    assert response.status_code == 202, response.text
    assert calls == ["models", "market", "submit"]
    assert client.get("/api/connections").json()["verified"] is True


def test_live_run_rejects_models_outside_the_verified_provider_list(client, monkeypatch):
    monkeypatch.setattr(connections, "_list_models", lambda key: MODELS)
    save_key(client)
    assert client.post("/api/connections/test").json()["verified"] is True
    calls = []
    monkeypatch.setattr(client.app.state.manager, "submit", lambda body: calls.append(body))
    response = client.post("/api/runs", json={"symbol": "AAPL", "quick_model": "unlisted-model"})
    assert response.status_code == 422
    assert calls == []


def test_live_run_fails_before_submission_when_real_quotes_are_unavailable(client, monkeypatch):
    from backend.market import MarketUnavailable

    monkeypatch.setattr(connections, "_list_models", lambda key: MODELS)
    save_key(client)
    assert client.post("/api/connections/test").json()["verified"] is True
    calls = []
    monkeypatch.setattr(client.app.state.manager, "submit", lambda body: calls.append(body))

    def unavailable(*args, **kwargs):
        raise MarketUnavailable("Real quote could not be checked")

    monkeypatch.setattr(client.app.state.market, "get", unavailable)
    response = client.post("/api/runs", json={"symbol": "AAPL"})
    assert response.status_code == 503
    assert calls == []
    assert response.json()["error_code"] == "market_data_unavailable"
    assert response.json()["error_stage"] == "market_preflight"
    assert response.json()["error_action"]


def test_live_run_snapshot_and_provenance_are_public_and_quote_time_is_distinct(client, monkeypatch):
    monkeypatch.setattr(connections, "_list_models", lambda key: MODELS)
    save_key(client)
    assert client.post("/api/connections/test").json()["verified"] is True
    captured = []

    def submit(body):
        captured.append(body)
        return {"id": "public-run-fixture", **body, "status": "queued"}

    monkeypatch.setattr(client.app.state.manager, "submit", submit)
    monkeypatch.setattr(client.app.state.market, "get", lambda *args, **kwargs: {
        "price": 100.25, "currency": "USD", "source": "Provider fixture", "mode": "live",
        "quote_as_of": "2026-10-26T20:00:00+00:00", "quote_date": "2026-10-26",
        "fetched_at": "2026-10-27T12:00:00+00:00", "price_type": "regular session quote",
    })
    response = client.post("/api/runs", json={"symbol": "AAPL", "date": "2026-10-27"})
    assert response.status_code == 202
    body = captured[0]
    assert body["quick_model"] == "gpt-4.1-mini" and body["deep_model"] == "gpt-4.1"
    assert body["data_snapshot"]["quote_as_of"] == "2026-10-26T20:00:00+00:00"
    assert body["date"] == "2026-10-27"
    assert body["provenance"]["provider"] == "openai"
    assert body["provenance"]["models_list_verified_at"]
    assert TEST_KEY not in response.text
    assert TEST_KEY not in json.dumps(body)


def test_sec_contact_is_required_for_fundamentals_but_not_technical_research(client, monkeypatch):
    monkeypatch.setattr(connections, "_list_models", lambda key: MODELS)
    save_key(client)
    assert client.post("/api/connections/test").json()["verified"] is True
    captured = []
    monkeypatch.setattr(client.app.state.manager, "submit", lambda body: captured.append(body) or {"id": "fixture", **body})
    monkeypatch.setattr(client.app.state.market, "get", lambda *args, **kwargs: {
        "price": 100.25, "currency": "USD", "source": "Provider fixture", "mode": "live",
        "quote_as_of": "2026-10-26T20:00:00+00:00", "fetched_at": "2026-10-27T12:00:00+00:00",
    })
    missing = client.post("/api/runs", json={"symbol": "AAPL", "analysts": ["fundamentals"]})
    assert missing.status_code == 422
    assert captured == []
    assert client.post("/api/runs", json={"symbol": "AAPL", "analysts": ["market"]}).status_code == 202
    contact = client.put("/api/connections", json={"sec_edgar_user_agent": "Test Operator operator@example.test"})
    assert contact.status_code == 200
    assert client.post("/api/runs", json={"symbol": "AAPL", "analysts": ["fundamentals"]}).status_code == 202


def test_old_provider_verification_expires_without_losing_saved_key(client, monkeypatch, tmp_path):
    monkeypatch.setattr(connections, "_list_models", lambda key: MODELS)
    save_key(client)
    assert client.post("/api/connections/test").json()["verified"] is True
    path = tmp_path / "config.json"
    config = json.loads(path.read_text())
    config["verification"]["checked_at"] = (datetime.now(UTC) - timedelta(days=2)).isoformat()
    path.write_text(json.dumps(config))
    value = client.get("/api/connections").json()
    assert value["key_configured"] is True
    assert value["verified"] is False and value["model_selection_validated"] is False
    assert client.get("/api/status").json()["ai_verified"] is False
    calls = []
    monkeypatch.setattr(connections, "_list_models", lambda key: calls.append("models") or MODELS)
    monkeypatch.setattr(client.app.state.market, "get", lambda *args, **kwargs: {
        "price": 100.25, "currency": "USD", "source": "Provider fixture", "mode": "live",
        "quote_as_of": "2026-10-27T20:00:00+00:00", "fetched_at": "2026-10-27T20:01:00+00:00",
    })
    monkeypatch.setattr(client.app.state.manager, "submit", lambda body: {"id": "expired-refresh", **body, "status": "queued"})
    assert client.post("/api/runs", json={"symbol": "AAPL"}).status_code == 202
    assert calls == ["models"]
    assert client.get("/api/connections").json()["verified"] is True
    assert connections.ConnectionSettings(tmp_path).get_key() == TEST_KEY


def test_concurrent_key_change_cannot_verify_the_replacement_credential(client, monkeypatch, tmp_path):
    save_key(client)

    def replace_while_listing(key):
        assert key == TEST_KEY
        connections.ConnectionSettings(tmp_path).save({"openai_api_key": OTHER_KEY}, allow_key_edit=True)
        return MODELS

    monkeypatch.setattr(connections, "_list_models", replace_while_listing)
    response = client.post("/api/connections/test")
    assert response.status_code >= 400
    assert TEST_KEY not in response.text and OTHER_KEY not in response.text
    value = client.get("/api/connections").json()
    assert value["verified"] is False and value["model_selection_validated"] is False
    assert connections.ConnectionSettings(tmp_path).get_key() == OTHER_KEY
