import json
from concurrent.futures import ThreadPoolExecutor
from types import SimpleNamespace
from uuid import uuid4

from langchain_core.messages import AIMessage, HumanMessage, ToolMessage
from langchain_core.tools import tool

from backend.tool_observer import ToolObserver


def call(observer, name, output, *, error=False):
    run_id = uuid4()
    observer.on_tool_start({"name": name, "description": "private-description"}, "private-input", run_id=run_id,
                           metadata={"key": "private-metadata"}, inputs={"key": "private-arguments"})
    if error:
        observer.on_tool_error(RuntimeError(output), run_id=run_id)
    else:
        observer.on_tool_end(output, run_id=run_id)


def test_callback_collector_keeps_only_safe_names_and_outcome_markers():
    observer = ToolObserver()
    call(observer, "get_stock_data", "Date,Close\n2026-10-27,123.45 sk-private-value")
    call(observer, "get_news", "DATA_UNAVAILABLE: https://secret.example/?token=private-value")
    call(observer, "sk-private-tool-name", "secret output")
    summary = observer.summary(["market", "news"])
    assert summary["attempted_tools"] == ["get_stock_data", "get_news", "unrecognized_tool"]
    assert summary["unavailable_tools"] == ["get_news"]
    assert summary["observation_method"] == "graph_tool_callbacks"
    # Check the collector itself too, not just its public summary.
    retained = repr(vars(observer)) + json.dumps(summary)
    for secret in ("private-value", "secret.example", "private-input", "private-description", "private-metadata", "private-arguments", "private-tool-name", "123.45"):
        assert secret not in retained


def test_callback_toolmessage_error_empty_and_financial_prose_are_distinct():
    observer = ToolObserver()
    call(observer, "get_stock_data", ToolMessage(content="private error body", status="error", tool_call_id="unused"))
    call(observer, "get_news", "   ")
    call(observer, "get_indicators", "A company's error rate declined; RSI is 52.")
    summary = observer.summary(["market", "news"])
    assert summary["unavailable_tools"] == ["get_stock_data"]
    assert summary["empty_output_tools"] == ["get_news"]
    assert "get_indicators" not in summary["unavailable_tools"]


def test_error_callback_never_reads_exception_text():
    class SensitiveError(Exception):
        def __str__(self):
            raise AssertionError("Do not stringify provider errors")

    observer = ToolObserver()
    run_id = uuid4()
    observer.on_tool_start({"name": "get_news"}, "", run_id=run_id)
    observer.on_tool_error(SensitiveError(), run_id=run_id)
    assert observer.summary(["news"])["unavailable_tools"] == ["get_news"]


def test_parallel_calls_are_counted_without_retaining_bodies():
    observer = ToolObserver()
    with ThreadPoolExecutor(max_workers=8) as executor:
        list(executor.map(lambda _: call(observer, "get_stock_data", "private CSV data"), range(100)))
    summary = observer.summary(["market"])
    assert summary["tool_observations"] == [{"tool": "get_stock_data", "calls": 100, "unavailable_calls": 0, "empty_calls": 0}]
    assert not observer._inflight
    assert "private CSV" not in repr(vars(observer))


def test_limits_and_unfinished_tools_are_explicit_not_false_completeness():
    observer = ToolObserver(max_records=2, max_inflight=1)
    observer.on_tool_start({"name": "get_stock_data"}, "", run_id=uuid4())
    observer.on_tool_start({"name": "get_news"}, "", run_id=uuid4())
    for _ in range(3):
        observer.on_tool_end(ToolMessage(name="get_stock_data", content="data", tool_call_id="unused"), run_id=uuid4())
    summary = observer.summary(["market"])
    assert len(observer._records) == 2 and len(observer._inflight) == 1
    assert summary["summary_status"] == "incomplete" and summary["observation_truncated"]
    assert any("terminal event" in text for text in summary["limitations"])


def test_real_langchain_tool_callbacks_reach_collector():
    @tool("get_stock_data")
    def stock_data(symbol: str) -> str:
        """Return an offline test price series."""
        return "Date,Close\n2026-10-27,123.45"

    observer = ToolObserver()
    stock_data.invoke({"symbol": "XYZ"}, config={"callbacks": [observer]})
    assert observer.summary(["market"])["attempted_tools"] == ["get_stock_data"]


def test_private_upstream_analyst_subgraph_tools_are_observed_despite_report_only_output():
    from tradingagents.graph.setup import _analyst_graph

    @tool("get_stock_data")
    def stock_data(symbol: str) -> str:
        """Return an offline test price series."""
        return "Date,Close\n2026-10-27,123.45"

    def agent(state):
        if isinstance(state["messages"][-1], ToolMessage):
            return {"messages": [AIMessage(content="Offline report")], "market_report": "Offline report"}
        return {"messages": [AIMessage(content="", tool_calls=[{"name": "get_stock_data", "args": {"symbol": "XYZ"}, "id": "offline-tool-call", "type": "tool_call"}])], "market_report": ""}

    spec = SimpleNamespace(key="market", report_key="market_report", agent_node="Market Analyst", tools=(stock_data,))
    graph = _analyst_graph(spec, agent, 6)
    observer = ToolObserver()
    result = graph.with_config({"callbacks": [observer]}).invoke({"messages": [HumanMessage(content="XYZ")]})
    assert result == {"market_report": "Offline report"}
    assert observer.summary(["market"])["attempted_tools"] == ["get_stock_data"]
    assert observer.summary(["market"])["summary_status"] == "observed_unverified"
