import json
from types import SimpleNamespace

import pytest
from langchain_core.messages import AIMessage, ToolMessage

from backend.coverage import summarize_source_coverage


def tool(name, content, status="success"):
    return ToolMessage(name=name, content=content, tool_call_id="call-test", status=status)


def test_valid_tool_output_is_observed_not_verified():
    messages = [AIMessage(content="DATA_UNAVAILABLE: prose is not a tool result"), tool("get_stock_data", "Date,Close\n2026-10-27,217.89")]
    result = summarize_source_coverage(messages, ["market"])
    assert result["attempted_tools"] == ["get_stock_data"]
    assert result["unavailable_tools"] == []
    assert result["summary_status"] == "observed_unverified"
    assert result["analyst_coverage"]["market"]["observed_tools"] == ["get_stock_data"]
    assert "independently verify" in result["limitations"][0]


@pytest.mark.parametrize("content", [
    "DATA_UNAVAILABLE: provider could not answer", "NO_DATA_AVAILABLE: symbol not covered",
    "Error fetching Yahoo data", "No news found for NVDA between these dates",
    '<Yahoo Finance news unavailable for 2026-10-20..2026-10-27: sample missing>',
    '{"error":{"message":"sk-private-value https://secret.example/?token=private"}}',
    '{"success":false,"message":"private provider detail"}',
    '```json\n{"status":"unavailable"}\n```',
    [{"type": "text", "text": "DATA_UNAVAILABLE: no macro data"}],
])
def test_sentinel_and_structured_errors_do_not_leak_bodies(content):
    result = summarize_source_coverage([tool("get_news", content)], ["news"])
    assert result["unavailable_tools"] == ["get_news"]
    assert result["summary_status"] == "incomplete"
    encoded = json.dumps(result)
    for forbidden in ("sk-private-value", "secret.example", "private provider detail"):
        assert forbidden not in encoded


@pytest.mark.parametrize("text", [
    "Revenue grew despite an error in the earlier earnings estimate.",
    "The company's Error Rate metric fell to 1%.",
    "News: vendor error costs the company $5m.\nThe source returned real news.",
    '{"error":null,"success":true,"price":217.89}',
])
def test_financial_prose_error_words_do_not_mean_provider_failure(text):
    result = summarize_source_coverage([tool("get_news", text)], ["news"])
    assert result["unavailable_tools"] == []


def test_tool_status_error_and_mixed_retries_are_visible():
    result = summarize_source_coverage([
        tool("get_indicators", "private detail", status="error"),
        tool("get_indicators", "RSI: 52"),
    ], ["market"])
    assert result["tool_observations"] == [{"tool": "get_indicators", "calls": 2, "unavailable_calls": 1, "empty_calls": 0}]
    assert "private detail" not in json.dumps(result)


def test_nested_parallel_messages_and_unknown_names_are_bounded_and_safe():
    messages = [[tool("get_stock_data", "history")], [{"role": "tool", "name": "sk-private-tool-name", "content": "secret"}]]
    result = summarize_source_coverage(messages, ["market", "unexpected-secret-analyst"])
    assert result["attempted_tools"] == ["get_stock_data", "unrecognized_tool"]
    assert "sk-private" not in json.dumps(result)
    assert "unexpected-secret" not in json.dumps(result)


def test_no_tool_results_never_means_sources_verified():
    result = summarize_source_coverage([AIMessage(content="All sources are verified")], ["market"])
    assert result["no_tools_warning"] is True
    assert result["summary_status"] == "incomplete"
    assert result["attempted_tools"] == []


def test_social_prefetch_is_unknown_not_an_automatic_failed_fetch():
    result = summarize_source_coverage([], ["social"])
    assert result["unavailable_tools"] == []
    assert result["analyst_coverage"]["social"]["prefetch_not_observed"] is True
    assert any("prefetches" in message for message in result["limitations"])


def test_optional_configuration_flags_only_apply_to_selected_analysts():
    source_config = {"fred": False, "sec_edgar_contact": False, "arbitrary": "sk-secret"}
    market = summarize_source_coverage([tool("get_stock_data", "rows")], ["market"], configured_sources=source_config)
    assert not any("FRED" in message or "SEC EDGAR contact" in message for message in market["limitations"])
    extra = summarize_source_coverage([tool("get_news", "headlines")], ["news", "fundamentals"], configured_sources=source_config)
    assert any("FRED" in message for message in extra["limitations"])
    assert any("SEC EDGAR contact" in message for message in extra["limitations"])
    assert "sk-secret" not in json.dumps(extra)


def test_empty_output_is_distinct_from_nonempty_and_source_errors():
    result = summarize_source_coverage([tool("get_news", "  ")], ["news"])
    assert result["empty_output_tools"] == ["get_news"]
    assert result["unavailable_tools"] == []
    assert result["summary_status"] == "incomplete"


def test_object_messages_need_explicit_tool_type():
    message = SimpleNamespace(type="tool", name="get_balance_sheet", status="success", content={"Assets": 100})
    result = summarize_source_coverage([message, SimpleNamespace(content="DATA_UNAVAILABLE", name="get_news")], ["fundamentals"])
    assert result["attempted_tools"] == ["get_balance_sheet"]


def test_one_analysts_output_does_not_establish_anothers_sources():
    result = summarize_source_coverage([tool("get_stock_data", "price rows")], ["market", "news"])
    assert result["summary_status"] == "incomplete"
    assert result["unobserved_analysts"] == ["news"]
    assert any("news/macro" in message for message in result["limitations"])
