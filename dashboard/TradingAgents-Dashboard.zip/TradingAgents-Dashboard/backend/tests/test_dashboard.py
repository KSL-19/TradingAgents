import json
import socket
import time
from concurrent.futures import ThreadPoolExecutor
from decimal import Decimal

import pytest
from fastapi.testclient import TestClient

from backend.app import create_app
from backend.market import MarketUnavailable
from backend.store import INITIAL_CASH_CENTS, LedgerError, Store


@pytest.fixture(autouse=True)
def isolate_network_and_credentials(monkeypatch):
    for name in ("DASHBOARD_PASSWORD", "DASHBOARD_LOCAL_MODE", "DASHBOARD_PUBLIC_ORIGIN", "DASHBOARD_SECURE_COOKIES", "OPENAI_API_KEY", "TRADINGAGENTS_OPENAI_API_KEY"):
        monkeypatch.delenv(name, raising=False)

    def refuse(*args, **kwargs):
        raise AssertionError("Tests must not make external network requests")

    monkeypatch.setattr(socket.socket, "connect", refuse)
    monkeypatch.setattr(socket.socket, "connect_ex", refuse)


@pytest.fixture
def client(tmp_path):
    with TestClient(create_app(tmp_path, local_mode=True)) as test_client:
        yield test_client


def quote(price="10.05", currency="USD", mode="demo"):
    return {"price": float(price), "currency": currency, "as_of": "2026-10-27", "source": "test fixture", "mode": mode}


def test_startup_requires_explicit_security_configuration(tmp_path):
    with pytest.raises(RuntimeError, match="Set DASHBOARD_PASSWORD"), TestClient(create_app(tmp_path)):
        pass
    with pytest.raises(RuntimeError, match="12 characters"), TestClient(create_app(tmp_path, password="short")):
        pass


def test_cookie_login_authorization_logout_and_csrf(tmp_path):
    app = create_app(tmp_path, password="a-long-private-password")
    with TestClient(app) as client:
        assert client.get("/api/health").status_code == 200
        assert client.get("/api/status").json()["authenticated"] is False
        assert client.get("/api/portfolio").status_code == 401
        assert client.post("/api/login", json={"password": "bad"}).status_code == 403
        headers = {"Origin": "http://testserver"}
        assert client.post("/api/login", json={"password": "bad"}, headers=headers).status_code == 401
        result = client.post("/api/login", json={"password": "a-long-private-password"}, headers=headers)
        assert result.status_code == 200
        cookie = result.headers["set-cookie"].lower()
        assert "httponly" in cookie and "samesite=strict" in cookie
        assert client.get("/api/portfolio").status_code == 200
        assert client.post("/api/watchlist", json={"symbol": "TSLA"}, headers={"Origin": "https://attacker.invalid"}).status_code == 403
        assert client.post("/api/watchlist", json={"symbol": "TSLA"}, headers={"Sec-Fetch-Site": "cross-site", **headers}).status_code == 403
        assert client.post("/api/logout", headers=headers).status_code == 200
        assert client.get("/api/watchlist").status_code == 401


def test_login_throttled_without_leaking_password(tmp_path):
    with TestClient(create_app(tmp_path, password="a-long-private-password")) as client:
        for _ in range(10):
            response = client.post("/api/login", json={"password": "wrong-secret"}, headers={"Origin": "http://testserver"})
            assert response.status_code == 401
            assert "wrong-secret" not in response.text
        assert client.post("/api/login", json={"password": "a-long-private-password"}, headers={"Origin": "http://testserver"}).status_code == 429


def test_proxy_public_origin_and_secure_cookie(tmp_path, monkeypatch):
    monkeypatch.setenv("DASHBOARD_PUBLIC_ORIGIN", "https://desk.example.com")
    monkeypatch.setenv("DASHBOARD_SECURE_COOKIES", "1")
    with TestClient(create_app(tmp_path, password="a-long-private-password")) as client:
        response = client.post("/api/login", json={"password": "a-long-private-password"}, headers={"Origin": "https://desk.example.com"})
        assert response.status_code == 200
        assert "Secure" in response.headers["set-cookie"]
        assert client.post("/api/login", json={"password": "a-long-private-password"}, headers={"Origin": "http://testserver"}).status_code == 403


def test_local_mode_rejects_public_host(client):
    assert client.get("/api/status", headers={"Host": "attacker.invalid"}).status_code == 403


def test_synthetic_market_explicit_and_consistent_across_periods(client):
    short = client.get("/api/market/aapl?mode=demo&period=1mo").json()
    long = client.get("/api/market/AAPL?mode=demo&period=1y").json()
    assert short["mode"] == "demo" and short["source"] == "Synthetic demo data"
    assert short["price"] == long["price"]
    assert short["as_of"] == long["as_of"]
    assert len(short["bars"]) == 23 and len(long["bars"]) == 252
    assert all(bar["low"] <= bar["close"] <= bar["high"] for bar in long["bars"])


def test_live_market_error_never_substitutes_synthetic_data(client, monkeypatch):
    def unavailable(*args, **kwargs):
        raise MarketUnavailable("Provider access unavailable; no demo prices were substituted.")
    monkeypatch.setattr(client.app.state.market, "get", unavailable)
    response = client.get("/api/market/AAPL?mode=live")
    assert response.status_code == 503
    assert "bars" not in response.json()


def test_run_refuses_live_without_credentials(client):
    assert client.get("/api/status").json()["live_available"] is False
    response = client.post("/api/runs", json={"symbol": "AAPL", "mode": "live"})
    assert response.status_code == 503
    assert "TRADINGAGENTS_OPENAI_API_KEY" in response.json()["detail"]
    assert client.get("/api/runs").json() == {"runs": []}


@pytest.mark.parametrize("body", [
    {"symbol": "../../secret"}, {"symbol": "AAPL", "date": "2099-01-01"},
    {"symbol": "AAPL", "date": "20261027"}, {"symbol": "AAPL", "rounds": 4},
    {"symbol": "AAPL", "analysts": []}, {"symbol": "AAPL", "analysts": ["market", "market"]},
    {"symbol": "AAPL", "api_key": "must-not-be-accepted"},
])
def test_run_input_validation(client, body):
    assert client.post("/api/runs", json=body).status_code == 422


def test_demo_run_persists_public_reports_and_downloads(client):
    response = client.post("/api/runs", json={"symbol": "AAPL", "mode": "demo", "analysts": ["market", "news"]})
    assert response.status_code == 202
    run_id = response.json()["id"]
    assert client.post("/api/runs", json={"symbol": "MSFT", "mode": "demo"}).status_code == 409
    for _ in range(60):
        result = client.get(f"/api/runs/{run_id}").json()
        if result["status"] in ("completed", "failed"):
            break
        time.sleep(0.03)
    assert result["status"] == "completed", result
    assert "synthetic data" in result["reports"]["market_report"]
    assert "No external sources" in result["reports"]["news_report"]
    assert result["rating"] in ("Overweight", "Underweight", "Hold")
    attachment = client.get(f"/api/runs/{run_id}/report")
    assert attachment.status_code == 200
    assert "attachment" in attachment.headers["content-disposition"]
    assert "DEMONSTRATION" in attachment.text
    assert client.get("/api/runs?mode=live").json()["runs"] == []
    assert client.get("/api/runs?mode=demo").json()["runs"][0]["id"] == run_id


def test_order_uses_server_price_and_rejects_client_price(client, monkeypatch):
    monkeypatch.setattr(client.app.state.market, "get", lambda *a, **k: quote())
    forged = {"symbol": "AAPL", "side": "buy", "quantity": 3, "mode": "demo", "price": 0.01}
    assert client.post("/api/orders", json=forged).status_code == 422
    forged.pop("price")
    response = client.post("/api/orders", json=forged)
    assert response.status_code == 201
    result = response.json()
    assert result["order"]["price"] == 10.05
    assert result["order"]["total"] == 30.15
    assert result["portfolio"]["cash"] == 99969.85
    assert result["portfolio"]["equity"] == 100000
    assert result["portfolio"]["positions"][0]["quantity"] == 3
    live = client.get("/api/portfolio?mode=live").json()
    assert live["cash"] == 100000 and live["positions"] == []


def test_fractional_orders_weighted_basis_and_realized_pnl(tmp_path):
    store = Store(tmp_path)
    store.fill("demo", "AAPL", "buy", Decimal(2), quote("10"))
    store.fill("demo", "AAPL", "buy", Decimal(1), quote("13"))
    store.fill("demo", "AAPL", "sell", Decimal("0.5"), quote("14"))
    account, positions, _ = store.account("demo")
    assert account["cash_cents"] == INITIAL_CASH_CENTS - 3300 + 700
    assert account["realized_cents"] == 150
    assert positions[0]["quantity"] == "2.5"
    assert positions[0]["cost_basis_cents"] == 2750
    store.fill("demo", "AAPL", "sell", Decimal("2.5"), quote("12"))
    account, positions, _ = store.account("demo")
    assert positions == [] and account["realized_cents"] == 400


def test_overdraft_oversell_currency_rejections_are_atomic(tmp_path):
    store = Store(tmp_path)
    for currency in ("GBP", None, ""):
        with pytest.raises(LedgerError, match="USD"):
            store.fill("demo", "AZN.L", "buy", Decimal(1), quote(currency=currency))
    with pytest.raises(LedgerError, match="Insufficient paper cash"):
        store.fill("demo", "AAPL", "buy", Decimal(100000), quote())
    with pytest.raises(LedgerError, match="Insufficient shares"):
        store.fill("demo", "AAPL", "sell", Decimal(1), quote())
    account, positions, orders = store.account("demo")
    assert account["cash_cents"] == INITIAL_CASH_CENTS and positions == [] and orders == []


def test_simultaneous_orders_cannot_overspend(tmp_path):
    store = Store(tmp_path)
    def buy(_):
        try:
            store.fill("demo", "AAPL", "buy", Decimal(1), quote("60000"))
            return True
        except LedgerError:
            return False
    with ThreadPoolExecutor(max_workers=2) as pool:
        results = list(pool.map(buy, range(2)))
    assert sum(results) == 1
    account, positions, orders = store.account("demo")
    assert account["cash_cents"] == 4_000_000
    assert positions[0]["quantity"] == "1" and len(orders) == 1


def test_currency_loss_marks_valuation_unavailable(client, monkeypatch):
    monkeypatch.setattr(client.app.state.market, "get", lambda *a, **k: quote())
    assert client.post("/api/orders", json={"symbol": "AAPL", "side": "buy", "quantity": 1}).status_code == 201
    monkeypatch.setattr(client.app.state.market, "get", lambda *a, **k: quote(currency=None))
    result = client.get("/api/portfolio").json()
    assert result["equity"] is None and result["unrealized_pnl"] is None
    assert result["quote_errors"] == ["AAPL"]
    assert result["positions"][0]["market_value"] is None


def test_watchlist_and_ledger_survive_restart_without_reseeding(tmp_path):
    store = Store(tmp_path)
    for symbol in store.watchlist():
        store.remove_symbol(symbol)
    store.fill("demo", "AAPL", "buy", Decimal(2), quote())
    reopened = Store(tmp_path)
    assert reopened.watchlist() == []
    assert reopened.account("demo")[0]["cash_cents"] == INITIAL_CASH_CENTS - 2010
    assert len(reopened.account("demo")[2]) == 1


def test_completed_runs_preserved_and_interrupted_run_failed_on_restart(tmp_path):
    store = Store(tmp_path)
    base = {"symbol": "AAPL", "mode": "demo", "created_at": "2026-10-27", "updated_at": "2026-10-27"}
    store.save_run(dict(base, id="complete", status="completed", reports={"market_report": "saved"}))
    store.save_run(dict(base, id="incomplete", status="running"))
    reopened = Store(tmp_path)
    assert reopened.get_run("complete")["reports"] == {"market_report": "saved"}
    assert reopened.get_run("incomplete")["status"] == "failed"
    assert "server restarted" in reopened.get_run("incomplete")["error"]


def test_nonfinite_and_negative_order_quantities_rejected(client):
    for quantity in (0, -1, "NaN", "Infinity", "0.0000001"):
        assert client.post("/api/orders", json={"symbol": "AAPL", "side": "buy", "quantity": quantity}).status_code == 422


def test_validation_errors_never_echo_unsupported_credentials(client):
    value = "an-accidentally-submitted-private-key"
    result = client.post("/api/runs", json={"symbol": "AAPL", "api_key": value})
    assert result.status_code == 422
    assert value not in result.text


def test_live_worker_calls_upstream_graph_and_returns_public_reports_only(tmp_path, monkeypatch):
    import tradingagents.graph.trading_graph as graph_module

    from backend.worker import execute_live

    calls = {}
    class FakeGraph:
        def __init__(self, selected_analysts, config):
            calls.update(analysts=selected_analysts, config=config)
        def propagate(self, symbol, analysis_date, asset_type):
            calls.update(symbol=symbol, date=analysis_date, asset_type=asset_type)
            return {
                "market_report": "A real adapter boundary result", "final_trade_decision": "Rating: Hold",
                "messages": [{"content": "must-not-cross-the-API-boundary"}],
                "secret": "must-not-cross-the-API-boundary",
            }, "Hold"
    class Output:
        value = None
        def put(self, value):
            self.value = value
    monkeypatch.setattr(graph_module, "TradingAgentsGraph", FakeGraph)
    monkeypatch.setenv("TRADINGAGENTS_OPENAI_API_KEY", "test-only-key-value")
    output = Output()
    execute_live({"symbol": "AAPL", "date": "2026-10-27", "analysts": ["market"], "quick_model": "quick-test", "deep_model": "deep-test", "rounds": 2}, str(tmp_path), output)
    assert output.value["ok"] is True and output.value["rating"] == "Hold"
    assert calls["symbol"] == "AAPL" and calls["asset_type"] == "stock"
    assert calls["config"]["quick_think_llm"] == "quick-test"
    assert calls["config"]["max_debate_rounds"] == 2 and calls["config"]["max_tool_rounds"] == 6
    assert str(tmp_path) in calls["config"]["results_dir"]
    serialized = json.dumps(output.value)
    assert "must-not-cross" not in serialized and "test-only-key-value" not in serialized
