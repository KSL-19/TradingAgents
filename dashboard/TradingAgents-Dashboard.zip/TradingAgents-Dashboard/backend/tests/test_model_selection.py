"""Account-observed model selection tests; no provider traffic or real keys."""

import hashlib
import json
from datetime import UTC, datetime, timedelta

import pytest

from backend import connections
from backend.catalog import is_research_candidate, model_catalog

KEY = "sk-proj-only-a-test-fixture-not-a-real-key-1234567890"


@pytest.fixture
def service(tmp_path, monkeypatch):
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    monkeypatch.delenv("TRADINGAGENTS_OPENAI_API_KEY", raising=False)
    value = connections.ConnectionSettings(tmp_path)
    value.save({"openai_api_key": KEY}, allow_key_edit=True)
    return value


@pytest.mark.parametrize("model", [
    "text-embedding-3-large", "gpt-4o-audio-preview", "gpt-image-1", "dall-e-3",
    "whisper-1", "tts-1-hd", "omni-moderation-latest", "gpt-4o-realtime-preview",
    "gpt-4o-mini-search-preview", "o3-deep-research", "computer-use-preview",
    "davinci-002", "babbage-002", "gpt-5-codex", "bad id with spaces",
])
def test_non_research_modalities_do_not_become_model_choices(model):
    assert not is_research_candidate(model)
    assert model_catalog([model])["model_options"] == []


def test_modern_families_only_appear_when_returned_by_the_account():
    models = ["gpt-4.1", "gpt-6-sol", "gpt-6-astra", "gpt-6-luna", "text-embedding-3-large"]
    result = model_catalog(models)
    assert result["recommended_quick_model"] == "gpt-6-sol"
    assert result["recommended_deep_model"] == "gpt-6-astra"
    assert result["unavailable_requested_options"] == []
    assert {option["id"] for option in result["model_options"]} == set(models) - {"text-embedding-3-large"}
    assert all(option["capability_status"] == "listed_not_generation_tested" for option in result["model_options"])


def test_missing_families_are_not_invented_or_claimed_available():
    result = model_catalog(["gpt-4.1-mini", "gpt-4.1"])
    assert result["recommended_quick_model"] == "gpt-4.1-mini"
    assert result["recommended_deep_model"] == "gpt-4.1"
    assert {option["family"] for option in result["unavailable_requested_options"]} == {"Sol", "Astra"}
    assert not any(option["family"] in ("Sol", "Astra") for option in result["model_options"])
    assert model_catalog([], observed=False)["unavailable_requested_options"] == []


def test_future_versions_are_ranked_only_if_the_exact_id_was_observed():
    ids = ["gpt-6-sol", "gpt-6.1-sol", "gpt-6-astra", "gpt-6.2-astra"]
    result = model_catalog(ids)
    assert result["recommended_quick_model"] == "gpt-6.1-sol"
    assert result["recommended_deep_model"] == "gpt-6.2-astra"
    assert {option["id"] for option in result["model_options"]} == set(ids)


def test_custom_returned_model_remains_selectable_without_capability_promise():
    result = model_catalog(["project-research-chat-v2"])
    assert result["recommended_quick_model"] == "project-research-chat-v2"
    assert result["model_options"][0]["family"] == "Other"
    assert result["model_options"][0]["capability_status"] == "listed_not_generation_tested"


def test_unqueried_connection_does_not_show_shipped_models_as_usable(service):
    public = service.public()
    assert public["quick_model"] == public["deep_model"] == ""
    assert public["model_options"] == []
    assert public["recommended_quick_model"] is None
    assert public["unavailable_requested_options"] == []
    assert public["can_attempt_analysis"] is True
    assert public["requires_reverification"] is True


def test_discovery_migrates_only_automatic_legacy_defaults(service, monkeypatch):
    service._write_config({"quick_model": "gpt-4.1-mini", "deep_model": "gpt-4.1"})
    monkeypatch.setattr(connections, "_list_models", lambda key: ["gpt-6-sol", "gpt-6-astra", "gpt-4.1"])
    result = service.test_connection()
    assert result["quick_model"] == "gpt-6-sol"
    assert result["deep_model"] == "gpt-6-astra"
    assert result["model_selection_validated"] is True
    assert KEY not in json.dumps(result)


def test_explicit_models_are_preserved_until_recommendation_action(service, monkeypatch):
    service.save({"quick_model": "gpt-4.1", "deep_model": "gpt-4.1"}, allow_key_edit=True)
    monkeypatch.setattr(connections, "_list_models", lambda key: ["gpt-6-sol", "gpt-6-astra", "gpt-4.1"])
    first = service.test_connection()
    assert first["quick_model"] == first["deep_model"] == "gpt-4.1"
    selected = service.use_recommended_models()
    assert selected["quick_model"] == "gpt-6-sol"
    assert selected["deep_model"] == "gpt-6-astra"
    assert selected["model_selection_validated"] is True


def test_expired_successful_listing_keeps_choices_and_can_retry_on_run(service, monkeypatch):
    monkeypatch.setattr(connections, "_list_models", lambda key: ["gpt-6-sol", "gpt-6-astra"])
    service.test_connection()
    config = service._read_config()
    config["verification"]["checked_at"] = (datetime.now(UTC) - timedelta(days=2)).isoformat()
    service._write_config(config)
    result = service.public()
    assert result["verified"] is False
    assert result["verification_expired"] is True
    assert result["requires_reverification"] is True
    assert result["can_attempt_analysis"] is True
    assert len(result["model_options"]) == 2
    assert result["quick_model"] == "gpt-6-sol"


def test_listed_embedding_cannot_validate_an_explicit_research_selection(service, monkeypatch):
    service.save({"quick_model": "text-embedding-3-large", "deep_model": "gpt-6-sol"}, allow_key_edit=True)
    monkeypatch.setattr(connections, "_list_models", lambda key: ["text-embedding-3-large", "gpt-6-sol"])
    result = service.test_connection()
    assert result["verified"] is True
    assert result["model_selection_validated"] is False
    assert result["selection_issues"][0]["code"] == "model_not_research_candidate"
    assert result["can_attempt_analysis"] is False


def test_no_generation_models_has_actionable_message_not_a_legacy_fallback(service, monkeypatch):
    monkeypatch.setattr(connections, "_list_models", lambda key: ["gpt-image-1", "text-embedding-3-large"])
    result = service.test_connection()
    assert result["verified"] is True
    assert result["model_selection_validated"] is False
    assert result["quick_model"] == result["deep_model"] == ""
    assert "no research model" in result["message"]
    assert result["model_options"] == []
    with pytest.raises(connections.ProviderConnectionError, match="no research model"):
        service.use_recommended_models()


def test_credential_accidentally_pasted_as_model_is_never_saved_or_echoed(service):
    with pytest.raises(connections.ProviderConnectionError, match="model ID"):
        service.save({"quick_model": KEY}, allow_key_edit=True)
    assert KEY not in service.config_path.read_text()
    # Older versions could have saved such a value; public metadata must redact it.
    service._write_config({"quick_model": KEY, "deep_model": "gpt-6-sol"})
    assert service.public()["quick_model"] == ""
    assert KEY not in json.dumps(service.public())


def probe_result():
    return {
        "verification_kind": "generation_probe", "success": True, "request_count": 2,
        "message": "Both model checks completed.",
        "results": [
            {"role": "quick", "model": "gpt-6-sol", "status": "passed", "check": "tool_call", "message": "Tool calling succeeded."},
            {"role": "deep", "model": "gpt-6-astra", "status": "passed", "check": "structured_output", "message": "Structured output succeeded."},
        ],
    }


def test_execution_test_records_only_safe_metadata_for_selected_identity(service, monkeypatch):
    monkeypatch.setattr(connections, "_list_models", lambda key: ["gpt-6-sol", "gpt-6-astra"])
    service.test_connection()
    metadata = probe_result()
    metadata["raw_response"] = KEY
    metadata["message"] += " " + KEY
    recorded = service.record_execution_test(metadata, expected_key_fingerprint=hashlib.sha256(KEY.encode()).hexdigest(),
                                             expected_models={"quick_model": "gpt-6-sol", "deep_model": "gpt-6-astra"})
    result = recorded["execution_test"]
    assert result["success"] is True and result["request_count"] == 2
    assert result["verification_kind"] == "generation_probe"
    assert KEY not in json.dumps(recorded)
    assert KEY not in service.config_path.read_text()
    assert "raw_response" not in json.dumps(recorded)
    assert "key_fingerprint" not in json.dumps(recorded)


def test_execution_test_does_not_certify_only_one_role_or_allow_changed_models(service, monkeypatch):
    monkeypatch.setattr(connections, "_list_models", lambda key: ["gpt-6-sol", "gpt-6-astra"])
    service.test_connection()
    identity = {"quick_model": "gpt-6-sol", "deep_model": "gpt-6-astra"}
    metadata = probe_result()
    metadata["results"] = metadata["results"][:1]
    state = service.record_execution_test(metadata, expected_key_fingerprint=hashlib.sha256(KEY.encode()).hexdigest(), expected_models=identity)
    assert state["execution_test"]["success"] is False
    service.save({"deep_model": "gpt-6-sol"}, allow_key_edit=True)
    assert service.public()["execution_test"] is None
    with pytest.raises(connections.ProviderConnectionError, match="model selection changed"):
        service.record_execution_test(probe_result(), expected_key_fingerprint=hashlib.sha256(KEY.encode()).hexdigest(), expected_models=identity)


def test_execution_test_cannot_verify_a_replacement_key(service, monkeypatch):
    monkeypatch.setattr(connections, "_list_models", lambda key: ["gpt-6-sol", "gpt-6-astra"])
    service.test_connection()
    service.save({"openai_api_key": "sk-proj-another-test-only-fixture-09876543210"}, allow_key_edit=True)
    with pytest.raises(connections.ProviderConnectionError, match="provider key changed"):
        service.record_execution_test(probe_result(), expected_key_fingerprint=hashlib.sha256(KEY.encode()).hexdigest(),
                                      expected_models={"quick_model": "gpt-6-sol", "deep_model": "gpt-6-astra"})
    assert service.public()["execution_test"] is None
