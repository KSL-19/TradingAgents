"""Run/probe regressions with provider boundaries mocked; no paid requests."""

import hashlib
import json
import logging
import queue
import socket
from datetime import UTC, datetime, timedelta
from types import SimpleNamespace
from uuid import uuid4

import httpx
import pytest
from fastapi.testclient import TestClient

import backend.connections as connections
import backend.worker as worker
from backend.app import create_app
from backend.execution_probe import ProbeResponse, execute_probe
from backend.store import Store, now

KEY = "sk-proj-test-fixture-not-a-real-key-12345678901234567890"
MODELS = ["gpt-6-sol", "gpt-6-astra"]


@pytest.fixture(autouse=True)
def isolated(monkeypatch):
    for name in ("DASHBOARD_PASSWORD", "DASHBOARD_LOCAL_MODE", "DASHBOARD_PUBLIC_ORIGIN", "DASHBOARD_SECURE_COOKIES",
                 "SEC_EDGAR_USER_AGENT", "TRADINGAGENTS_OPENAI_API_KEY"):
        monkeypatch.delenv(name, raising=False)
    # Direct child-target tests mutate this key; restore it after every test.
    monkeypatch.setenv("OPENAI_API_KEY", "")
    monkeypatch.setattr(socket.socket, "connect", lambda *a, **k: pytest.fail("No remote requests are allowed"))


@pytest.fixture
def client(tmp_path, monkeypatch):
    monkeypatch.setattr(connections, "_list_models", lambda key: MODELS)
    with TestClient(create_app(tmp_path, local_mode=True)) as value:
        yield value


def configure(client):
    assert client.put("/api/connections", json={"openai_api_key": KEY}).status_code == 200
    response = client.post("/api/connections/test")
    assert response.status_code == 200 and response.json()["verified"]
    return response.json()


def market_quote():
    return {"price": 125.25, "currency": "USD", "source": "Provider fixture", "mode": "live",
            "quote_as_of": "2026-10-27T20:00:00+00:00", "quote_date": "2026-10-27",
            "fetched_at": "2026-10-27T20:01:00+00:00", "price_type": "regular-session provider quote"}


def test_expired_listing_is_refreshed_before_model_defaults_are_resolved(client, tmp_path, monkeypatch):
    configure(client)
    path = tmp_path / "config.json"
    config = json.loads(path.read_text())
    config["verification"]["checked_at"] = (datetime.now(UTC) - timedelta(days=2)).isoformat()
    path.write_text(json.dumps(config))
    calls = []
    monkeypatch.setattr(connections, "_list_models", lambda key: calls.append("models") or MODELS)
    monkeypatch.setattr(client.app.state.market, "get", lambda *a, **k: market_quote())
    monkeypatch.setattr(client.app.state.manager, "submit", lambda body: calls.append(body) or {"id": "fixture", **body})
    result = client.post("/api/runs", json={"symbol": "AAPL"})
    assert result.status_code == 202, result.text
    assert calls[0] == "models"
    assert calls[1]["quick_model"] == "gpt-6-sol" and calls[1]["deep_model"] == "gpt-6-astra"
    assert KEY not in result.text


def test_free_readiness_does_not_request_generation_or_queue_a_job(client, monkeypatch):
    configure(client)
    monkeypatch.setattr(client.app.state.market, "get", lambda *a, **k: market_quote())
    monkeypatch.setattr(client.app.state.manager, "submit", lambda *a, **k: pytest.fail("Readiness must not queue analysis"))
    monkeypatch.setattr(client.app.state.manager, "probe", lambda *a, **k: pytest.fail("Readiness must not request a paid probe"))
    response = client.post("/api/analysis/check", json={"symbol": "AAPL"})
    assert response.status_code == 200
    assert response.json()["ready"] is True and response.json()["generation_tested"] is False
    assert client.get("/api/runs").json()["runs"] == []


def test_recommendations_endpoint_uses_observed_modern_models(client):
    configure(client)
    result = client.post("/api/connections/recommendations")
    assert result.status_code == 200
    assert result.json()["quick_model"] == "gpt-6-sol"
    assert result.json()["deep_model"] == "gpt-6-astra"


def test_missing_key_is_distinct_from_provider_rejection(client):
    result = client.post("/api/runs", json={"symbol": "AAPL"})
    assert result.status_code == 503
    assert result.json()["error_code"] == "credential_missing"
    assert "rejected" not in result.json()["detail"].lower()


class Output:
    def __init__(self):
        self.messages = []

    def put(self, value):
        self.messages.append(value)

    def put_nowait(self, value):
        self.put(value)


def test_worker_exposes_quota_action_without_raw_error_and_suppresses_upstream_logs(tmp_path, monkeypatch, capsys):
    import tradingagents.graph.trading_graph as graph_module

    connections.ConnectionSettings(tmp_path).save({"openai_api_key": KEY}, allow_key_edit=True)
    class QuotaError(Exception):
        status_code = 429
        body = {"error": {"code": "insufficient_quota", "message": KEY}}

    class Graph:
        def __init__(self, **kwargs):
            self.graph = None

        def propagate(self, *args, **kwargs):
            logging.getLogger("tradingagents.agents.structured").warning("Raw provider exception includes %s", KEY)
            raise QuotaError("raw SDK text " + KEY)

    monkeypatch.setattr(graph_module, "TradingAgentsGraph", Graph)
    output = Output()
    worker.execute_live({"symbol": "AAPL", "date": "2026-10-27", "analysts": ["market"],
                         "quick_model": MODELS[0], "deep_model": MODELS[1], "rounds": 1}, str(tmp_path), output)
    result = output.messages[-1]
    assert result["ok"] is False and result["error_code"] == "billing_quota_exceeded"
    assert result["error_stage"] == "graph_execution" and "billing" in result["error_action"].lower()
    assert KEY not in json.dumps(output.messages)
    captured = capsys.readouterr()
    assert KEY not in captured.out + captured.err


def test_worker_uses_larger_budget_timeout_and_root_tool_callback(tmp_path, monkeypatch):
    import tradingagents.graph.trading_graph as graph_module

    connections.ConnectionSettings(tmp_path).save({"openai_api_key": KEY}, allow_key_edit=True)
    observed = {}
    class Compiled:
        def with_config(self, config):
            observed["root_callbacks"] = config["callbacks"]
            return self

    class Graph:
        def __init__(self, config, callbacks, **kwargs):
            observed["config"] = config
            observed["callbacks"] = callbacks
            graph_module.create_tier_client(config, "quick")
            self.graph = Compiled()

        def propagate(self, *args, **kwargs):
            for callback in observed["root_callbacks"]:
                callback.on_tool_start({"name": "get_stock_data"}, "input must not be retained", run_id=uuid4())
                callback.on_tool_end({"type": "tool", "name": "get_stock_data", "content": "price fixture"}, run_id=uuid4())
            return {"final_trade_decision": "Rating: Hold", "market_report": "Adapter result"}, "Hold"

    def factory(config, tier, **extra):
        observed["timeout"] = extra["timeout"]
        return object()

    monkeypatch.setattr(graph_module, "create_tier_client", factory)
    monkeypatch.setattr(graph_module, "TradingAgentsGraph", Graph)
    output = Output()
    worker.execute_live({"symbol": "AAPL", "date": "2026-10-27", "analysts": ["market"],
                         "quick_model": MODELS[0], "deep_model": MODELS[1], "rounds": 1}, str(tmp_path), output)
    result = output.messages[-1]
    assert result["ok"] is True
    assert observed["config"]["max_tokens"] == 8192 and observed["timeout"] == 120
    assert observed["config"]["temperature"] is None and observed["config"]["openai_reasoning_effort"] is None
    assert result["source_coverage"]["attempted_tools"] == ["get_stock_data"]
    assert graph_module.create_tier_client is factory


def test_explicit_probe_uses_actual_adapter_boundary_for_two_capabilities(tmp_path, monkeypatch):
    import tradingagents.llm_clients as llm_clients

    connections.ConnectionSettings(tmp_path).save({"openai_api_key": KEY}, allow_key_edit=True)
    observed = []
    class LLM:
        def __init__(self, role):
            self.role = role

        def get_llm(self):
            return self

        def bind_tools(self, tools, tool_choice):
            assert tool_choice == "dashboard_readiness_check"
            return self

        def with_structured_output(self, schema):
            assert schema is ProbeResponse
            return self

        def invoke(self, prompt):
            observed.append((self.role, prompt))
            return SimpleNamespace(tool_calls=[{"name": "dashboard_readiness_check", "args": {"ready": True}}]) if self.role == "quick" else ProbeResponse(ready=True)

    def factory(config, role, **extra):
        assert extra["timeout"] == 35 and config["llm_max_retries"] == 0
        return LLM(role)

    monkeypatch.setattr(llm_clients, "create_tier_client", factory)
    output = Output()
    execute_probe(str(tmp_path), {"quick_model": MODELS[0], "deep_model": MODELS[1]}, hashlib.sha256(KEY.encode()).hexdigest(), output)
    result = output.messages[-1]
    assert result["success"] is True and result["request_count"] == 2
    assert [item["check"] for item in result["results"]] == ["tool_call", "structured_output"]
    assert len(observed) == 2 and KEY not in json.dumps(result)


def test_probe_quota_failure_skips_second_paid_request(tmp_path, monkeypatch):
    import tradingagents.llm_clients as llm_clients

    connections.ConnectionSettings(tmp_path).save({"openai_api_key": KEY}, allow_key_edit=True)
    class QuotaError(Exception):
        status_code = 429
        code = "insufficient_quota"

    class LLM:
        def get_llm(self):
            return self

        def bind_tools(self, *args, **kwargs):
            return self

        def invoke(self, prompt):
            raise QuotaError(KEY)

    monkeypatch.setattr(llm_clients, "create_tier_client", lambda *a, **k: LLM())
    output = Output()
    execute_probe(str(tmp_path), {"quick_model": MODELS[0], "deep_model": MODELS[1]}, hashlib.sha256(KEY.encode()).hexdigest(), output)
    result = output.messages[-1]
    assert result["success"] is False and result["request_count"] == 1
    assert result["results"][0]["error_code"] == "billing_quota_exceeded"
    assert result["results"][1]["status"] == "skipped"
    assert KEY not in json.dumps(result)


def test_probe_gate_prevents_concurrent_paid_requests_and_key_edits(client, monkeypatch):
    configure(client)
    client.app.state.manager._lock.acquire()
    try:
        assert client.post("/api/connections/probe").status_code == 409
        assert client.post("/api/runs", json={"symbol": "AAPL"}).status_code == 409
        assert client.put("/api/connections", json={"quick_model": MODELS[0]}).status_code == 409
    finally:
        client.app.state.manager._lock.release()


def test_probe_endpoint_persists_only_explicit_safe_check(client, monkeypatch):
    state = configure(client)
    calls = []
    def probe(models, fingerprint):
        calls.append(models)
        return {"verification_kind": "generation_probe", "success": True, "tested_at": now(), "request_count": 2,
                "message": "Two explicit fixture requests passed", "results": [
                    {"role": role, "model": models[role + "_model"], "check": check, "status": "passed",
                     "message": "Expected fixture received", "error_code": None, "error_action": None,
                     "error_stage": role + "_model_probe", "retryable": False}
                    for role, check in (("quick", "tool_call"), ("deep", "structured_output"))]}
    monkeypatch.setattr(client.app.state.manager, "probe", probe)
    assert calls == []  # Neither key save nor free test ran a generation probe.
    response = client.post("/api/connections/probe")
    assert response.status_code == 200 and response.json()["success"] is True
    assert calls == [{"quick_model": state["quick_model"], "deep_model": state["deep_model"]}]
    assert client.get("/api/connections").json()["execution_test"]["success"] is True
    assert KEY not in response.text


def test_diagnostic_export_keeps_only_safe_whitelisted_metadata(client):
    stamp = now()
    client.app.state.store.save_run({"id": "fixture", "symbol": "AAPL", "mode": "live", "date": "2026-10-27",
        "created_at": stamp, "updated_at": stamp, "status": "failed", "error_code": "billing_quota_exceeded",
        "error_stage": "graph_execution", "error": KEY, "raw_sdk_body": KEY, "quick_model": KEY,
        "deep_model": MODELS[1], "analysts": ["market"], "reports": {"secret": KEY}})
    response = client.get("/api/runs/fixture/diagnostics")
    assert response.status_code == 200 and "attachment" in response.headers["content-disposition"]
    assert KEY not in response.text and "raw_sdk_body" not in response.text
    data = response.json()
    assert data["quick_model"] is None and data["deep_model"] == MODELS[1]
    assert data["failure"]["code"] == "billing_quota_exceeded"


def test_worker_crash_and_probe_timeout_reach_safe_terminal_results(tmp_path, monkeypatch):
    class Channel:
        def get(self, timeout):
            raise queue.Empty

        def close(self):
            pass

    class Process:
        def start(self):
            pass

        def is_alive(self):
            return False

        def join(self, timeout):
            pass

    context = SimpleNamespace(Queue=lambda **kwargs: Channel(), Process=lambda **kwargs: Process())
    monkeypatch.setattr(worker.multiprocessing, "get_context", lambda name: context)
    manager = worker.AnalysisManager(Store(tmp_path), tmp_path)
    result = manager.probe({"quick_model": MODELS[0], "deep_model": MODELS[1]}, "fingerprint")
    assert result["success"] is False and result["error_code"] == "worker_crashed"
    assert manager.busy is False

    monkeypatch.setattr(Process, "is_alive", lambda self: True)
    monkeypatch.setattr(Process, "terminate", lambda self: None, raising=False)
    stamps = iter([0.0, 91.0])
    monkeypatch.setattr(worker.time, "monotonic", lambda: next(stamps))
    result = manager.probe({"quick_model": MODELS[0], "deep_model": MODELS[1]}, "fingerprint")
    assert result["error_code"] == "provider_timeout" and manager.busy is False


def test_analysis_job_preserves_child_failure_code_and_progress(tmp_path, monkeypatch):
    messages = queue.Queue()
    messages.put({"event": "progress", "stage": "graph_execution", "message": "Selected model is reviewing evidence"})
    messages.put({"ok": False, "error_code": "billing_quota_exceeded", "error_stage": "graph_execution",
                  "error": KEY, "raw_sdk_response": KEY})
    class Channel:
        def get(self, timeout):
            return messages.get_nowait()

        def close(self):
            pass

    class Process:
        def start(self):
            pass

        def is_alive(self):
            return False

        def join(self, timeout):
            pass

    context = SimpleNamespace(Queue=lambda **kwargs: Channel(), Process=lambda **kwargs: Process())
    monkeypatch.setattr(worker.multiprocessing, "get_context", lambda name: context)
    store = Store(tmp_path)
    manager = worker.AnalysisManager(store, tmp_path)
    manager._lock.acquire()
    stamp = now()
    manager._run({"id": "failure-fixture", "symbol": "AAPL", "date": "2026-10-27", "mode": "live",
                  "quick_model": MODELS[0], "deep_model": MODELS[1], "analysts": ["market"],
                  "status": "queued", "created_at": stamp, "updated_at": stamp, "reports": {}})
    result = store.get_run("failure-fixture")
    assert result["status"] == "failed" and result["error_code"] == "billing_quota_exceeded"
    assert "billing" in result["error_action"].lower() and result["error_stage"] == "graph_execution"
    assert KEY not in json.dumps(result) and manager.busy is False


def test_installed_native_adapter_serializes_and_parses_both_probe_capabilities(tmp_path, monkeypatch):
    """Exercise actual LangChain/OpenAI request building with a local transport."""
    import tradingagents.llm_clients as llm_clients

    connections.ConnectionSettings(tmp_path).save({"openai_api_key": KEY}, allow_key_edit=True)
    requests = []
    def response(request):
        body = json.loads(request.content)
        requests.append((request.url.path, body))
        tool = body["tools"][0]
        name = tool.get("name") or tool["function"]["name"]
        return httpx.Response(200, json={
            "id": "resp_fixture", "object": "response", "created_at": 1793124000, "status": "completed",
            "model": body["model"], "error": None, "incomplete_details": None,
            "output": [{"type": "function_call", "id": "fc_fixture", "call_id": "call_fixture",
                        "name": name, "arguments": '{"ready":true}', "status": "completed"}],
            "usage": {"input_tokens": 10, "output_tokens": 4, "total_tokens": 14,
                      "input_tokens_details": {"cached_tokens": 0}, "output_tokens_details": {"reasoning_tokens": 0}},
            "parallel_tool_calls": False, "tools": body["tools"], "tool_choice": body.get("tool_choice", "auto"),
            "text": {"format": {"type": "text"}}, "temperature": 1, "top_p": 1,
        })

    original = llm_clients.create_tier_client
    with httpx.Client(transport=httpx.MockTransport(response)) as http_client:
        def with_transport(config, role, **extra):
            return original(config, role, http_client=http_client, **extra)

        monkeypatch.setattr(llm_clients, "create_tier_client", with_transport)
        output = Output()
        execute_probe(str(tmp_path), {"quick_model": MODELS[0], "deep_model": MODELS[1]},
                      hashlib.sha256(KEY.encode()).hexdigest(), output)
    result = output.messages[-1]
    assert result["success"] is True, result
    assert len(requests) == 2
    assert all(path.endswith("/responses") for path, body in requests)
    assert requests[0][1]["model"] == MODELS[0] and requests[1][1]["model"] == MODELS[1]
    assert all(body["max_output_tokens"] == 4096 for path, body in requests)
    assert KEY not in json.dumps(result)
