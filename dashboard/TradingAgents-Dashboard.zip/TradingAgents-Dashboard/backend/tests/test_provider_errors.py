"""Failure classifications never serialize raw exception contents or secrets."""

import json

import pytest

from backend.provider_errors import (
    AnalysisFailure,
    Failure,
    classify_failure,
    failure_for,
)

SECRET = "sk-proj-not-a-real-key-private-response-test-value"


class ProviderError(Exception):
    def __init__(self, status=None, code=None, kind=None, param=None, body=None):
        super().__init__("raw SDK text " + SECRET + " https://private.example/?token=" + SECRET)
        self.status_code = status
        self.code = code
        self.type = kind
        self.param = param
        self.body = body


@pytest.mark.parametrize(("error", "expected"), [
    (ProviderError(401, SECRET), "authentication_failed"),
    (ProviderError(429, "insufficient_quota"), "billing_quota_exceeded"),
    (ProviderError(429, body={"error": {"code": "billing_hard_limit_reached", "message": SECRET}}), "billing_quota_exceeded"),
    (ProviderError(429, "rate_limit_exceeded"), "rate_limited"),
    (ProviderError(403, SECRET), "permission_denied"),
    (ProviderError(404, SECRET), "model_not_available"),
    (ProviderError(400, "unsupported_parameter", param=SECRET), "unsupported_model_parameter"),
    (ProviderError(400, "unsupported_parameter", param="max_output_tokens"), "unsupported_model_parameter"),
    (ProviderError(400, "context_length_exceeded"), "context_limit_exceeded"),
    (ProviderError(500, SECRET), "provider_unavailable"),
    (ProviderError(code="output_limit_exceeded"), "output_limit_exceeded"),
    (ProviderError(code="content_filter"), "content_rejected"),
    (ProviderError(body={"error": {"error": {"code": "model_not_found", "message": SECRET}}}), "model_not_available"),
])
def test_provider_failure_metadata_maps_to_fixed_messages(error, expected):
    result = classify_failure(error, "graph_execution")
    assert result.code == expected
    assert result.stage == "graph_execution"
    serialized = json.dumps(result.as_dict()) + json.dumps(result.as_job_fields())
    assert SECRET not in serialized
    assert "private.example" not in serialized
    assert result.message and result.action


@pytest.mark.parametrize(("name", "expected"), [
    ("LengthFinishReasonError", "output_limit_exceeded"),
    ("APITimeoutError", "provider_timeout"),
    ("APIConnectionError", "provider_connection_failed"),
    ("OutputParserException", "invalid_model_output"),
    ("MarketUnavailable", "market_data_unavailable"),
    ("BrokenProcessPool", "worker_crashed"),
])
def test_known_sdk_failure_types_need_no_raw_message_matching(name, expected):
    error_type = type(name, (Exception,), {})
    result = classify_failure(error_type(SECRET))
    assert result.code == expected
    assert SECRET not in json.dumps(result.as_dict())


def test_wrapper_failure_uses_safe_nested_cause():
    outer = RuntimeError(SECRET)
    outer.__cause__ = ProviderError(429, "insufficient_quota")
    result = classify_failure(outer, "quick_model_probe")
    assert result.code == "billing_quota_exceeded"
    assert result.stage == "quick_model_probe"
    assert result.retryable is False
    assert SECRET not in json.dumps(result.as_dict())


def test_unknown_codes_stages_and_directly_constructed_failures_are_not_reflected():
    error = ProviderError(200, SECRET, kind=SECRET, param=SECRET, body={"error": {"code": SECRET}})
    result = classify_failure(error, SECRET)
    assert result.code == "analysis_failed" and result.stage == "analysis"
    assert SECRET not in json.dumps(result.as_dict())
    direct = Failure(SECRET, SECRET, SECRET, SECRET, True)
    assert direct.as_dict() == failure_for("analysis_failed").as_dict()
    assert SECRET not in json.dumps(direct.as_job_fields())


def test_deliberate_failure_uses_registry_and_preserves_known_stage():
    error = AnalysisFailure("empty_model_output", "report_output")
    result = classify_failure(error, "graph_execution")
    assert result.code == "empty_model_output" and result.stage == "report_output"
    assert result.as_job_fields()["error_code"] == result.code
    assert result.as_job_fields()["error"] == result.message
    assert SECRET not in str(error)


def test_poisoned_deliberate_failure_cannot_serialize_custom_text():
    error = AnalysisFailure(Failure("model_not_available", SECRET, SECRET, "model_preflight", True))
    assert SECRET not in str(error)
    assert SECRET not in json.dumps(classify_failure(error).as_dict())


def test_exception_chain_cycle_is_bounded():
    one, two = RuntimeError(SECRET), RuntimeError(SECRET)
    one.__cause__, two.__cause__ = two, one
    assert classify_failure(one).code == "analysis_failed"


def test_raising_metadata_properties_do_not_replace_public_failure_with_exception():
    class StrangeError(Exception):
        @property
        def body(self):
            raise ValueError(SECRET)

        @property
        def status_code(self):
            raise ValueError(SECRET)

    assert classify_failure(StrangeError(SECRET)).code == "analysis_failed"


def test_sdk_authentication_exception_can_be_classified_without_echoing_request():
    import httpx2
    from openai import AuthenticationError

    request = httpx2.Request("POST", "https://api.openai.com/v1/responses", headers={"Authorization": "Bearer " + SECRET})
    response = httpx2.Response(401, request=request, json={"error": {"code": "invalid_api_key", "message": SECRET}})
    error = AuthenticationError(SECRET, response=response, body={"code": "invalid_api_key", "message": SECRET})
    result = classify_failure(error)
    assert result.code == "authentication_failed"
    assert SECRET not in json.dumps(result.as_dict())


def test_authentication_failure_is_distinct_from_model_list_success_and_billing_failure():
    auth = classify_failure(ProviderError(401))
    billing = classify_failure(ProviderError(429, "insufficient_quota"))
    rate = classify_failure(ProviderError(429))
    assert {auth.code, billing.code, rate.code} == {"authentication_failed", "billing_quota_exceeded", "rate_limited"}
    assert billing.retryable is False and rate.retryable is True
    assert "ChatGPT" in billing.action
