"""Provider-boundary tests: fixture prices do not represent real market observations."""

import socket
import time
from collections.abc import Mapping
from concurrent.futures import ThreadPoolExecutor
from datetime import UTC, datetime

import pandas as pd
import pytest

from backend import market


def instant(text):
    return datetime.fromisoformat(text).astimezone(UTC)


def history():
    return pd.DataFrame({
        "Open": [99.0, 100.5], "High": [102.0, 112.0], "Low": [98.0, 100.0],
        "Close": [100.0, 110.75], "Volume": [100000, 120000],
    }, index=pd.to_datetime(["2026-10-26", "2026-10-27"]).tz_localize("America/New_York"))


def metadata():
    return {
        "symbol": "XYZ", "shortName": "Fixture company", "currency": "USD",
        "exchangeName": "NMS", "exchangeTimezoneName": "America/New_York",
        "regularMarketPrice": 111.25, "regularMarketTime": instant("2026-10-27T19:35:00+00:00").timestamp(),
        "exchangeDataDelayedBy": 15,
        "currentTradingPeriod": {
            "regular": {"start": instant("2026-10-27T13:30:00+00:00").timestamp(),
                        "end": instant("2026-10-27T20:00:00+00:00").timestamp()},
            "post": {"start": instant("2026-10-27T20:00:00+00:00").timestamp(),
                     "end": instant("2026-10-28T00:00:00+00:00").timestamp()},
        },
    }


@pytest.fixture(autouse=True)
def no_network(monkeypatch):
    def refuse(*args, **kwargs):
        raise AssertionError("Provider tests must not use the network")
    monkeypatch.setattr(socket.socket, "connect", refuse)
    monkeypatch.setattr(socket.socket, "connect_ex", refuse)


def test_exact_quote_timestamp_is_distinct_from_daily_bar_and_completed_close():
    now = instant("2026-10-27T19:40:00+00:00")
    quote = market._provenance(market._live_quote("XYZ", history(), metadata(), now), now)
    assert quote["price"] == 111.25
    assert quote["latest_bar_close"] == 110.75
    assert quote["last_completed_close"] == 100.0
    assert quote["last_completed_session_date"] == "2026-10-26"
    assert quote["quote_as_of"] == "2026-10-27T19:35:00+00:00"
    assert quote["quote_date"] == "2026-10-27"
    assert quote["exchange_timezone"] == "America/New_York"
    assert quote["latest_bar_complete"] is False
    assert quote["stale"] is False and quote["session_state"] == "regular"
    assert quote["change"] == 11.25
    assert "_metadata" not in quote


def test_latest_completed_close_advances_only_after_session_end_grace_period():
    before = instant("2026-10-27T20:01:00+00:00")
    after = instant("2026-10-27T20:10:00+00:00")
    first = market._live_quote("XYZ", history(), metadata(), before)
    second = market._live_quote("XYZ", history(), metadata(), after)
    assert first["last_completed_close"] == 100.0
    assert second["last_completed_close"] == 110.75
    assert second["last_completed_session_date"] == "2026-10-27"
    assert second["latest_bar_complete"] is True


def test_yfinance_formatted_aware_timestamps_are_supported():
    data = metadata()
    data["regularMarketTime"] = pd.Timestamp("2026-10-27T15:35:00", tz="America/New_York")
    data["currentTradingPeriod"]["regular"]["start"] = pd.Timestamp("2026-10-27T09:30:00", tz="America/New_York")
    data["currentTradingPeriod"]["regular"]["end"] = pd.Timestamp("2026-10-27T16:00:00", tz="America/New_York")
    now = instant("2026-10-27T19:40:00+00:00")
    result = market._provenance(market._live_quote("XYZ", history(), data, now), now)
    assert result["quote_as_of"] == "2026-10-27T19:35:00+00:00"
    assert result["session_state"] == "regular"


def test_missing_provider_time_cannot_masquerade_as_current_quote():
    data = metadata()
    data.pop("regularMarketTime")
    now = instant("2026-10-27T19:40:00+00:00")
    result = market._provenance(market._live_quote("XYZ", history(), data, now), now)
    assert result["price"] == 110.75
    assert result["as_of"] == "2026-10-27" and result["quote_as_of"] is None
    assert result["quote_kind"] == "daily_bar" and result["freshness"] == "timestamp_unavailable"
    assert result["stale"] is None


@pytest.mark.parametrize("observed_at", ["2026-10-31T16:00:00+00:00", "2026-11-01T16:00:00+00:00"])
def test_closed_market_does_not_relabel_old_quote_as_today_or_assume_weekends_stale(observed_at):
    now = instant(observed_at)
    result = market._provenance(market._live_quote("XYZ", history(), metadata(), now), now)
    assert result["quote_date"] == "2026-10-27"
    assert result["quote_as_of"].startswith("2026-10-27")
    assert result["freshness"] == "outside_regular_hours" and result["stale"] is False
    assert result["quote_age_seconds"] > 86400


def test_session_metadata_respects_holiday_gap_without_inventing_a_new_price_date():
    data = metadata()
    data["regularMarketTime"] = instant("2026-05-22T20:00:00+00:00").timestamp()
    data["currentTradingPeriod"] = {"regular": {
        "start": instant("2026-05-26T13:30:00+00:00").timestamp(),
        "end": instant("2026-05-26T20:00:00+00:00").timestamp(),
    }}
    frame = history()
    frame.index = pd.to_datetime(["2026-05-21", "2026-05-22"]).tz_localize("America/New_York")
    now = instant("2026-05-25T17:00:00+00:00")
    result = market._provenance(market._live_quote("XYZ", frame, data, now), now)
    assert result["quote_date"] == "2026-05-22"
    assert result["freshness"] == "outside_regular_hours" and result["stale"] is False
    assert result["last_completed_session_date"] == "2026-05-22"


def test_stale_during_active_session_and_future_clock_are_disclosed():
    now = instant("2026-10-27T18:00:00+00:00")
    data = metadata()
    data["regularMarketTime"] = instant("2026-10-27T14:00:00+00:00").timestamp()
    result = market._provenance(market._live_quote("XYZ", history(), data, now), now)
    assert result["stale"] is True and result["freshness"] == "stale_during_session"
    data["regularMarketTime"] = instant("2026-10-27T19:00:00+00:00").timestamp()
    result = market._provenance(market._live_quote("XYZ", history(), data, now), now)
    assert result["freshness"] == "clock_warning" and result["stale"] is None


def test_conspicuously_old_quote_is_flagged_without_claiming_holiday_is_a_failure():
    now = instant("2026-11-10T19:40:00+00:00")
    result = market._provenance(market._live_quote("XYZ", history(), metadata(), now), now)
    assert result["freshness"] == "old_quote" and result["stale"] is None
    assert "Long market closures" in result["freshness_note"]
    assert result["quote_as_of"].startswith("2026-10-27")


def test_lagging_schedule_does_not_discard_newer_known_completed_bars():
    data = metadata()
    data["currentTradingPeriod"] = {"regular": {
        "start": instant("2026-10-26T13:30:00+00:00").timestamp(),
        "end": instant("2026-10-26T20:00:00+00:00").timestamp(),
    }}
    result = market._live_quote("XYZ", history(), data, instant("2026-10-29T16:00:00+00:00"))
    assert result["last_completed_session_date"] == "2026-10-27"
    assert result["last_completed_close"] == 110.75


def test_mismatched_symbol_and_invalid_bars_fail_without_fake_data():
    data = metadata()
    data["symbol"] = "DIFFERENT"
    with pytest.raises(market.MarketUnavailable, match="different instrument"):
        market._live_quote("XYZ", history(), data, instant("2026-10-27T19:40:00+00:00"))
    frame = history()
    frame["High"] = 1
    with pytest.raises(market.MarketUnavailable, match="no valid price history"):
        market._live_quote("XYZ", frame, metadata(), instant("2026-10-27T19:40:00+00:00"))


def test_unknown_currency_and_name_remain_unknown_not_seeded_defaults():
    data = metadata()
    for key in ("currency", "shortName"):
        data.pop(key)
    data["symbol"] = "NVDA"
    result = market._live_quote("NVDA", history(), data, instant("2026-10-27T19:40:00+00:00"))
    assert result["currency"] is None and result["name"] == "NVDA"


def test_cache_consistency_refresh_and_concurrent_fetch_coalescing(monkeypatch):
    import yfinance as yf

    calls = []

    class Ticker:
        def __init__(self, symbol):
            self.history_metadata = metadata()
            self.history_metadata["regularMarketPrice"] = 111.25 + len(calls)

        def history(self, **kwargs):
            calls.append(kwargs)
            time.sleep(0.01)
            return history()

    monkeypatch.setattr(yf, "Ticker", Ticker)
    monkeypatch.setattr(market, "_utc_now", lambda: instant("2026-10-27T19:40:00+00:00"))
    service = market.MarketService()
    with ThreadPoolExecutor(max_workers=5) as pool:
        results = list(pool.map(lambda _: service.get("XYZ", "live", "1mo"), range(5)))
    assert len(calls) == 1 and calls[0]["period"] == "1y"
    assert all(item["price"] == results[0]["price"] for item in results)
    wide = service.get("XYZ", "live", "1y")
    assert len(calls) == 1 and wide["price"] == results[0]["price"]
    refreshed = service.get("XYZ", "live", "3mo", force_refresh=True)
    assert len(calls) == 2 and refreshed["price"] == results[0]["price"] + 1
    assert refreshed["fetched_at"] == "2026-10-27T19:40:00+00:00"
    assert refreshed["cache_age_seconds"] == 0


def test_provider_error_is_sanitized_and_never_changes_to_demo(monkeypatch):
    import yfinance as yf

    def fail(*args, **kwargs):
        raise RuntimeError("secret-provider-key and private proxy URL")
    monkeypatch.setattr(yf, "Ticker", fail)
    with pytest.raises(market.MarketUnavailable) as failure:
        market.MarketService().get("XYZ", "live")
    assert "secret-provider-key" not in str(failure.value)
    assert "No demo prices were substituted" in str(failure.value)


def test_yfinance_lazy_metadata_does_not_trigger_unneeded_intraday_fetch(monkeypatch):
    import yfinance as yf

    class LazyMetadata(Mapping):
        def __getitem__(self, key):
            if key == "tradingPeriods":
                raise AssertionError("An unnecessary intraday request was triggered")
            return metadata()[key]

        def __iter__(self):
            return iter([*metadata(), "tradingPeriods"])

        def __len__(self):
            return len(metadata()) + 1

    class Ticker:
        history_metadata = LazyMetadata()

        def __init__(self, symbol):
            pass

        def history(self, **kwargs):
            return history()

    monkeypatch.setattr(yf, "Ticker", Ticker)
    monkeypatch.setattr(market, "_utc_now", lambda: instant("2026-10-27T19:40:00+00:00"))
    result = market.MarketService().get("XYZ", "live")
    assert result["price"] == 111.25 and result["quote_kind"] == "regular_session"
