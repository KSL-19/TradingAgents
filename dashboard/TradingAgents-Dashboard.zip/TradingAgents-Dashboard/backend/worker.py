"""Bounded analysis worker. Live runs execute the installed upstream graph."""

import copy
import multiprocessing
import os
import queue
import threading
import time
import uuid
from datetime import date
from pathlib import Path

from .connections import ConnectionSettings, valid_sec_contact
from .market import demo_market
from .store import now

REPORT_KEYS = (
    "market_report", "sentiment_report", "news_report", "fundamentals_report",
    "investment_plan", "trader_investment_plan", "final_trade_decision",
)


def live_key_present() -> bool:
    return bool(os.getenv("OPENAI_API_KEY") or os.getenv("TRADINGAGENTS_OPENAI_API_KEY"))


def execute_live(payload: dict, data_dir: str, output):
    """Isolate process-wide SDK/config state and enforce a parent-side timeout."""
    try:
        settings = ConnectionSettings(Path(data_dir))
        key = settings.get_key()
        if not key:
            raise RuntimeError("No provider credential is configured")
        # This is a spawned per-run process. The key never enters a persisted job.
        os.environ["OPENAI_API_KEY"] = key
        contact = settings.sec_contact()
        if contact and not os.getenv("SEC_EDGAR_USER_AGENT"):
            os.environ["SEC_EDGAR_USER_AGENT"] = contact
        state_dir = Path(data_dir) / "agents"
        os.environ["XDG_CACHE_HOME"] = str(state_dir / "xdg-cache")
        os.environ["TRADINGAGENTS_NO_UPDATE_CHECK"] = "1"
        import yfinance as yf
        from tradingagents.default_config import DEFAULT_CONFIG
        from tradingagents.graph.trading_graph import TradingAgentsGraph

        yf.set_tz_cache_location(str(state_dir / "yfinance"))
        config = copy.deepcopy(DEFAULT_CONFIG)
        config.update(
            llm_provider="openai", quick_think_provider=None, deep_think_provider=None,
            backend_url=None, quick_think_backend_url=None, deep_think_backend_url=None,
            quick_think_llm=payload["quick_model"], deep_think_llm=payload["deep_model"],
            results_dir=str(state_dir / "logs"), data_cache_dir=str(state_dir / "cache"),
            memory_log_path=str(state_dir / "memory" / "decisions.md"),
            max_debate_rounds=payload["rounds"], max_risk_discuss_rounds=payload["rounds"],
            max_tool_rounds=6, max_recur_limit=100, max_tokens=2048, llm_max_retries=1,
            checkpoint_enabled=False, output_language="English",
        )
        graph = TradingAgentsGraph(selected_analysts=payload["analysts"], config=config)
        asset_type = "crypto" if payload["symbol"].endswith("-USD") else "stock"
        state, rating = graph.propagate(payload["symbol"], payload["date"], asset_type=asset_type)
        reports = {key: str(state.get(key) or "")[:100_000] for key in REPORT_KEYS}
        for section, key in (("investment_debate_state", "research_debate"), ("risk_debate_state", "risk_debate")):
            value = state.get(section) or {}
            reports[key] = str(value.get("history") or "")[:100_000]
        from .coverage import summarize_source_coverage

        coverage = summarize_source_coverage(state.get("messages", []), payload["analysts"], configured_sources={
            "fred": bool(os.getenv("FRED_API_KEY")), "sec_edgar_contact": valid_sec_contact(contact),
        })
        output.put({"ok": True, "rating": str(rating), "reports": reports, "source_coverage": coverage})
    except Exception:  # noqa: BLE001 -- only a sanitized failure crosses the worker boundary.
        # Never serialize raw SDK errors, auth headers, or LangChain message objects.
        output.put({"ok": False})


def demo_analysis(payload: dict) -> dict:
    quote = demo_market(payload["symbol"], "3mo", date.fromisoformat(payload["date"]))
    closes = [bar["close"] for bar in quote["bars"]]
    if len(closes) < 20:
        raise ValueError("The demonstration requires 20 synthetic trading days of history.")
    price, sma = closes[-1], sum(closes[-20:]) / 20
    momentum = (price / closes[-20] - 1) * 100
    rating = "Overweight" if momentum > 3 else "Underweight" if momentum < -3 else "Hold"
    prefix = "**Illustrative demonstration — synthetic data, no LLM analysis.**\n\n"
    reports = {
        "market_report": prefix + f"### {payload['symbol']} technical snapshot\n"
            f"Synthetic close: ${price:,.2f}. 20-session average: ${sma:,.2f}. "
            f"20-session return: {momentum:+.2f}%. Price is {'above' if price > sma else 'below'} "
            "the moving average. These generated observations are for exploring the interface, "
            "and describe no real security or current market opportunity.",
        "investment_plan": prefix + "### Research discussion\n"
            "A momentum view favors following a sustained trend; a cautious view asks whether "
            "recent movement could reverse. Real research would compare company filings, news, "
            "liquidity and valuation. None of those sources were consulted in this demonstration.",
        "trader_investment_plan": prefix + "### Practice plan\n"
            "Use the isolated paper account to practice order entry. The simulator uses its "
            "displayed synthetic close, ignores transaction costs and slippage, and never sends "
            "an order to a broker. Position sizes are entirely under your control.",
        "risk_debate": prefix + "### Risk review\n"
            "Synthetic returns do not establish expected real returns. Consider concentration, "
            "position sizing and downside exposure when evaluating any real strategy. "
            "Paper fills at a daily close do not model executable market prices.",
        "final_trade_decision": prefix + f"**Rating: {rating}**\n\n"
            f"This example label follows a fixed rule: a 20-session synthetic return above 3% "
            "is Overweight, below -3% is Underweight, otherwise Hold. It is not a model's "
            "recommendation and should not be used as a real trade signal.",
    }
    for analyst, key in (("news", "news_report"), ("fundamentals", "fundamentals_report"), ("social", "sentiment_report")):
        if analyst in payload["analysts"]:
            reports[key] = prefix + "No external sources were requested. Configure live analysis to run this analyst against the selected data sources."
    return {"rating": rating, "reports": reports}


class AnalysisManager:
    def __init__(self, store, data_dir: Path):
        self.store, self.data_dir = store, data_dir
        self._lock = threading.Lock()
        self._thread = None

    @property
    def busy(self) -> bool:
        return self._lock.locked()

    def submit(self, body: dict) -> dict | None:
        if not self._lock.acquire(blocking=False):
            return None
        stamp = now()
        payload = dict(body, id=uuid.uuid4().hex, status="queued", created_at=stamp,
                       updated_at=stamp, progress="Waiting for analysis worker", rating=None, error=None, reports={})
        try:
            self.store.save_run(payload)
            self._thread = threading.Thread(target=self._run, args=(payload,), daemon=True)
            self._thread.start()
        except Exception:
            self._lock.release()
            raise
        return payload

    def _run(self, payload: dict):
        process = None
        channel = None
        try:
            payload.update(status="running", progress="Running illustrative demo" if payload["mode"] == "demo" else "TradingAgents analysts and research debate are running", updated_at=now())
            if payload.get("provenance"):
                payload["provenance"]["started_at"] = payload["updated_at"]
            self.store.save_run(payload)
            if payload["mode"] == "demo":
                # Briefly preserve running state so the UI can show real job lifecycle.
                time.sleep(0.25)
                result = demo_analysis(payload)
            else:
                context = multiprocessing.get_context("spawn")
                channel = context.Queue(maxsize=1)
                process = context.Process(target=execute_live, args=(payload, str(self.data_dir), channel), daemon=True)
                process.start()
                deadline = time.monotonic() + 900
                while True:
                    try:
                        result = channel.get(timeout=0.5)
                        break
                    except queue.Empty:
                        if not process.is_alive():
                            raise RuntimeError("The analysis worker exited without a result.") from None
                        if time.monotonic() >= deadline:
                            raise TimeoutError from None
                if not result.get("ok"):
                    raise RuntimeError
            payload.update(status="completed", progress="Complete", **{key: result[key] for key in ("rating", "reports")})
            if "source_coverage" in result:
                payload["source_coverage"] = result["source_coverage"]
            if payload.get("provenance"):
                payload["provenance"]["generated_at"] = now()
        except TimeoutError:
            payload.update(status="failed", error="Analysis exceeded the 15-minute limit and was stopped. Try fewer analysts or a faster model.", progress="Stopped at time limit")
        except Exception:  # noqa: BLE001 -- background jobs must reach a durable terminal state.
            message = (
                "The demonstration could not produce this date range. Choose a recent analysis date."
                if payload["mode"] == "demo" else
                "TradingAgents could not finish. Check the OpenAI key, model access, account quota, "
                "network permissions and data-provider availability. No demo report was substituted."
            )
            payload.update(status="failed", error=message, progress="Analysis failed")
        finally:
            if process is not None:
                process.join(timeout=2)
                if process.is_alive():
                    process.terminate()
                    process.join(timeout=5)
            if channel is not None:
                channel.close()
            payload["updated_at"] = now()
            try:
                self.store.save_run(payload)
            finally:
                self._lock.release()

    def join(self, timeout=5):
        if self._thread:
            self._thread.join(timeout=timeout)
