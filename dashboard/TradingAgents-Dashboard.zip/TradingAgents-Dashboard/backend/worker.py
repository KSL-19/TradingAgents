"""Bounded analysis worker. Live runs execute the installed upstream graph."""

import copy
import logging
import multiprocessing
import os
import queue
import threading
import time
import uuid
from contextlib import suppress
from datetime import date
from pathlib import Path

from .connections import ConnectionSettings, valid_sec_contact
from .execution_probe import execute_probe
from .market import demo_market
from .provider_errors import AnalysisFailure, classify_failure, failure_for
from .store import now

REPORT_KEYS = (
    "market_report", "sentiment_report", "news_report", "fundamentals_report",
    "investment_plan", "trader_investment_plan", "final_trade_decision",
)


def live_key_present() -> bool:
    return bool(os.getenv("OPENAI_API_KEY") or os.getenv("TRADINGAGENTS_OPENAI_API_KEY"))


def execute_live(payload: dict, data_dir: str, output):
    """Run the installed graph in isolation and return only safe diagnostics."""
    stage = "initialization"
    logger_names = (
        "tradingagents.agents.structured", "tradingagents.graph.trading_graph",
        "tradingagents.memory.settlement", "tradingagents.dataflows.vendors.stocktwits",
        "tradingagents.dataflows.vendors.reddit", "tradingagents.dataflows.files",
        "langchain_openai.chat_models.base",
    )
    previous_logging = {name: logging.getLogger(name).disabled for name in logger_names}
    previous_disable = logging.root.manager.disable
    try:
        # Optional vendor failures can include query credentials in their log
        # text. Only our fixed safe queue messages leave this isolated process.
        logging.disable(logging.CRITICAL)
        for name in logger_names:
            logging.getLogger(name).disabled = True
        settings = ConnectionSettings(Path(data_dir))
        key = settings.get_key()
        if not key:
            raise AnalysisFailure("credential_missing", "initialization")
        # This is a spawned per-run process. The key never enters a persisted job.
        os.environ["OPENAI_API_KEY"] = key
        contact = settings.sec_contact()
        if contact and not os.getenv("SEC_EDGAR_USER_AGENT"):
            os.environ["SEC_EDGAR_USER_AGENT"] = contact
        state_dir = Path(data_dir) / "agents"
        os.environ["XDG_CACHE_HOME"] = str(state_dir / "xdg-cache")
        os.environ["TRADINGAGENTS_NO_UPDATE_CHECK"] = "1"
        import tradingagents.graph.trading_graph as graph_module
        import yfinance as yf
        from langchain_core.callbacks import BaseCallbackHandler
        from tradingagents.default_config import DEFAULT_CONFIG

        from .tool_observer import ToolObserver

        class SafeProgress(BaseCallbackHandler):
            def __init__(self):
                self._last = 0.0
                self._lock = threading.Lock()

            def on_chat_model_start(self, serialized, messages, **kwargs):
                self._emit()

            def on_llm_start(self, serialized, prompts, **kwargs):
                self._emit()

            def _emit(self):
                with self._lock:
                    stamp = time.monotonic()
                    if stamp - self._last < 3:
                        return
                    self._last = stamp
                with suppress(AttributeError, queue.Full):
                    output.put_nowait({"event": "progress", "stage": "graph_execution",
                                       "message": "The selected models are reviewing research evidence"})

        yf.set_tz_cache_location(str(state_dir / "yfinance"))
        config = copy.deepcopy(DEFAULT_CONFIG)
        config.update(
            llm_provider="openai", quick_think_provider=None, deep_think_provider=None,
            backend_url=None, quick_think_backend_url=None, deep_think_backend_url=None,
            quick_think_llm=payload["quick_model"], deep_think_llm=payload["deep_model"],
            results_dir=str(state_dir / "logs"), data_cache_dir=str(state_dir / "cache"),
            memory_log_path=str(state_dir / "memory" / "decisions.md"),
            max_debate_rounds=payload["rounds"], max_risk_discuss_rounds=payload["rounds"],
            max_tool_rounds=6, max_recur_limit=100, max_tokens=8192, llm_max_retries=1,
            # Do not inherit sampling/effort overrides that a selected reasoning
            # model may reject. Let its supported API defaults apply.
            temperature=None, openai_reasoning_effort=None,
            checkpoint_enabled=False, output_language="English",
        )
        observer = ToolObserver()
        progress = SafeProgress()
        original_factory = graph_module.create_tier_client

        def bounded_factory(settings, tier, **extra):
            extra.setdefault("timeout", 120)
            return original_factory(settings, tier, **extra)

        # The public factory accepts SDK timeouts; the upstream graph has no
        # timeout config field. This per-process wrapper changes no source file.
        graph_module.create_tier_client = bounded_factory
        try:
            graph = graph_module.TradingAgentsGraph(selected_analysts=payload["analysts"], config=config,
                                                    callbacks=[observer, progress])
            compiled = getattr(graph, "graph", None)
            if compiled is not None and hasattr(compiled, "with_config"):
                # Analyst subgraphs return reports, not their private messages.
                # Root callback propagation is needed to observe their tools.
                graph.graph = compiled.with_config({"callbacks": [observer, progress]})
            asset_type = "crypto" if payload["symbol"].endswith("-USD") else "stock"
            stage = "graph_execution"
            output.put({"event": "progress", "stage": stage,
                        "message": "TradingAgents is running the selected analysts and risk review"})
            state, rating = graph.propagate(payload["symbol"], payload["date"], asset_type=asset_type)
        finally:
            graph_module.create_tier_client = original_factory
        stage = "report_output"
        reports = {name: str(state.get(name) or "")[:100_000] for name in REPORT_KEYS}
        for section, name in (("investment_debate_state", "research_debate"), ("risk_debate_state", "risk_debate")):
            value = state.get(section) or {}
            reports[name] = str(value.get("history") or "")[:100_000]
        if not reports["final_trade_decision"].strip():
            raise AnalysisFailure("empty_model_output", stage)
        coverage = observer.summary(payload["analysts"], configured_sources={
            "fred": bool(os.getenv("FRED_API_KEY")), "sec_edgar_contact": valid_sec_contact(contact),
        })
        output.put({"ok": True, "rating": str(rating), "reports": reports, "source_coverage": coverage,
                    "execution_limits": {"output_tokens_per_call": 8192, "sdk_timeout_seconds": 120,
                                         "sdk_retries": 1, "analysis_timeout_seconds": 900}})
    except Exception as exc:  # noqa: BLE001 -- only fixed classifications cross the worker boundary.
        output.put({"ok": False, **classify_failure(exc, stage).as_job_fields()})
    finally:
        logging.disable(previous_disable)
        for name, disabled in previous_logging.items():
            logging.getLogger(name).disabled = disabled


def demo_analysis(payload: dict) -> dict:
    quote = demo_market(payload["symbol"], "3mo", date.fromisoformat(payload["date"]))
    closes = [bar["close"] for bar in quote["bars"]]
    if len(closes) < 20:
        raise ValueError("The demonstration requires 20 synthetic trading days of history.")
    price, sma = closes[-1], sum(closes[-20:]) / 20
    momentum = (price / closes[-20] - 1) * 100
    rating = "Overweight" if momentum > 3 else "Underweight" if momentum < -3 else "Hold"
    prefix = "**Illustrative demonstration — synthetic data, no LLM analysis.**\n\n"
    reports = {
        "market_report": prefix + f"### {payload['symbol']} technical snapshot\n"
            f"Synthetic close: ${price:,.2f}. 20-session average: ${sma:,.2f}. "
            f"20-session return: {momentum:+.2f}%. Price is {'above' if price > sma else 'below'} "
            "the moving average. These generated observations are for exploring the interface, "
            "and describe no real security or current market opportunity.",
        "investment_plan": prefix + "### Research discussion\n"
            "A momentum view favors following a sustained trend; a cautious view asks whether "
            "recent movement could reverse. Real research would compare company filings, news, "
            "liquidity and valuation. None of those sources were consulted in this demonstration.",
        "trader_investment_plan": prefix + "### Practice plan\n"
            "Use the isolated paper account to practice order entry. The simulator uses its "
            "displayed synthetic close, ignores transaction costs and slippage, and never sends "
            "an order to a broker. Position sizes are entirely under your control.",
        "risk_debate": prefix + "### Risk review\n"
            "Synthetic returns do not establish expected real returns. Consider concentration, "
            "position sizing and downside exposure when evaluating any real strategy. "
            "Paper fills at a daily close do not model executable market prices.",
        "final_trade_decision": prefix + f"**Rating: {rating}**\n\n"
            f"This example label follows a fixed rule: a 20-session synthetic return above 3% "
            "is Overweight, below -3% is Underweight, otherwise Hold. It is not a model's "
            "recommendation and should not be used as a real trade signal.",
    }
    for analyst, key in (("news", "news_report"), ("fundamentals", "fundamentals_report"), ("social", "sentiment_report")):
        if analyst in payload["analysts"]:
            reports[key] = prefix + "No external sources were requested. Configure live analysis to run this analyst against the selected data sources."
    return {"rating": rating, "reports": reports}


class AnalysisManager:
    def __init__(self, store, data_dir: Path):
        self.store, self.data_dir = store, data_dir
        self._lock = threading.Lock()
        self._thread = None

    @property
    def busy(self) -> bool:
        return self._lock.locked()

    def submit(self, body: dict) -> dict | None:
        if not self._lock.acquire(blocking=False):
            return None
        stamp = now()
        payload = dict(body, id=uuid.uuid4().hex, status="queued", created_at=stamp,
                       updated_at=stamp, progress="Waiting for analysis worker", rating=None, error=None,
                       error_code=None, error_action=None, error_stage=None, retryable=False, reports={})
        try:
            self.store.save_run(payload)
            self._thread = threading.Thread(target=self._run, args=(payload,), daemon=True)
            self._thread.start()
        except Exception:
            self._lock.release()
            raise
        return payload

    def _run(self, payload: dict):
        process = None
        channel = None
        try:
            payload.update(status="running", progress="Running illustrative demo" if payload["mode"] == "demo" else "TradingAgents analysts and research debate are running", updated_at=now())
            if payload.get("provenance"):
                payload["provenance"]["started_at"] = payload["updated_at"]
            self.store.save_run(payload)
            if payload["mode"] == "demo":
                # Briefly preserve running state so the UI can show real job lifecycle.
                time.sleep(0.25)
                result = demo_analysis(payload)
            else:
                context = multiprocessing.get_context("spawn")
                channel = context.Queue(maxsize=32)
                process = context.Process(target=execute_live, args=(payload, str(self.data_dir), channel), daemon=True)
                process.start()
                deadline = time.monotonic() + 900
                while True:
                    try:
                        result = channel.get(timeout=0.5)
                        if result.get("event") == "progress":
                            payload.update(progress=result["message"], updated_at=now())
                            self.store.save_run(payload)
                            continue
                        break
                    except queue.Empty:
                        if not process.is_alive():
                            raise AnalysisFailure("worker_crashed", "worker_exit") from None
                        if time.monotonic() >= deadline:
                            raise TimeoutError from None
                if not result.get("ok"):
                    raise AnalysisFailure(failure_for(result.get("error_code"), result.get("error_stage", "graph_execution")))
            payload.update(status="completed", progress="Complete", **{key: result[key] for key in ("rating", "reports")})
            for field in ("source_coverage", "execution_limits"):
                if field in result:
                    payload[field] = result[field]
            if payload.get("provenance"):
                payload["provenance"]["generated_at"] = now()
        except TimeoutError:
            payload.update(status="failed", progress="Stopped at time limit",
                           **failure_for("analysis_timeout", "graph_execution").as_job_fields())
        except Exception as exc:  # noqa: BLE001 -- background jobs must reach a durable terminal state.
            if payload["mode"] == "demo":
                payload.update(status="failed", error="The demonstration could not produce this date range. Choose a recent analysis date.",
                               error_code="analysis_failed", error_action="Choose a recent demonstration date and retry.",
                               error_stage="analysis", retryable=False, progress="Demonstration failed")
            else:
                payload.update(status="failed", progress="Analysis failed",
                               **classify_failure(exc, "graph_execution").as_job_fields())
        finally:
            if process is not None:
                process.join(timeout=2)
                if process.is_alive():
                    process.terminate()
                    process.join(timeout=5)
            if channel is not None:
                channel.close()
            payload["updated_at"] = now()
            try:
                self.store.save_run(payload)
            finally:
                self._lock.release()

    def probe(self, models: dict, expected_fingerprint: str) -> dict | None:
        """Explicitly requested paid check, serialized against normal analysis."""
        if not self._lock.acquire(blocking=False):
            return None
        process, channel = None, None
        try:
            context = multiprocessing.get_context("spawn")
            channel = context.Queue(maxsize=1)
            process = context.Process(target=execute_probe,
                                      args=(str(self.data_dir), models, expected_fingerprint, channel), daemon=True)
            process.start()
            deadline = time.monotonic() + 90
            while True:
                try:
                    return channel.get(timeout=0.5)
                except queue.Empty:
                    if not process.is_alive():
                        raise AnalysisFailure("worker_crashed", "worker_exit") from None
                    if time.monotonic() >= deadline:
                        raise AnalysisFailure("provider_timeout", "analysis") from None
        except Exception as exc:  # noqa: BLE001 -- return fixed actionable classifications only.
            failure = classify_failure(exc, "analysis")
            return {"verification_kind": "generation_probe", "tested_at": now(), "success": False,
                    "request_count": 0, "results": [], "message": failure.message, **failure.as_job_fields()}
        finally:
            if process is not None:
                process.join(timeout=1)
                if process.is_alive():
                    process.terminate()
                    process.join(timeout=5)
            if channel is not None:
                channel.close()
            self._lock.release()

    def join(self, timeout=5):
        if self._thread:
            self._thread.join(timeout=timeout)
