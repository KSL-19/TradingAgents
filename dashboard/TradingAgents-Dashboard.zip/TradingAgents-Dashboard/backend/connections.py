"""Local provider setup and credential checks without exposing credentials.

Windows stores the user's key through user-scoped DPAPI. Other desktop systems
use an owner-only local file. Hosted instances must use their secret settings.
"""

from __future__ import annotations

import ctypes
import hashlib
import json
import os
import re
import tempfile
import threading
from datetime import UTC, datetime, timedelta
from pathlib import Path

from .catalog import credential_like_model, model_catalog, selection_issues

# An account model list, rather than a shipped model name, chooses defaults.
DEFAULT_QUICK_MODEL = ""
DEFAULT_DEEP_MODEL = ""
MODEL_PATTERN = re.compile(r"^[A-Za-z0-9_.:/\-]{1,100}$")
VERIFY_LIFETIME = timedelta(hours=24)


class ProviderConnectionError(Exception):
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code, self.message = code, message


def _is_windows() -> bool:
    return os.name == "nt"


def _windows_crypt(value: bytes, *, decrypt: bool = False) -> bytes:
    """Use Windows DPAPI for the current logged-in user; forbid GUI prompts."""
    from ctypes import wintypes

    class Blob(ctypes.Structure):
        _fields_ = [("size", wintypes.DWORD), ("data", ctypes.POINTER(ctypes.c_ubyte))]

    crypt32 = ctypes.WinDLL("crypt32", use_last_error=True)
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    buffer = (ctypes.c_ubyte * len(value)).from_buffer_copy(value)
    source, target = Blob(len(value), buffer), Blob()
    if decrypt:
        operation = crypt32.CryptUnprotectData
        operation.restype = wintypes.BOOL
        operation.argtypes = [ctypes.POINTER(Blob), ctypes.c_void_p, ctypes.c_void_p,
                              ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(Blob)]
        result = operation(ctypes.byref(source), None, None, None, None, 1, ctypes.byref(target))
    else:
        operation = crypt32.CryptProtectData
        operation.restype = wintypes.BOOL
        operation.argtypes = [ctypes.POINTER(Blob), wintypes.LPCWSTR, ctypes.c_void_p,
                              ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(Blob)]
        result = operation(ctypes.byref(source), "TradingAgents OpenAI key", None, None, None, 1, ctypes.byref(target))
    kernel32.LocalFree.argtypes = [ctypes.c_void_p]
    kernel32.LocalFree.restype = ctypes.c_void_p
    if not result:
        raise ProviderConnectionError("key_storage_unavailable", "Windows could not protect or unlock the saved key. Save the key again under your Windows account.")
    try:
        return ctypes.string_at(target.data, target.size)
    finally:
        kernel32.LocalFree(target.data)


def _protect_windows(value: bytes) -> bytes:
    return _windows_crypt(value)


def _unprotect_windows(value: bytes) -> bytes:
    return _windows_crypt(value, decrypt=True)


def valid_sec_contact(value: str) -> bool:
    found = re.search(r"[^\s<>@]+@([^\s<>@]+\.[^\s<>@]+)", value)
    return bool(found and found.group(1).lower().strip(".,;") not in {
        "example.com", "example.org", "example.net", "email.com", "yourdomain.com",
    })


def _list_models(key: str) -> list[str]:
    from openai import OpenAI

    with OpenAI(api_key=key, timeout=15, max_retries=0) as client:
        return sorted({model.id for model in client.models.list().data
                       if isinstance(model.id, str) and MODEL_PATTERN.fullmatch(model.id)})[:1000]


class ConnectionSettings:
    def __init__(self, data_dir: Path):
        self.folder = Path(data_dir)
        self.folder.mkdir(parents=True, exist_ok=True)
        if not _is_windows():
            self.folder.chmod(0o700)
        self.config_path = self.folder / "config.json"
        self.key_path = self.folder / "openai.key"
        self._lock = threading.RLock()

    def _read_config(self) -> dict:
        if not self.config_path.exists():
            return {}
        if self.config_path.is_symlink():
            raise ProviderConnectionError("config_unavailable", "The connection settings file is not a regular local file.")
        try:
            value = json.loads(self.config_path.read_text())
            return value if isinstance(value, dict) else {}
        except (OSError, ValueError):
            raise ProviderConnectionError("config_unavailable", "The local connection settings could not be read. Restore the config file or remove it and set up the connection again.") from None

    def _atomic_write(self, path: Path, content: bytes):
        descriptor, temporary = tempfile.mkstemp(prefix=".connection-", dir=self.folder)
        try:
            if not _is_windows():
                os.fchmod(descriptor, 0o600)
            with os.fdopen(descriptor, "wb") as stream:
                stream.write(content)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, path)
            if not _is_windows():
                path.chmod(0o600)
        finally:
            Path(temporary).unlink(missing_ok=True)

    def _write_config(self, config: dict):
        self._atomic_write(self.config_path, (json.dumps(config, indent=2) + "\n").encode())

    @staticmethod
    def _environment_key() -> str | None:
        return os.getenv("OPENAI_API_KEY") or os.getenv("TRADINGAGENTS_OPENAI_API_KEY") or None

    def _saved_key(self) -> str | None:
        if not self.key_path.exists():
            return None
        if self.key_path.is_symlink():
            raise ProviderConnectionError("key_storage_unavailable", "The saved key is not a regular local file. Remove the local key and configure it again.")
        try:
            value = self.key_path.read_bytes()
            if value.startswith(b"DPAPI1\0"):
                if not _is_windows():
                    raise ProviderConnectionError("key_storage_unavailable", "This key was protected by a Windows account. Configure your key on this computer.")
                value = _unprotect_windows(value[7:])
            elif value.startswith(b"LOCAL1\0"):
                value = value[7:]
            else:
                raise ValueError
            return value.decode()
        except ProviderConnectionError:
            raise
        except (OSError, ValueError, UnicodeError):
            raise ProviderConnectionError("key_storage_unavailable", "The saved key could not be read. Remove the local key and save it again.") from None

    def get_key(self) -> str | None:
        return self._environment_key() or self._saved_key()

    def sec_contact(self) -> str:
        return os.getenv("SEC_EDGAR_USER_AGENT") or self._read_config().get("sec_edgar_user_agent", "")

    def _identity(self) -> tuple[str | None, str, str]:
        environment = self._environment_key()
        if environment:
            return environment, "environment", "environment"
        saved = self._saved_key()
        return (saved, "local_saved", "windows_dpapi" if _is_windows() else "private_file") if saved else (None, "none", "none")

    def public(self, local_editable: bool = True) -> dict:
        with self._lock:
            config = self._read_config()
            key, source, storage = None, "none", "none"
            error_code = config.get("verification_error")
            try:
                key, source, storage = self._identity()
            except ProviderConnectionError as exc:
                error_code = exc.code
            fingerprint = hashlib.sha256(key.encode()).hexdigest() if key else None
            verification = config.get("verification", {})
            identity_matches = bool(fingerprint and verification.get("key_fingerprint") == fingerprint)
            verified_at = verification.get("checked_at") if identity_matches else None
            try:
                checked = datetime.fromisoformat(verified_at) if verified_at else None
                stamp = datetime.now(UTC)
                fresh = bool(checked and stamp - VERIFY_LIFETIME < checked <= stamp + timedelta(minutes=5))
            except (ValueError, TypeError):
                fresh = False
            observed = bool(identity_matches and verification.get("succeeded"))
            verified = bool(observed and fresh)
            expired = bool(observed and not fresh)
            available = verification.get("available_models", []) if identity_matches else []
            available = [model for model in available if isinstance(model, str) and MODEL_PATTERN.fullmatch(model)
                         and not credential_like_model(model)] if isinstance(available, list) else []
            quick = config.get("quick_model") or DEFAULT_QUICK_MODEL
            deep = config.get("deep_model") or DEFAULT_DEEP_MODEL
            quick = quick if isinstance(quick, str) and not credential_like_model(quick) else ""
            deep = deep if isinstance(deep, str) and not credential_like_model(deep) else ""
            catalog = model_catalog(available, observed=observed)
            issues = selection_issues(quick, deep, available, observed=observed)
            models_validated = verified and not issues and bool(quick and deep)
            execution = config.get("execution_test") or {}
            execution_public = None
            if (fingerprint and execution.get("key_fingerprint") == fingerprint
                    and execution.get("quick_model") == quick and execution.get("deep_model") == deep):
                execution_public = execution.get("result")
            if not key:
                message = "Add your OpenAI API key to enable the real analyst team. Yahoo market prices do not require an OpenAI key."
            elif expired:
                message = "The saved key remains configured. Its model list will be refreshed automatically when you start analysis, or you can test the connection now."
            elif not verified:
                message = config.get("verification_message") if identity_matches else None
                message = message or "A key is configured but has not been verified recently. Test the connection before running research."
            elif not models_validated:
                if not catalog["model_options"]:
                    message = "OpenAI returned no research model candidates for this key. Check project model permissions; audio, embeddings and image models cannot run this analyst team."
                else:
                    message = issues[0]["message"] if issues else "Choose both research models from this account's available choices."
            else:
                message = "OpenAI accepted the key and returned these model IDs. Model listing does not verify analysis billing, generation permissions, or market-data access."
            return {
                "provider": "openai", "key_configured": bool(key), "key_source": source,
                "key_storage": storage, "key_editable": bool(local_editable and source != "environment"),
                "verified": verified, "verified_at": verified_at, "verification_kind": "model_list_only",
                "model_selection_validated": bool(models_validated), "quick_model": quick, "deep_model": deep,
                "verification_expired": expired, "requires_reverification": bool(key and not verified),
                "can_attempt_analysis": bool(key and (not observed or not issues)),
                "selection_issues": issues, **catalog,
                "execution_test": execution_public,
                "available_models": available, "sec_edgar_user_agent": self.sec_contact(),
                "sec_contact_configured": valid_sec_contact(self.sec_contact()),
                "message": message, "error_code": error_code,
            }

    def save(self, body: dict, allow_key_edit: bool) -> dict:
        with self._lock:
            config = self._read_config()
            key = body.get("openai_api_key")
            encoded = None
            if key is not None:
                if not allow_key_edit or self._environment_key():
                    raise ProviderConnectionError("key_edit_forbidden", "Set or change the provider key in your hosting or environment secret settings. Browser key setup is available only in local desktop mode.")
                if not isinstance(key, str) or not 20 <= len(key.strip()) <= 1024 or any(character.isspace() for character in key.strip()):
                    raise ProviderConnectionError("invalid_key", "Enter the complete OpenAI API key, with no spaces. Do not use your ChatGPT password.")
                key_bytes = key.strip().encode()
                encoded = b"DPAPI1\0" + _protect_windows(key_bytes) if _is_windows() else b"LOCAL1\0" + key_bytes
                config.pop("verification", None)
                config.pop("verification_error", None)
                config.pop("verification_message", None)
                config.pop("execution_test", None)
            for name in ("quick_model", "deep_model"):
                value = body.get(name)
                if value is not None:
                    if not isinstance(value, str) or not MODEL_PATTERN.fullmatch(value) or credential_like_model(value):
                        raise ProviderConnectionError("invalid_model", "Use a model ID from your OpenAI account's available model list.")
                    if value != config.get(name):
                        config.pop("execution_test", None)
                    config[name] = value
                    config[name + "_explicit"] = True
            contact = body.get("sec_edgar_user_agent")
            if contact is not None:
                contact = contact.strip()
                if contact and (len(contact) > 200 or not valid_sec_contact(contact)):
                    raise ProviderConnectionError("invalid_sec_contact", "Enter your real contact name and email for SEC filings, or leave this field empty. Example-domain placeholders are not accepted.")
                config["sec_edgar_user_agent"] = contact
            # Reject every field before persisting a new credential. A malformed
            # contact/model must not silently replace a previously working key.
            if encoded is not None:
                self._atomic_write(self.key_path, encoded)
            self._write_config(config)
            return self.public(local_editable=allow_key_edit)

    def delete_key(self, allow_key_edit: bool) -> dict:
        with self._lock:
            if not allow_key_edit or self._environment_key():
                raise ProviderConnectionError("key_edit_forbidden", "Environment-managed credentials must be changed in environment or hosting secret settings.")
            self.key_path.unlink(missing_ok=True)
            config = self._read_config()
            for name in ("verification", "verification_error", "verification_message"):
                config.pop(name, None)
            config.pop("execution_test", None)
            self._write_config(config)
            return self.public(local_editable=True)

    def use_recommended_models(self, local_editable: bool = True) -> dict:
        """Explicit user action; never replace an explicit selection silently."""
        with self._lock:
            public = self.public(local_editable=local_editable)
            if not public["verified"]:
                raise ProviderConnectionError("verification_required", "Refresh your API model list before applying model recommendations.")
            quick, deep = public["recommended_quick_model"], public["recommended_deep_model"]
            if not quick or not deep:
                raise ProviderConnectionError("no_research_models", "OpenAI returned no research model candidates for this key. Check project model permissions.")
            config = self._read_config()
            if config.get("quick_model") != quick or config.get("deep_model") != deep:
                config.pop("execution_test", None)
            config.update(quick_model=quick, deep_model=deep, quick_model_explicit=True, deep_model_explicit=True)
            self._write_config(config)
            return self.public(local_editable=local_editable)

    def record_execution_test(self, metadata: dict, *, expected_key_fingerprint: str,
                              expected_models: dict) -> dict:
        """Record only the safe result of an explicitly requested paid probe."""
        with self._lock:
            key = self.get_key()
            if not key or hashlib.sha256(key.encode()).hexdigest() != expected_key_fingerprint:
                raise ProviderConnectionError("connection_changed", "The provider key changed during the model test. Test the selected models again.")
            config = self._read_config()
            quick, deep = config.get("quick_model") or "", config.get("deep_model") or ""
            if expected_models != {"quick_model": quick, "deep_model": deep}:
                raise ProviderConnectionError("connection_changed", "The model selection changed during the model test. Test the selected models again.")

            def safe_text(value, maximum=400):
                if not isinstance(value, str):
                    return None
                value = value.replace(key, "[redacted]")
                value = re.sub(r"sk-[A-Za-z0-9_-]{12,}", "[redacted]", value)
                value = re.sub(r"https?://\S+", "[link omitted]", value)
                return value[:maximum]

            def safe_code(value):
                return value if isinstance(value, str) and re.fullmatch(r"[a-z0-9_]{1,80}", value) else None

            results = []
            for item in (metadata.get("results") or [])[:4]:
                if not isinstance(item, dict) or item.get("role") not in ("quick", "deep"):
                    continue
                role = item["role"]
                model = expected_models[role + "_model"]
                if item.get("model") != model:
                    raise ProviderConnectionError("connection_changed", "A model result did not match the requested selection. Test the selected models again.")
                results.append({
                    "role": role, "model": model,
                    "status": item.get("status") if item.get("status") in ("passed", "failed", "skipped") else "failed",
                    "check": item.get("check") if item.get("check") in ("tool_call", "structured_output") else "unknown",
                    "error_code": safe_code(item.get("error_code")),
                    "error_action": safe_text(item.get("error_action")),
                    "error_stage": safe_code(item.get("error_stage")),
                    "message": safe_text(item.get("message")), "retryable": item.get("retryable") is True,
                })
            success = (metadata.get("success") is True and len(results) == 2
                       and {item["role"] for item in results} == {"quick", "deep"}
                       and all(item["status"] == "passed" for item in results))
            count = metadata.get("request_count", 0)
            count = count if isinstance(count, int) and not isinstance(count, bool) and 0 <= count <= 2 else 0
            result = {"verification_kind": "generation_probe", "tested_at": datetime.now(UTC).isoformat(),
                      "success": success, "request_count": count, "message": safe_text(metadata.get("message")),
                      "results": results}
            config["execution_test"] = {"key_fingerprint": expected_key_fingerprint,
                                        "quick_model": quick, "deep_model": deep, "result": result}
            self._write_config(config)
            return self.public()

    def test_connection(self) -> dict:
        with self._lock:
            key = self.get_key()
            if not key:
                raise ProviderConnectionError("key_missing", "Save your OpenAI API key first, or configure TRADINGAGENTS_OPENAI_API_KEY in environment settings.")
            fingerprint = hashlib.sha256(key.encode()).hexdigest()
        try:
            available = sorted({model for model in _list_models(key) if isinstance(model, str) and MODEL_PATTERN.fullmatch(model)
                                and not credential_like_model(model)})[:1000]
            error_code, message, succeeded = None, None, True
        except Exception as exc:  # noqa: BLE001 -- provider failures must never expose raw SDK credentials/errors.
            status = getattr(exc, "status_code", None)
            if isinstance(exc, ProviderConnectionError):
                error_code, message = exc.code, exc.message
            elif status == 401:
                error_code, message = "authentication_failed", "OpenAI rejected the key. Create or check the API key in your OpenAI developer account."
            elif status == 403:
                error_code, message = "permission_denied", "OpenAI denied model-list access. Check this key's project and model permissions."
            elif status == 429:
                error_code, message = "rate_limited", "OpenAI limited this request. Check API billing, quota and rate limits, then retry."
            else:
                error_code, message = "connection_failed", "Could not reach OpenAI securely. Check your Internet connection, proxy and provider availability, then retry."
            available, succeeded = [], False
        with self._lock:
            # A concurrent settings change must not verify a different credential.
            current = self.get_key()
            if not current or hashlib.sha256(current.encode()).hexdigest() != fingerprint:
                raise ProviderConnectionError("connection_changed", "The saved key changed during verification. Test the connection again.")
            config = self._read_config()
            if succeeded:
                catalog = model_catalog(available)
                for name, recommendation in (("quick_model", "recommended_quick_model"), ("deep_model", "recommended_deep_model")):
                    if not config.get(name + "_explicit"):
                        # Clear obsolete auto-defaults if only non-chat modalities
                        # remain; do not advertise a shipped fallback as available.
                        selected = catalog[recommendation] or ""
                        if selected != config.get(name):
                            config.pop("execution_test", None)
                        config[name] = selected
            config["verification"] = {"key_fingerprint": fingerprint, "checked_at": datetime.now(UTC).isoformat(),
                                      "succeeded": succeeded, "available_models": available}
            config["verification_error"], config["verification_message"] = error_code, message
            self._write_config(config)
            return self.public()
