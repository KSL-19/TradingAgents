"""Local provider setup and credential checks without exposing credentials.

Windows stores the user's key through user-scoped DPAPI. Other desktop systems
use an owner-only local file. Hosted instances must use their secret settings.
"""

from __future__ import annotations

import ctypes
import hashlib
import json
import os
import re
import tempfile
import threading
from datetime import UTC, datetime, timedelta
from pathlib import Path

DEFAULT_QUICK_MODEL = "gpt-4.1-mini"
DEFAULT_DEEP_MODEL = "gpt-4.1"
MODEL_PATTERN = re.compile(r"^[A-Za-z0-9_.:/\-]{1,100}$")
VERIFY_LIFETIME = timedelta(hours=24)


class ProviderConnectionError(Exception):
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code, self.message = code, message


def _is_windows() -> bool:
    return os.name == "nt"


def _windows_crypt(value: bytes, *, decrypt: bool = False) -> bytes:
    """Use Windows DPAPI for the current logged-in user; forbid GUI prompts."""
    from ctypes import wintypes

    class Blob(ctypes.Structure):
        _fields_ = [("size", wintypes.DWORD), ("data", ctypes.POINTER(ctypes.c_ubyte))]

    crypt32 = ctypes.WinDLL("crypt32", use_last_error=True)
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    buffer = (ctypes.c_ubyte * len(value)).from_buffer_copy(value)
    source, target = Blob(len(value), buffer), Blob()
    if decrypt:
        operation = crypt32.CryptUnprotectData
        operation.restype = wintypes.BOOL
        operation.argtypes = [ctypes.POINTER(Blob), ctypes.c_void_p, ctypes.c_void_p,
                              ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(Blob)]
        result = operation(ctypes.byref(source), None, None, None, None, 1, ctypes.byref(target))
    else:
        operation = crypt32.CryptProtectData
        operation.restype = wintypes.BOOL
        operation.argtypes = [ctypes.POINTER(Blob), wintypes.LPCWSTR, ctypes.c_void_p,
                              ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(Blob)]
        result = operation(ctypes.byref(source), "TradingAgents OpenAI key", None, None, None, 1, ctypes.byref(target))
    kernel32.LocalFree.argtypes = [ctypes.c_void_p]
    kernel32.LocalFree.restype = ctypes.c_void_p
    if not result:
        raise ProviderConnectionError("key_storage_unavailable", "Windows could not protect or unlock the saved key. Save the key again under your Windows account.")
    try:
        return ctypes.string_at(target.data, target.size)
    finally:
        kernel32.LocalFree(target.data)


def _protect_windows(value: bytes) -> bytes:
    return _windows_crypt(value)


def _unprotect_windows(value: bytes) -> bytes:
    return _windows_crypt(value, decrypt=True)


def valid_sec_contact(value: str) -> bool:
    found = re.search(r"[^\s<>@]+@([^\s<>@]+\.[^\s<>@]+)", value)
    return bool(found and found.group(1).lower().strip(".,;") not in {
        "example.com", "example.org", "example.net", "email.com", "yourdomain.com",
    })


def _list_models(key: str) -> list[str]:
    from openai import OpenAI

    with OpenAI(api_key=key, timeout=15, max_retries=0) as client:
        return sorted({model.id for model in client.models.list().data
                       if isinstance(model.id, str) and MODEL_PATTERN.fullmatch(model.id)})[:1000]


class ConnectionSettings:
    def __init__(self, data_dir: Path):
        self.folder = Path(data_dir)
        self.folder.mkdir(parents=True, exist_ok=True)
        if not _is_windows():
            self.folder.chmod(0o700)
        self.config_path = self.folder / "config.json"
        self.key_path = self.folder / "openai.key"
        self._lock = threading.RLock()

    def _read_config(self) -> dict:
        if not self.config_path.exists():
            return {}
        if self.config_path.is_symlink():
            raise ProviderConnectionError("config_unavailable", "The connection settings file is not a regular local file.")
        try:
            value = json.loads(self.config_path.read_text())
            return value if isinstance(value, dict) else {}
        except (OSError, ValueError):
            raise ProviderConnectionError("config_unavailable", "The local connection settings could not be read. Restore the config file or remove it and set up the connection again.") from None

    def _atomic_write(self, path: Path, content: bytes):
        descriptor, temporary = tempfile.mkstemp(prefix=".connection-", dir=self.folder)
        try:
            if not _is_windows():
                os.fchmod(descriptor, 0o600)
            with os.fdopen(descriptor, "wb") as stream:
                stream.write(content)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, path)
            if not _is_windows():
                path.chmod(0o600)
        finally:
            Path(temporary).unlink(missing_ok=True)

    def _write_config(self, config: dict):
        self._atomic_write(self.config_path, (json.dumps(config, indent=2) + "\n").encode())

    @staticmethod
    def _environment_key() -> str | None:
        return os.getenv("OPENAI_API_KEY") or os.getenv("TRADINGAGENTS_OPENAI_API_KEY") or None

    def _saved_key(self) -> str | None:
        if not self.key_path.exists():
            return None
        if self.key_path.is_symlink():
            raise ProviderConnectionError("key_storage_unavailable", "The saved key is not a regular local file. Remove the local key and configure it again.")
        try:
            value = self.key_path.read_bytes()
            if value.startswith(b"DPAPI1\0"):
                if not _is_windows():
                    raise ProviderConnectionError("key_storage_unavailable", "This key was protected by a Windows account. Configure your key on this computer.")
                value = _unprotect_windows(value[7:])
            elif value.startswith(b"LOCAL1\0"):
                value = value[7:]
            else:
                raise ValueError
            return value.decode()
        except ProviderConnectionError:
            raise
        except (OSError, ValueError, UnicodeError):
            raise ProviderConnectionError("key_storage_unavailable", "The saved key could not be read. Remove the local key and save it again.") from None

    def get_key(self) -> str | None:
        return self._environment_key() or self._saved_key()

    def sec_contact(self) -> str:
        return os.getenv("SEC_EDGAR_USER_AGENT") or self._read_config().get("sec_edgar_user_agent", "")

    def _identity(self) -> tuple[str | None, str, str]:
        environment = self._environment_key()
        if environment:
            return environment, "environment", "environment"
        saved = self._saved_key()
        return (saved, "local_saved", "windows_dpapi" if _is_windows() else "private_file") if saved else (None, "none", "none")

    def public(self, local_editable: bool = True) -> dict:
        with self._lock:
            config = self._read_config()
            key, source, storage = None, "none", "none"
            error_code = config.get("verification_error")
            try:
                key, source, storage = self._identity()
            except ProviderConnectionError as exc:
                error_code = exc.code
            fingerprint = hashlib.sha256(key.encode()).hexdigest() if key else None
            verification = config.get("verification", {})
            identity_matches = bool(fingerprint and verification.get("key_fingerprint") == fingerprint)
            verified_at = verification.get("checked_at") if identity_matches else None
            try:
                fresh = bool(verified_at and datetime.fromisoformat(verified_at) > datetime.now(UTC) - VERIFY_LIFETIME)
            except (ValueError, TypeError):
                fresh = False
            verified = bool(identity_matches and verification.get("succeeded") and fresh)
            available = verification.get("available_models", []) if identity_matches else []
            quick = config.get("quick_model") or DEFAULT_QUICK_MODEL
            deep = config.get("deep_model") or DEFAULT_DEEP_MODEL
            models_validated = verified and quick in available and deep in available
            if not key:
                message = "Add your OpenAI API key to enable the real analyst team. Yahoo market prices do not require an OpenAI key."
            elif not verified:
                message = config.get("verification_message") if identity_matches else None
                message = message or "A key is configured but has not been verified recently. Test the connection before running research."
            elif not models_validated:
                message = "OpenAI returned a model list, but one or both selected model IDs are not in it. Choose available models, save, and test again."
            else:
                message = "OpenAI accepted the key and returned these model IDs. Model listing does not verify analysis billing, generation permissions, or market-data access."
            return {
                "provider": "openai", "key_configured": bool(key), "key_source": source,
                "key_storage": storage, "key_editable": bool(local_editable and source != "environment"),
                "verified": verified, "verified_at": verified_at, "verification_kind": "model_list_only",
                "model_selection_validated": bool(models_validated), "quick_model": quick, "deep_model": deep,
                "available_models": available, "sec_edgar_user_agent": self.sec_contact(),
                "sec_contact_configured": valid_sec_contact(self.sec_contact()),
                "message": message, "error_code": error_code,
            }

    def save(self, body: dict, allow_key_edit: bool) -> dict:
        with self._lock:
            config = self._read_config()
            key = body.get("openai_api_key")
            encoded = None
            if key is not None:
                if not allow_key_edit or self._environment_key():
                    raise ProviderConnectionError("key_edit_forbidden", "Set or change the provider key in your hosting or environment secret settings. Browser key setup is available only in local desktop mode.")
                if not isinstance(key, str) or not 20 <= len(key.strip()) <= 1024 or any(character.isspace() for character in key.strip()):
                    raise ProviderConnectionError("invalid_key", "Enter the complete OpenAI API key, with no spaces. Do not use your ChatGPT password.")
                key_bytes = key.strip().encode()
                encoded = b"DPAPI1\0" + _protect_windows(key_bytes) if _is_windows() else b"LOCAL1\0" + key_bytes
                config.pop("verification", None)
                config.pop("verification_error", None)
                config.pop("verification_message", None)
            for name in ("quick_model", "deep_model"):
                value = body.get(name)
                if value is not None:
                    if not isinstance(value, str) or not MODEL_PATTERN.fullmatch(value):
                        raise ProviderConnectionError("invalid_model", "Use a model ID from your OpenAI account's available model list.")
                    config[name] = value
                    config[name + "_explicit"] = True
            contact = body.get("sec_edgar_user_agent")
            if contact is not None:
                contact = contact.strip()
                if contact and (len(contact) > 200 or not valid_sec_contact(contact)):
                    raise ProviderConnectionError("invalid_sec_contact", "Enter your real contact name and email for SEC filings, or leave this field empty. Example-domain placeholders are not accepted.")
                config["sec_edgar_user_agent"] = contact
            # Reject every field before persisting a new credential. A malformed
            # contact/model must not silently replace a previously working key.
            if encoded is not None:
                self._atomic_write(self.key_path, encoded)
            self._write_config(config)
            return self.public(local_editable=allow_key_edit)

    def delete_key(self, allow_key_edit: bool) -> dict:
        with self._lock:
            if not allow_key_edit or self._environment_key():
                raise ProviderConnectionError("key_edit_forbidden", "Environment-managed credentials must be changed in environment or hosting secret settings.")
            self.key_path.unlink(missing_ok=True)
            config = self._read_config()
            for name in ("verification", "verification_error", "verification_message"):
                config.pop(name, None)
            self._write_config(config)
            return self.public(local_editable=True)

    def test_connection(self) -> dict:
        with self._lock:
            key = self.get_key()
            if not key:
                raise ProviderConnectionError("key_missing", "Save your OpenAI API key first, or configure TRADINGAGENTS_OPENAI_API_KEY in environment settings.")
            fingerprint = hashlib.sha256(key.encode()).hexdigest()
        try:
            available = sorted({model for model in _list_models(key) if isinstance(model, str) and MODEL_PATTERN.fullmatch(model)})[:1000]
            error_code, message, succeeded = None, None, True
        except Exception as exc:  # noqa: BLE001 -- provider failures must never expose raw SDK credentials/errors.
            status = getattr(exc, "status_code", None)
            if isinstance(exc, ProviderConnectionError):
                error_code, message = exc.code, exc.message
            elif status == 401:
                error_code, message = "authentication_failed", "OpenAI rejected the key. Create or check the API key in your OpenAI developer account."
            elif status == 403:
                error_code, message = "permission_denied", "OpenAI denied model-list access. Check this key's project and model permissions."
            elif status == 429:
                error_code, message = "rate_limited", "OpenAI limited this request. Check API billing, quota and rate limits, then retry."
            else:
                error_code, message = "connection_failed", "Could not reach OpenAI securely. Check your Internet connection, proxy and provider availability, then retry."
            available, succeeded = [], False
        with self._lock:
            # A concurrent settings change must not verify a different credential.
            current = self.get_key()
            if not current or hashlib.sha256(current.encode()).hexdigest() != fingerprint:
                raise ProviderConnectionError("connection_changed", "The saved key changed during verification. Test the connection again.")
            config = self._read_config()
            if succeeded:
                quick_preferences = (DEFAULT_QUICK_MODEL, "gpt-4o-mini", "gpt-5-mini", DEFAULT_DEEP_MODEL, "gpt-4o")
                deep_preferences = (DEFAULT_DEEP_MODEL, "gpt-4o", "gpt-5", DEFAULT_QUICK_MODEL, "gpt-4o-mini")
                for name, choices in (("quick_model", quick_preferences), ("deep_model", deep_preferences)):
                    if not config.get(name + "_explicit"):
                        match = next((model for model in choices if model in available), None)
                        if match:
                            config[name] = match
            config["verification"] = {"key_fingerprint": fingerprint, "checked_at": datetime.now(UTC).isoformat(),
                                      "succeeded": succeeded, "available_models": available}
            config["verification_error"], config["verification_message"] = error_code, message
            self._write_config(config)
            return self.public()
