"""Private FastAPI dashboard and static frontend host.

Run with ``python -m uvicorn backend.app:app --host 127.0.0.1 --port 8000``.
Set a password for hosting, or explicitly enable loopback-only local mode.
"""

import hashlib
import hmac
import os
import secrets
import threading
import time
from contextlib import asynccontextmanager
from decimal import Decimal
from pathlib import Path
from typing import Literal
from urllib.parse import urlsplit

from fastapi import Depends, FastAPI, HTTPException, Request, Response
from fastapi.exceptions import RequestValidationError
from fastapi.responses import FileResponse, JSONResponse, PlainTextResponse

from .market import MarketService, MarketUnavailable
from .models import LoginInput, Mode, OrderInput, RunInput, SymbolInput
from .store import INITIAL_CASH_CENTS, LedgerError, Store, cents
from .worker import AnalysisManager, live_key_present

ROOT = Path(__file__).resolve().parent.parent
COOKIE = "trading_dashboard_session"


def create_app(data_dir: Path | None = None, *, password: str | None = None, local_mode: bool | None = None) -> FastAPI:
    @asynccontextmanager
    async def lifespan(app: FastAPI):
        secret = password if password is not None else os.getenv("DASHBOARD_PASSWORD", "")
        local = local_mode if local_mode is not None else os.getenv("DASHBOARD_LOCAL_MODE") == "1"
        if not secret and not local:
            raise RuntimeError("Set DASHBOARD_PASSWORD before hosting, or DASHBOARD_LOCAL_MODE=1 for private loopback use.")
        if secret and len(secret) < 12:
            raise RuntimeError("DASHBOARD_PASSWORD must contain at least 12 characters.")
        public_origin = os.getenv("DASHBOARD_PUBLIC_ORIGIN", "").rstrip("/")
        if public_origin:
            parsed = urlsplit(public_origin)
            if parsed.scheme not in ("http", "https") or not parsed.netloc or parsed.path or parsed.username or parsed.password or parsed.query or parsed.fragment:
                raise RuntimeError("DASHBOARD_PUBLIC_ORIGIN must be an HTTP(S) origin without a path or credentials.")
        folder = data_dir or Path(os.getenv("DASHBOARD_DATA_DIR", str(ROOT / ".data")))
        app.state.password = secret
        app.state.local = local
        app.state.public_origin = public_origin
        app.state.sessions = {}
        app.state.failed_logins = {}
        app.state.auth_lock = threading.Lock()
        app.state.store = Store(folder)
        app.state.market = MarketService()
        app.state.manager = AnalysisManager(app.state.store, folder)
        app.state.data_dir = folder
        os.environ.setdefault("XDG_CACHE_HOME", str(folder / "xdg-cache"))
        yield
        app.state.manager.join(timeout=2)

    application = FastAPI(title="TradingAgents Dashboard", version="1.0.0", lifespan=lifespan,
                          docs_url=None, redoc_url=None, openapi_url=None)

    @application.exception_handler(RequestValidationError)
    async def invalid_request(request: Request, exc: RequestValidationError):
        # Pydantic's default response echoes rejected inputs, including a mistyped
        # password or a credential accidentally sent as an unsupported field.
        errors = [{"location": list(error["loc"]), "message": error["msg"]} for error in exc.errors()]
        return JSONResponse(status_code=422, content={
            "detail": "Invalid request. Check the ticker, date, analyst selection and order values.",
            "errors": errors,
        })

    def authenticated(request: Request) -> bool:
        if request.app.state.local and not request.app.state.password:
            return True
        token = request.cookies.get(COOKIE, "")
        if not token:
            return False
        digest = hashlib.sha256(token.encode()).hexdigest()
        with request.app.state.auth_lock:
            expires = request.app.state.sessions.get(digest, 0)
            if expires < time.time():
                request.app.state.sessions.pop(digest, None)
                return False
        return True

    def require_auth(request: Request):
        if not authenticated(request):
            raise HTTPException(401, "Sign in to your private dashboard.")

    @application.middleware("http")
    async def browser_safety(request: Request, call_next):
        # Explicit local mode must not become an unauthenticated public dashboard.
        if hasattr(request.app.state, "local") and request.app.state.local and not request.app.state.password:
            client_host = request.client.host if request.client else ""
            if request.url.hostname not in ("localhost", "127.0.0.1", "::1", "testserver") or client_host not in ("localhost", "127.0.0.1", "::1", "testserver", "testclient"):
                return PlainTextResponse("Local mode accepts loopback hosts only. Configure a password for hosting.", status_code=403)
        if request.method in ("POST", "PUT", "PATCH", "DELETE"):
            origin = request.headers.get("origin")
            fetch_site = request.headers.get("sec-fetch-site")
            if fetch_site == "cross-site":
                return PlainTextResponse("Cross-site requests are not permitted.", status_code=403)
            if origin:
                expected = request.app.state.public_origin or f"{request.url.scheme}://{request.headers.get('host')}"
                # Explicit public origin supports HTTPS reverse proxies without trusting arbitrary forwarded headers.
                if not hmac.compare_digest(origin, expected):
                    return PlainTextResponse("Cross-origin requests are not permitted.", status_code=403)
            elif request.app.state.password and request.headers.get("x-dashboard-client") != "cli":
                return PlainTextResponse("An Origin header or explicit X-Dashboard-Client: cli header is required.", status_code=403)
        response = await call_next(request)
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "no-referrer"
        if request.url.path.startswith("/api/"):
            response.headers["Cache-Control"] = "no-store"
        return response

    @application.get("/api/health")
    def health():
        return {"status": "ok", "service": "tradingagents-dashboard"}

    @application.get("/api/status")
    def status(request: Request):
        return {
            "authenticated": authenticated(request), "auth_required": bool(request.app.state.password),
            "live_available": live_key_present(), "provider": "openai", "default_mode": "demo",
            "version": "0.7.1", "trading_mode": "paper", "quick_model": "gpt-6-luna", "deep_model": "gpt-6-sol",
            "quote_type": "daily bar price", "broker_connected": False,
        }

    @application.post("/api/login")
    def login(body: LoginInput, request: Request, response: Response):
        if request.app.state.local and not request.app.state.password:
            return {"authenticated": True}
        ip = request.client.host if request.client else "unknown"
        stamp = time.monotonic()
        with request.app.state.auth_lock:
            failures = [s for s in request.app.state.failed_logins.get(ip, []) if stamp - s < 300]
            if len(failures) >= 10:
                raise HTTPException(429, "Too many sign-in attempts. Try again in five minutes.")
            if not hmac.compare_digest(body.password.encode(), request.app.state.password.encode()):
                failures.append(stamp)
                # Bounded memory for untrusted source addresses.
                if len(request.app.state.failed_logins) >= 1000:
                    request.app.state.failed_logins.clear()
                request.app.state.failed_logins[ip] = failures
                raise HTTPException(401, "The password is incorrect.")
            request.app.state.failed_logins.pop(ip, None)
            request.app.state.sessions = {k: v for k, v in request.app.state.sessions.items() if v > time.time()}
            if len(request.app.state.sessions) >= 100:
                request.app.state.sessions.pop(next(iter(request.app.state.sessions)))
            token = secrets.token_urlsafe(48)
            request.app.state.sessions[hashlib.sha256(token.encode()).hexdigest()] = time.time() + 12 * 3600
        response.set_cookie(COOKIE, token, max_age=12 * 3600, httponly=True, samesite="strict",
                            secure=os.getenv("DASHBOARD_SECURE_COOKIES") == "1", path="/")
        return {"authenticated": True}

    @application.post("/api/logout")
    def logout(request: Request, response: Response):
        token = request.cookies.get(COOKIE, "")
        with request.app.state.auth_lock:
            request.app.state.sessions.pop(hashlib.sha256(token.encode()).hexdigest(), None)
        response.delete_cookie(COOKIE, path="/")
        return {"authenticated": False}

    def market_quote(request: Request, symbol: str, mode: str, period="3mo"):
        try:
            return request.app.state.market.get(symbol, mode, period)
        except MarketUnavailable as exc:
            raise HTTPException(503, str(exc)) from None

    @application.get("/api/market/{symbol}", dependencies=[Depends(require_auth)])
    def market(symbol: str, request: Request, mode: Mode = "demo", period: Literal["1mo", "3mo", "6mo", "1y"] = "3mo"):
        try:
            normalized = SymbolInput(symbol=symbol).symbol
        except ValueError:
            raise HTTPException(422, "Use a valid ticker symbol of at most 20 characters.") from None
        return market_quote(request, normalized, mode, period)

    @application.get("/api/watchlist", dependencies=[Depends(require_auth)])
    def watchlist(request: Request):
        return {"symbols": request.app.state.store.watchlist()}

    @application.post("/api/watchlist", dependencies=[Depends(require_auth)])
    def add_watchlist(body: SymbolInput, request: Request):
        try:
            return {"symbols": request.app.state.store.add_symbol(body.symbol)}
        except LedgerError as exc:
            raise HTTPException(409, str(exc)) from None

    @application.delete("/api/watchlist/{symbol}", dependencies=[Depends(require_auth)])
    def remove_watchlist(symbol: str, request: Request):
        return {"symbols": request.app.state.store.remove_symbol(symbol.upper())}

    @application.get("/api/runs", dependencies=[Depends(require_auth)])
    def runs(request: Request, mode: Mode | None = None):
        return {"runs": request.app.state.store.list_runs(mode)}

    @application.post("/api/runs", status_code=202, dependencies=[Depends(require_auth)])
    def run(body: RunInput, request: Request):
        if body.mode == "live" and not live_key_present():
            raise HTTPException(503, "Add your OpenAI key securely as TRADINGAGENTS_OPENAI_API_KEY in environment settings to run live analysis.")
        payload = request.app.state.manager.submit(body.model_dump(mode="json"))
        if payload is None:
            raise HTTPException(409, "An analysis is already running. Wait for it to finish before starting another.")
        return payload

    def find_run(request: Request, run_id: str):
        found = request.app.state.store.get_run(run_id)
        if not found:
            raise HTTPException(404, "This analysis was not found.")
        return found

    @application.get("/api/runs/{run_id}", dependencies=[Depends(require_auth)])
    def run_detail(run_id: str, request: Request):
        return find_run(request, run_id)

    @application.get("/api/runs/{run_id}/report", dependencies=[Depends(require_auth)])
    def report(run_id: str, request: Request):
        payload = find_run(request, run_id)
        if payload["status"] != "completed":
            raise HTTPException(409, "The analysis report is not complete yet.")
        label = "DEMONSTRATION — synthetic prices and illustrative reports" if payload["mode"] == "demo" else "TradingAgents research — not a broker execution"
        text = f"# {payload['symbol']} · {payload['date']}\n\n{label}\n\n"
        text += "\n\n".join(f"## {key.replace('_', ' ').title()}\n\n{value}" for key, value in payload["reports"].items() if value)
        return PlainTextResponse(text, media_type="text/markdown", headers={"Content-Disposition": f'attachment; filename="analysis-{run_id}.md"'})

    def portfolio_payload(request: Request, mode: str):
        account, stored, orders = request.app.state.store.account(mode)
        positions, errors = [], []
        market_cents, pnl_cents = 0, 0
        for position in stored:
            quantity = Decimal(position["quantity"])
            try:
                quote = request.app.state.market.get(position["symbol"], mode)
                if quote.get("currency") != "USD":
                    raise MarketUnavailable("The position's quote currency could not be verified as USD.")
                price = quote["price"]
                value = cents(Decimal(str(price)) * quantity)
                unrealized = value - position["cost_basis_cents"]
                market_cents += value
                pnl_cents += unrealized
                source, as_of = quote["source"], quote["as_of"]
            except MarketUnavailable:
                # Preserve the position and make unavailable valuations explicit.
                price, value, unrealized, source, as_of = None, None, None, "Price unavailable", None
                errors.append(position["symbol"])
            positions.append({"symbol": position["symbol"], "quantity": float(quantity),
                              "average_price": float(Decimal(position["cost_basis_cents"]) / 100 / quantity),
                              "price": price, "market_value": value / 100 if value is not None else None,
                              "unrealized_pnl": unrealized / 100 if unrealized is not None else None,
                              "as_of": as_of, "source": source})
        return {"mode": mode, "cash": account["cash_cents"] / 100, "buying_power": account["cash_cents"] / 100,
                "equity": (account["cash_cents"] + market_cents) / 100 if not errors else None,
                "unrealized_pnl": pnl_cents / 100 if not errors else None, "realized_pnl": account["realized_cents"] / 100,
                "initial_cash": INITIAL_CASH_CENTS / 100, "positions": positions, "orders": orders, "quote_errors": errors}

    @application.get("/api/portfolio", dependencies=[Depends(require_auth)])
    def portfolio(request: Request, mode: Mode = "demo"):
        return portfolio_payload(request, mode)

    @application.post("/api/orders", status_code=201, dependencies=[Depends(require_auth)])
    def order(body: OrderInput, request: Request):
        quote = market_quote(request, body.symbol, body.mode)
        try:
            result = request.app.state.store.fill(body.mode, body.symbol, body.side, body.quantity, quote)
        except LedgerError as exc:
            raise HTTPException(422, str(exc)) from None
        return {"order": result, "portfolio": portfolio_payload(request, body.mode)}

    @application.get("/{path:path}")
    def frontend(path: str):
        if path.startswith("api/"):
            raise HTTPException(404, "API route not found.")
        dist = ROOT / "frontend" / "dist"
        candidate = (dist / path).resolve()
        if path and candidate.is_relative_to(dist.resolve()) and candidate.is_file():
            return FileResponse(candidate)
        index = dist / "index.html"
        if index.is_file():
            return FileResponse(index)
        return PlainTextResponse("TradingAgents dashboard API is running. Build frontend/dist to open the dashboard.", status_code=503)

    return application


app = create_app()
