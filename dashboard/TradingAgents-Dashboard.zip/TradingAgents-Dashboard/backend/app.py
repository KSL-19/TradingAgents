"""Private FastAPI dashboard and static frontend host.

Run with ``python -m uvicorn backend.app:app --host 127.0.0.1 --port 8000``.
Set a password for hosting, or explicitly enable loopback-only local mode.
"""

import hashlib
import hmac
import json
import os
import re
import secrets
import threading
import time
from contextlib import asynccontextmanager
from decimal import Decimal
from pathlib import Path
from typing import Literal
from urllib.parse import urlsplit

from fastapi import Depends, FastAPI, HTTPException, Request, Response
from fastapi.exceptions import RequestValidationError
from fastapi.responses import FileResponse, JSONResponse, PlainTextResponse

from .catalog import credential_like_model, is_research_candidate
from .connections import ConnectionSettings, ProviderConnectionError, valid_sec_contact
from .market import MarketService, MarketUnavailable
from .models import (
    ConnectionsInput,
    LoginInput,
    Mode,
    OrderInput,
    RunInput,
    SymbolInput,
)
from .provider_errors import failure_for
from .store import INITIAL_CASH_CENTS, LedgerError, Store, cents
from .worker import AnalysisManager

ROOT = Path(__file__).resolve().parent.parent
COOKIE = "trading_dashboard_session"


class PreflightFailure(Exception):
    def __init__(self, code: str, stage: str, status_code: int = 409):
        self.failure = failure_for(code, stage)
        self.status_code = status_code
        super().__init__(self.failure.message)


def create_app(data_dir: Path | None = None, *, password: str | None = None, local_mode: bool | None = None) -> FastAPI:
    @asynccontextmanager
    async def lifespan(app: FastAPI):
        secret = password if password is not None else os.getenv("DASHBOARD_PASSWORD", "")
        local = local_mode if local_mode is not None else os.getenv("DASHBOARD_LOCAL_MODE") == "1"
        if not secret and not local:
            raise RuntimeError("Set DASHBOARD_PASSWORD before hosting, or DASHBOARD_LOCAL_MODE=1 for private loopback use.")
        if secret and len(secret) < 12:
            raise RuntimeError("DASHBOARD_PASSWORD must contain at least 12 characters.")
        public_origin = os.getenv("DASHBOARD_PUBLIC_ORIGIN", "").rstrip("/")
        if public_origin:
            parsed = urlsplit(public_origin)
            if parsed.scheme not in ("http", "https") or not parsed.netloc or parsed.path or parsed.username or parsed.password or parsed.query or parsed.fragment:
                raise RuntimeError("DASHBOARD_PUBLIC_ORIGIN must be an HTTP(S) origin without a path or credentials.")
        folder = data_dir or Path(os.getenv("DASHBOARD_DATA_DIR", str(ROOT / ".data")))
        app.state.password = secret
        app.state.local = local
        app.state.public_origin = public_origin
        app.state.sessions = {}
        app.state.failed_logins = {}
        app.state.auth_lock = threading.Lock()
        app.state.store = Store(folder)
        app.state.market = MarketService()
        app.state.connections = ConnectionSettings(folder)
        app.state.manager = AnalysisManager(app.state.store, folder)
        app.state.data_dir = folder
        os.environ.setdefault("XDG_CACHE_HOME", str(folder / "xdg-cache"))
        yield
        app.state.manager.join(timeout=2)

    application = FastAPI(title="TradingAgents Dashboard", version="1.2.0", lifespan=lifespan,
                          docs_url=None, redoc_url=None, openapi_url=None)

    @application.exception_handler(RequestValidationError)
    async def invalid_request(request: Request, exc: RequestValidationError):
        # Pydantic's default response echoes rejected inputs, including a mistyped
        # password or a credential accidentally sent as an unsupported field.
        errors = [{"location": list(error["loc"]), "message": error["msg"]} for error in exc.errors()]
        return JSONResponse(status_code=422, content={
            "detail": "Invalid request. Check the ticker, date, analyst selection and order values.",
            "errors": errors,
        })

    def authenticated(request: Request) -> bool:
        if request.app.state.local and not request.app.state.password:
            return True
        token = request.cookies.get(COOKIE, "")
        if not token:
            return False
        digest = hashlib.sha256(token.encode()).hexdigest()
        with request.app.state.auth_lock:
            expires = request.app.state.sessions.get(digest, 0)
            if expires < time.time():
                request.app.state.sessions.pop(digest, None)
                return False
        return True

    def require_auth(request: Request):
        if not authenticated(request):
            raise HTTPException(401, "Sign in to your private dashboard.")

    def local_key_editable(request: Request) -> bool:
        peer = request.client.host if request.client else ""
        return bool(request.app.state.local
                    and request.url.hostname in ("localhost", "127.0.0.1", "::1", "testserver")
                    and peer in ("localhost", "127.0.0.1", "::1", "testserver", "testclient"))

    @application.exception_handler(PreflightFailure)
    async def preflight_error(request: Request, exc: PreflightFailure):
        failure = exc.failure
        return JSONResponse(status_code=exc.status_code, content={
            "detail": failure.message, "error_code": failure.code, "error_action": failure.action,
            "error_stage": failure.stage, "retryable": failure.retryable,
        })

    @application.exception_handler(ProviderConnectionError)
    async def connection_error(request: Request, exc: ProviderConnectionError):
        status_code = 403 if exc.code == "key_edit_forbidden" else 400
        return JSONResponse(status_code=status_code, content={"detail": exc.message, "error_code": exc.code})

    @application.middleware("http")
    async def browser_safety(request: Request, call_next):
        # Explicit local mode must not become an unauthenticated public dashboard.
        if hasattr(request.app.state, "local") and request.app.state.local and not request.app.state.password:
            client_host = request.client.host if request.client else ""
            if request.url.hostname not in ("localhost", "127.0.0.1", "::1", "testserver") or client_host not in ("localhost", "127.0.0.1", "::1", "testserver", "testclient"):
                return PlainTextResponse("Local mode accepts loopback hosts only. Configure a password for hosting.", status_code=403)
        if request.method in ("POST", "PUT", "PATCH", "DELETE"):
            origin = request.headers.get("origin")
            fetch_site = request.headers.get("sec-fetch-site")
            if fetch_site == "cross-site":
                return PlainTextResponse("Cross-site requests are not permitted.", status_code=403)
            if origin:
                expected = request.app.state.public_origin or f"{request.url.scheme}://{request.headers.get('host')}"
                # Explicit public origin supports HTTPS reverse proxies without trusting arbitrary forwarded headers.
                if not hmac.compare_digest(origin, expected):
                    return PlainTextResponse("Cross-origin requests are not permitted.", status_code=403)
            elif request.app.state.password and request.headers.get("x-dashboard-client") != "cli":
                return PlainTextResponse("An Origin header or explicit X-Dashboard-Client: cli header is required.", status_code=403)
        response = await call_next(request)
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "no-referrer"
        if request.url.path.startswith("/api/"):
            response.headers["Cache-Control"] = "no-store"
        return response

    @application.get("/api/health")
    def health():
        return {"status": "ok", "service": "tradingagents-dashboard"}

    @application.get("/api/status")
    def status(request: Request):
        connection = request.app.state.connections.public(local_editable=local_key_editable(request))
        models = {name: connection.get(name) for name in (
            "model_options", "recommended_quick_model", "recommended_deep_model", "selection_issues",
            "unavailable_requested_options", "verification_expired", "requires_reverification",
            "can_attempt_analysis", "execution_test",
        )}
        failed = next((item for item in request.app.state.store.list_runs("live") if item.get("status") == "failed"), None)
        last_error = None
        if failed and failed.get("error_code"):
            last_error = failure_for(failed["error_code"], failed.get("error_stage")).as_job_fields()
        return {
            **models, "last_analysis_failure": last_error,
            "authenticated": authenticated(request), "auth_required": bool(request.app.state.password),
            "live_available": connection["key_configured"], "ai_available": connection["key_configured"],
            "ai_verified": connection["verified"], "model_selection_validated": connection["model_selection_validated"],
            "provider": "openai", "default_mode": "live", "app_version": "1.2.0",
            "version": "0.7.1", "trading_mode": "paper", "quick_model": connection["quick_model"],
            "deep_model": connection["deep_model"], "market_data_requires_key": False,
            "quote_type": "provider-timestamped regular-session quote", "broker_connected": False,
        }

    @application.get("/api/connections", dependencies=[Depends(require_auth)])
    def connections(request: Request):
        return request.app.state.connections.public(local_editable=local_key_editable(request))

    @application.put("/api/connections", dependencies=[Depends(require_auth)])
    def save_connections(body: ConnectionsInput, request: Request):
        if request.app.state.manager.busy:
            raise HTTPException(409, "Wait for the current analysis to finish before changing connection settings.")
        values = body.model_dump(exclude_none=True)
        if body.openai_api_key is not None:
            values["openai_api_key"] = body.openai_api_key.get_secret_value()
        return request.app.state.connections.save(values, allow_key_edit=local_key_editable(request))

    @application.post("/api/connections/test", dependencies=[Depends(require_auth)])
    def test_connections(request: Request):
        request.app.state.connections.test_connection()
        return request.app.state.connections.public(local_editable=local_key_editable(request))

    def verified_connection(request: Request):
        connection = request.app.state.connections.public(local_editable=local_key_editable(request))
        if not connection["key_configured"]:
            raise PreflightFailure("credential_missing", "model_preflight", 503)
        if not connection["verified"]:
            # A model-list request is free of generation. Expired checks do not
            # strand an otherwise configured key behind a disabled UI button.
            request.app.state.connections.test_connection()
            connection = request.app.state.connections.public(local_editable=local_key_editable(request))
        if not connection["verified"]:
            code = {
                "authentication_failed": "authentication_failed", "permission_denied": "permission_denied",
                "rate_limited": "rate_limited", "connection_failed": "provider_connection_failed",
                "key_missing": "credential_missing", "key_storage_unavailable": "authentication_failed",
            }.get(connection.get("error_code"), "provider_connection_failed")
            raise PreflightFailure(code, "model_preflight", 503)
        return connection

    @application.post("/api/connections/recommendations", dependencies=[Depends(require_auth)])
    def recommended_models(request: Request):
        if request.app.state.manager.busy:
            raise HTTPException(409, "Wait for the current analysis or execution check to finish before changing models.")
        verified_connection(request)
        return request.app.state.connections.use_recommended_models(local_editable=local_key_editable(request))

    @application.post("/api/connections/probe", dependencies=[Depends(require_auth)])
    def execution_probe(request: Request):
        # This endpoint is never called by save/test/startup/preflight. The UI
        # explicitly labels it as a paid, user-triggered generation check.
        if request.app.state.manager.busy:
            raise HTTPException(409, "Wait for the current analysis or execution check to finish.")
        connection = verified_connection(request)
        models = {"quick_model": connection["quick_model"], "deep_model": connection["deep_model"]}
        if any(model not in connection["available_models"] or not is_research_candidate(model)
               for model in models.values()):
            raise PreflightFailure("model_not_available", "model_preflight", 422)
        key = request.app.state.connections.get_key()
        if not key:
            raise PreflightFailure("credential_missing", "model_preflight", 503)
        fingerprint = hashlib.sha256(key.encode()).hexdigest()
        result = request.app.state.manager.probe(models, fingerprint)
        if result is None:
            raise HTTPException(409, "An analysis or execution check is already running.")
        saved = request.app.state.connections.record_execution_test(
            result, expected_key_fingerprint=fingerprint, expected_models=models,
        )
        # Return only the helper's validated public metadata, never the child
        # process's untrusted response object or provider body.
        return saved["execution_test"]

    @application.delete("/api/connections/key", dependencies=[Depends(require_auth)])
    def delete_connection_key(request: Request):
        if request.app.state.manager.busy:
            raise HTTPException(409, "Wait for the current analysis to finish before removing the saved key.")
        return request.app.state.connections.delete_key(allow_key_edit=local_key_editable(request))

    @application.post("/api/login")
    def login(body: LoginInput, request: Request, response: Response):
        if request.app.state.local and not request.app.state.password:
            return {"authenticated": True}
        ip = request.client.host if request.client else "unknown"
        stamp = time.monotonic()
        with request.app.state.auth_lock:
            failures = [s for s in request.app.state.failed_logins.get(ip, []) if stamp - s < 300]
            if len(failures) >= 10:
                raise HTTPException(429, "Too many sign-in attempts. Try again in five minutes.")
            if not hmac.compare_digest(body.password.encode(), request.app.state.password.encode()):
                failures.append(stamp)
                # Bounded memory for untrusted source addresses.
                if len(request.app.state.failed_logins) >= 1000:
                    request.app.state.failed_logins.clear()
                request.app.state.failed_logins[ip] = failures
                raise HTTPException(401, "The password is incorrect.")
            request.app.state.failed_logins.pop(ip, None)
            request.app.state.sessions = {k: v for k, v in request.app.state.sessions.items() if v > time.time()}
            if len(request.app.state.sessions) >= 100:
                request.app.state.sessions.pop(next(iter(request.app.state.sessions)))
            token = secrets.token_urlsafe(48)
            request.app.state.sessions[hashlib.sha256(token.encode()).hexdigest()] = time.time() + 12 * 3600
        response.set_cookie(COOKIE, token, max_age=12 * 3600, httponly=True, samesite="strict",
                            secure=os.getenv("DASHBOARD_SECURE_COOKIES") == "1", path="/")
        return {"authenticated": True}

    @application.post("/api/logout")
    def logout(request: Request, response: Response):
        token = request.cookies.get(COOKIE, "")
        with request.app.state.auth_lock:
            request.app.state.sessions.pop(hashlib.sha256(token.encode()).hexdigest(), None)
        response.delete_cookie(COOKIE, path="/")
        return {"authenticated": False}

    def market_quote(request: Request, symbol: str, mode: str, period="3mo", refresh=False):
        try:
            return request.app.state.market.get(symbol, mode, period, force_refresh=refresh)
        except MarketUnavailable as exc:
            raise HTTPException(503, str(exc)) from None

    @application.get("/api/market/{symbol}", dependencies=[Depends(require_auth)])
    def market(symbol: str, request: Request, mode: Mode = "live", period: Literal["1mo", "3mo", "6mo", "1y"] = "3mo", refresh: bool = False):
        try:
            normalized = SymbolInput(symbol=symbol).symbol
        except ValueError:
            raise HTTPException(422, "Use a valid ticker symbol of at most 20 characters.") from None
        return market_quote(request, normalized, mode, period, refresh)

    @application.get("/api/watchlist", dependencies=[Depends(require_auth)])
    def watchlist(request: Request):
        return {"symbols": request.app.state.store.watchlist()}

    @application.post("/api/watchlist", dependencies=[Depends(require_auth)])
    def add_watchlist(body: SymbolInput, request: Request):
        try:
            return {"symbols": request.app.state.store.add_symbol(body.symbol)}
        except LedgerError as exc:
            raise HTTPException(409, str(exc)) from None

    @application.delete("/api/watchlist/{symbol}", dependencies=[Depends(require_auth)])
    def remove_watchlist(symbol: str, request: Request):
        return {"symbols": request.app.state.store.remove_symbol(symbol.upper())}

    @application.get("/api/runs", dependencies=[Depends(require_auth)])
    def runs(request: Request, mode: Mode | None = None):
        return {"runs": request.app.state.store.list_runs(mode)}

    def prepare_analysis(body: RunInput, request: Request):
        connection = request.app.state.connections.public(local_editable=local_key_editable(request))
        if body.mode == "live":
            connection = verified_connection(request)
        inputs = body.model_dump(mode="json")
        inputs["quick_model"] = body.quick_model or connection["quick_model"]
        inputs["deep_model"] = body.deep_model or connection["deep_model"]
        if body.mode == "live":
            selected = (inputs["quick_model"], inputs["deep_model"])
            if any(not model or credential_like_model(model) or model not in connection["available_models"]
                   or not is_research_candidate(model) for model in selected):
                raise PreflightFailure("model_not_available", "model_preflight", 422)
            if "fundamentals" in body.analysts and not valid_sec_contact(request.app.state.connections.sec_contact()):
                raise HTTPException(422, "Fundamentals uses SEC filings. Add your real contact name and email in Connections & settings before selecting this analyst.")
            try:
                quote = request.app.state.market.get(body.symbol, "live", "1mo", force_refresh=True)
            except MarketUnavailable:
                raise PreflightFailure("market_data_unavailable", "market_preflight", 503) from None
            latest = request.app.state.connections.public(local_editable=local_key_editable(request))
            if (not latest["verified"] or latest["verified_at"] != connection["verified_at"]
                    or latest["quick_model"] != connection["quick_model"] or latest["deep_model"] != connection["deep_model"]):
                raise HTTPException(409, "The provider connection changed while checking market data. Retry the readiness check with the current saved models.")
            if "fundamentals" in body.analysts and not valid_sec_contact(request.app.state.connections.sec_contact()):
                raise HTTPException(422, "The SEC contact changed while checking market data. Configure a real contact before retrying fundamentals.")
            inputs["data_snapshot"] = {
                "context": "Current quote fetched at run start; separate from the requested analysis date",
                "provider": "Yahoo Finance", "source": quote.get("source"), "price": quote.get("price"),
                "currency": quote.get("currency"), "quote_as_of": quote.get("quote_as_of") or quote.get("as_of"),
                "quote_date": quote.get("quote_date") or quote.get("as_of"), "fetched_at": quote.get("fetched_at"),
                "price_type": quote.get("price_type"),
            }
        inputs["provenance"] = {
            "provider": "openai" if body.mode == "live" else "illustrative_demo",
            "quick_model": inputs["quick_model"], "deep_model": inputs["deep_model"],
            "requested_analysts": body.analysts, "models_list_verified_at": connection["verified_at"] if body.mode == "live" else None,
            "analysis_date": body.date, "started_at": None, "generated_at": None,
            "source_coverage_note": "Source coverage depends on provider availability; completion does not confirm every selected source responded.",
        }
        return inputs

    @application.post("/api/analysis/check", dependencies=[Depends(require_auth)])
    def analysis_readiness(body: RunInput, request: Request):
        if request.app.state.manager.busy:
            raise HTTPException(409, "Wait for the current analysis or execution check to finish.")
        inputs = prepare_analysis(body, request)
        return {"ready": True, "generation_tested": False, "request_kind": "non_generation_preflight",
                "message": "Key, selected model listing and market-data preflight passed. No AI generation was requested.",
                "quick_model": inputs["quick_model"], "deep_model": inputs["deep_model"],
                "data_snapshot": inputs.get("data_snapshot"), "analysis_date": inputs["date"]}

    @application.post("/api/runs", status_code=202, dependencies=[Depends(require_auth)])
    def run(body: RunInput, request: Request):
        if request.app.state.manager.busy:
            raise HTTPException(409, "An analysis or execution check is already running. Wait for it to finish.")
        inputs = prepare_analysis(body, request)
        payload = request.app.state.manager.submit(inputs)
        if payload is None:
            raise HTTPException(409, "An analysis or execution check is already running. Wait for it to finish.")
        return payload

    def find_run(request: Request, run_id: str):
        found = request.app.state.store.get_run(run_id)
        if not found:
            raise HTTPException(404, "This analysis was not found.")
        return found

    @application.get("/api/runs/{run_id}", dependencies=[Depends(require_auth)])
    def run_detail(run_id: str, request: Request):
        return find_run(request, run_id)

    @application.get("/api/runs/{run_id}/diagnostics", dependencies=[Depends(require_auth)])
    def diagnostics(run_id: str, request: Request):
        payload = find_run(request, run_id)
        def model_id(value):
            if (isinstance(value, str) and len(value) <= 100 and not credential_like_model(value)
                    and re.fullmatch(r"[A-Za-z0-9_.:/\-]+", value)):
                return value
            return None
        failure = failure_for(payload.get("error_code"), payload.get("error_stage")) if payload.get("status") == "failed" else None
        diagnostic = {
            "format_version": 1, "app_version": "1.2.0", "run_id": payload["id"],
            "symbol": payload["symbol"], "analysis_date": payload.get("date"), "mode": payload["mode"],
            "status": payload["status"], "quick_model": model_id(payload.get("quick_model")),
            "deep_model": model_id(payload.get("deep_model")), "analysts": payload.get("analysts", []),
            "created_at": payload.get("created_at"), "updated_at": payload.get("updated_at"),
            "failure": failure.as_dict() if failure else None,
            "execution_limits": {"output_tokens_per_call": 8192, "sdk_timeout_seconds": 120,
                                 "sdk_retries": 1, "analysis_timeout_seconds": 900},
            "note": "Credential-free diagnostics. This does not include provider response bodies, prompts, tool results, or environment values.",
        }
        text = json.dumps(diagnostic, indent=2) + "\n"
        return PlainTextResponse(text, media_type="application/json", headers={
            "Content-Disposition": f'attachment; filename="analysis-{run_id}-diagnostics.json"',
        })

    @application.get("/api/runs/{run_id}/report", dependencies=[Depends(require_auth)])
    def report(run_id: str, request: Request):
        payload = find_run(request, run_id)
        if payload["status"] != "completed":
            raise HTTPException(409, "The analysis report is not complete yet.")
        label = "DEMONSTRATION — synthetic prices and illustrative reports" if payload["mode"] == "demo" else "TradingAgents research — not a broker execution"
        text = f"# {payload['symbol']} · {payload['date']}\n\n{label}\n\n"
        provenance = payload.get("provenance") or {}
        if provenance:
            text += (f"Provider: {provenance.get('provider')}\n\nAnalyst model: {provenance.get('quick_model')}\n\n"
                     f"Decision model: {provenance.get('deep_model')}\n\nGenerated at: {provenance.get('generated_at') or payload.get('updated_at')}\n\n")
        snapshot = payload.get("data_snapshot") or {}
        if snapshot:
            text += (f"Quote context: {snapshot.get('context')}\n\nQuote source: {snapshot.get('source')}\n\n"
                     f"Quote: {snapshot.get('price')} {snapshot.get('currency')} at {snapshot.get('quote_as_of')}\n\n"
                     f"Fetched at: {snapshot.get('fetched_at')}\n\n")
        coverage = payload.get("source_coverage") or {}
        if coverage:
            text += "## Data-source coverage\n\n"
            text += "Attempted tools: " + (", ".join(coverage.get("attempted_tools", [])) or "No tool calls were observed") + "\n\n"
            text += "Unavailable tools: " + (", ".join(coverage.get("unavailable_tools", [])) or "None explicitly identified") + "\n\n"
            text += "\n".join("- " + limitation for limitation in coverage.get("limitations", [])) + "\n\n"
        text += "\n\n".join(f"## {key.replace('_', ' ').title()}\n\n{value}" for key, value in payload["reports"].items() if value)
        return PlainTextResponse(text, media_type="text/markdown", headers={"Content-Disposition": f'attachment; filename="analysis-{run_id}.md"'})

    def portfolio_payload(request: Request, mode: str):
        account, stored, orders = request.app.state.store.account(mode)
        positions, errors = [], []
        market_cents, pnl_cents = 0, 0
        for position in stored:
            quantity = Decimal(position["quantity"])
            try:
                quote = request.app.state.market.get(position["symbol"], mode)
                if quote.get("currency") != "USD":
                    raise MarketUnavailable("The position's quote currency could not be verified as USD.")
                price = quote["price"]
                value = cents(Decimal(str(price)) * quantity)
                unrealized = value - position["cost_basis_cents"]
                market_cents += value
                pnl_cents += unrealized
                source, as_of = quote["source"], quote["as_of"]
            except MarketUnavailable:
                # Preserve the position and make unavailable valuations explicit.
                price, value, unrealized, source, as_of = None, None, None, "Price unavailable", None
                errors.append(position["symbol"])
            positions.append({"symbol": position["symbol"], "quantity": float(quantity),
                              "average_price": float(Decimal(position["cost_basis_cents"]) / 100 / quantity),
                              "price": price, "market_value": value / 100 if value is not None else None,
                              "unrealized_pnl": unrealized / 100 if unrealized is not None else None,
                              "as_of": as_of, "source": source})
        return {"mode": mode, "cash": account["cash_cents"] / 100, "buying_power": account["cash_cents"] / 100,
                "equity": (account["cash_cents"] + market_cents) / 100 if not errors else None,
                "unrealized_pnl": pnl_cents / 100 if not errors else None, "realized_pnl": account["realized_cents"] / 100,
                "initial_cash": INITIAL_CASH_CENTS / 100, "positions": positions, "orders": orders, "quote_errors": errors}

    @application.get("/api/portfolio", dependencies=[Depends(require_auth)])
    def portfolio(request: Request, mode: Mode = "live"):
        return portfolio_payload(request, mode)

    @application.post("/api/orders", status_code=201, dependencies=[Depends(require_auth)])
    def order(body: OrderInput, request: Request):
        quote = market_quote(request, body.symbol, body.mode)
        try:
            result = request.app.state.store.fill(body.mode, body.symbol, body.side, body.quantity, quote)
        except LedgerError as exc:
            raise HTTPException(422, str(exc)) from None
        return {"order": result, "portfolio": portfolio_payload(request, body.mode)}

    @application.get("/{path:path}")
    def frontend(path: str):
        if path.startswith("api/"):
            raise HTTPException(404, "API route not found.")
        dist = ROOT / "frontend" / "dist"
        candidate = (dist / path).resolve()
        if path and candidate.is_relative_to(dist.resolve()) and candidate.is_file():
            return FileResponse(candidate)
        index = dist / "index.html"
        if index.is_file():
            return FileResponse(index)
        return PlainTextResponse("TradingAgents dashboard API is running. Build frontend/dist to open the dashboard.", status_code=503)

    return application


app = create_app()
