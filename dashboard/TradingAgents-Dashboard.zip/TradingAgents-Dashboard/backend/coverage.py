"""Credential-free observations about data-tool results captured in a run.

This is an availability summary, not a verifier of financial facts. It never
persists tool bodies, model prose, URLs, message IDs, or credential values.
"""

import json
import re
from collections.abc import Mapping, Sequence

_TOOLS = frozenset({
    "get_stock_data", "get_indicators", "get_verified_market_snapshot",
    "get_fundamentals", "get_balance_sheet", "get_cashflow", "get_income_statement",
    "get_news", "get_global_news", "get_insider_transactions", "get_macro_indicators",
    "get_prediction_markets",
})
_ANALYST_TOOLS = {
    "market": {"get_stock_data", "get_indicators", "get_verified_market_snapshot"},
    "news": {"get_news", "get_global_news", "get_macro_indicators", "get_prediction_markets"},
    "fundamentals": {"get_fundamentals", "get_balance_sheet", "get_cashflow", "get_income_statement", "get_insider_transactions"},
    # Social feeds are prefetched by the upstream node rather than emitted as
    # ToolMessages. Their absence here must never be reported as a failed fetch.
    "social": set(),
}
_UNAVAILABLE_PREFIX = re.compile(
    r"^\s*(?:\*\*)?(?:DATA_UNAVAILABLE|NO_DATA_AVAILABLE|VENDOR_UNAVAILABLE|TOOL_ERROR|ERROR)"
    r"(?:\*\*)?\s*[:\-]", re.IGNORECASE,
)
_ERROR_ACTION_PREFIX = re.compile(r"^\s*error\s+(?:fetching|retrieving|calling|accessing|loading)\b", re.IGNORECASE)
_NO_RESULTS_PREFIX = re.compile(
    r"^\s*no\s+(?:usable\s+market\s+data|news|data|articles|posts|results|filings)"
    r"\s+(?:found|available|returned|for|in)\b", re.IGNORECASE,
)
_ANGLE_STATUS_PREFIX = re.compile(r"^\s*<[^>\n]{0,200}\bunavailable\b", re.IGNORECASE)
_MAX_MESSAGES = 2000
_MAX_CONTENT = 25_000


def _field(message, key, default=None):
    return message.get(key, default) if isinstance(message, Mapping) else getattr(message, key, default)


def _tool_messages(messages):
    stack = [(messages, 0)]
    visited = 0
    while stack and visited < _MAX_MESSAGES:
        value, depth = stack.pop()
        visited += 1
        if isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray)):
            if depth < 5:
                stack.extend((item, depth + 1) for item in reversed(value[:_MAX_MESSAGES]))
            continue
        if _field(value, "type") == "tool" or _field(value, "role") == "tool":
            yield value


def _content_state(content, depth=0):
    """Return a conservative classification, without returning the content."""
    if depth > 4:
        return "output"
    if content is None or content == "" or content == [] or content == {}:
        return "empty"
    if isinstance(content, Mapping):
        status = content.get("status")
        if content.get("success") is False or (isinstance(status, str) and status.lower() in {
            "error", "failed", "unavailable", "no_data", "no_results",
        }) or bool(content.get("error")):
            return "unavailable"
        if content.get("type") == "text" and isinstance(content.get("text"), str):
            return _content_state(content["text"], depth + 1)
        return "output"
    if isinstance(content, Sequence) and not isinstance(content, (str, bytes, bytearray)):
        states = [_content_state(item, depth + 1) for item in content[:100]]
        return "unavailable" if "unavailable" in states else "output" if "output" in states else "empty"
    if not isinstance(content, str):
        return "output"
    text = content[:_MAX_CONTENT].strip()
    if not text:
        return "empty"
    if text.startswith("```"):
        lines = text.splitlines()
        text = "\n".join(lines[1:-1] if lines[-1].strip() == "```" else lines[1:]).strip()
    if text.startswith(("{", "[")):
        try:
            parsed = json.loads(text)
        except (ValueError, RecursionError):
            pass
        else:
            return _content_state(parsed, depth + 1)
    if any(pattern.search(text) for pattern in (
        _UNAVAILABLE_PREFIX, _ERROR_ACTION_PREFIX, _NO_RESULTS_PREFIX, _ANGLE_STATUS_PREFIX,
    )):
        return "unavailable"
    return "output"


def summarize_source_coverage(messages, selected_analysts, *, configured_sources=None):
    """Describe observed data-tool availability; never assert financial accuracy.

    ``configured_sources`` may contain boolean ``fred`` and
    ``sec_edgar_contact`` flags. Omitted flags mean unknown, not missing.
    Only a fixed allowlist of upstream tool names is returned. Unexpected names
    become ``unrecognized_tool`` so a malformed message cannot leak a secret.
    """
    observations = {}
    for message in _tool_messages(messages):
        supplied_name = _field(message, "name")
        name = supplied_name if isinstance(supplied_name, str) and supplied_name in _TOOLS else "unrecognized_tool"
        item = observations.setdefault(name, {"tool": name, "calls": 0, "unavailable_calls": 0, "empty_calls": 0})
        item["calls"] += 1
        state = "unavailable" if _field(message, "status") == "error" else _content_state(_field(message, "content"))
        if state == "unavailable":
            item["unavailable_calls"] += 1
        elif state == "empty":
            item["empty_calls"] += 1
    attempted = list(observations)
    unavailable = [name for name, item in observations.items() if item["unavailable_calls"]]
    empty = [name for name, item in observations.items() if item["empty_calls"]]
    no_tools = not observations
    selected = [name for name in _ANALYST_TOOLS if name in (selected_analysts or [])]
    limitations = [
        "This summary records tool-return status only. It does not independently verify source accuracy, completeness or freshness.",
    ]
    if no_tools:
        limitations.append("No data-tool results were captured in the completed run. This summary cannot establish that the selected sources were retrieved.")
    if unavailable:
        limitations.append("At least one data-tool call returned an unavailable, error or no-data result. A completed AI report does not establish complete source coverage.")
    if empty:
        limitations.append("At least one data-tool call returned no visible output; its source coverage is not established.")
    if "unrecognized_tool" in observations:
        limitations.append("An unrecognized tool result was captured; its name and contents were omitted from this summary.")
    if "social" in selected:
        limitations.append("The sentiment analyst prefetches news, StockTwits and Reddit outside the tool-message history. This summary cannot verify those feeds; historical social coverage is not a complete archive.")
    unobserved_analysts = [
        analyst for analyst in selected
        if analyst != "social" and not (_ANALYST_TOOLS[analyst] & observations.keys())
    ]
    if unobserved_analysts and not no_tools:
        labels = {"market": "technical", "news": "news/macro", "fundamentals": "fundamentals"}
        limitations.append("No relevant data-tool result was captured for the selected "
                           + ", ".join(labels[name] for name in unobserved_analysts)
                           + " analyst(s). Their source coverage is not established.")
    sources = configured_sources if isinstance(configured_sources, Mapping) else {}
    missing_config = False
    if "news" in selected and sources.get("fred") is False:
        missing_config = True
        limitations.append("FRED macro data is not configured. News/macro analysis may proceed without those indicators.")
    if "fundamentals" in selected and sources.get("sec_edgar_contact") is False:
        missing_config = True
        limitations.append("A personal SEC EDGAR contact is not configured; as-filed SEC statement access is not established.")
    analyst_coverage = {
        analyst: {
            "observed_tools": [name for name in attempted if name in _ANALYST_TOOLS[analyst]],
            "prefetch_not_observed": analyst == "social",
        }
        for analyst in selected
    }
    return {
        "summary_status": "incomplete" if no_tools or unavailable or empty or missing_config or unobserved_analysts else "observed_unverified",
        "attempted_tools": attempted,
        "unavailable_tools": unavailable,
        "empty_output_tools": empty,
        "no_tools_warning": no_tools,
        "unobserved_analysts": unobserved_analysts,
        "tool_observations": list(observations.values()),
        "analyst_coverage": analyst_coverage,
        "limitations": limitations,
    }
