"""Market adapter: explicit synthetic mode, never a silent data fallback."""

import hashlib
import math
import random
import threading
import time
from datetime import date, timedelta

from .models import today

PERIODS = {"1mo": 23, "3mo": 66, "6mo": 132, "1y": 252}
NAMES = {
    "AAPL": ("Apple Inc.", 248.0), "NVDA": ("NVIDIA Corporation", 178.0),
    "MSFT": ("Microsoft Corporation", 512.0), "GOOGL": ("Alphabet Inc.", 237.0),
    "AMZN": ("Amazon.com Inc.", 218.0), "TSLA": ("Tesla Inc.", 362.0),
    "META": ("Meta Platforms Inc.", 734.0), "SPY": ("SPDR S&P 500 ETF", 651.0),
    "BTC-USD": ("Bitcoin / US Dollar", 112_400.0), "ETH-USD": ("Ethereum / US Dollar", 4_120.0),
}


class MarketUnavailable(Exception):
    """Public, credential-free error for a failed remote data request."""


def demo_market(symbol: str, period: str = "3mo", end: date | None = None) -> dict:
    # Fixed anchor keeps the current quote identical for every requested period.
    anchor = today()
    seed = int(hashlib.sha256(symbol.encode()).hexdigest()[:12], 16)
    rng = random.Random(seed)
    name, base = NAMES.get(symbol, (symbol, float(70 + seed % 300)))
    days = []
    cursor = anchor - timedelta(days=540)
    price = base * 0.75
    i = 0
    while cursor <= anchor:
        if cursor.weekday() < 5:
            change = 0.0009 + 0.0018 * math.sin(i / 13) + rng.gauss(0, 0.009)
            opening = max(0.01, price * (1 + rng.gauss(0, 0.002)))
            price = max(0.01, price * (1 + change))
            spread = abs(rng.gauss(0.005, 0.002))
            days.append({
                "date": cursor.isoformat(), "open": round(opening, 2),
                "high": round(max(opening, price) * (1 + spread), 2),
                "low": round(min(opening, price) * (1 - spread), 2),
                "close": round(price, 2), "volume": rng.randint(8_000_000, 90_000_000),
            })
            i += 1
        cursor += timedelta(days=1)
    if end is not None:
        days = [bar for bar in days if bar["date"] <= end.isoformat()]
    bars = days[-PERIODS[period]:]
    return _quote(symbol, name, "USD", "SIMULATED", "demo", "Synthetic demo data", bars)


def _quote(symbol: str, name: str, currency: str | None, exchange: str, mode: str, source: str, bars: list[dict]) -> dict:
    if not bars:
        raise MarketUnavailable("No price history is available for this symbol and period.")
    last = bars[-1]
    previous = bars[-2]["close"] if len(bars) > 1 else last["close"]
    return {
        "symbol": symbol, "name": name, "currency": currency, "exchange": exchange,
        "mode": mode, "source": source, "as_of": last["date"], "delayed": True,
        "price": last["close"], "change": round(last["close"] - previous, 4),
        "change_percent": round((last["close"] / previous - 1) * 100, 4) if previous else 0,
        "bars": bars, "price_type": "synthetic daily close" if mode == "demo" else "latest available daily bar price",
    }


class MarketService:
    def __init__(self):
        self._cache: dict[tuple, tuple[float, dict]] = {}
        self._lock = threading.Lock()

    def get(self, symbol: str, mode: str = "demo", period: str = "3mo") -> dict:
        if mode == "demo":
            return demo_market(symbol, period)
        key = (symbol, period)
        with self._lock:
            cached = self._cache.get(key)
            if cached and time.monotonic() - cached[0] < 60:
                return cached[1]
        try:
            import yfinance as yf

            ticker = yf.Ticker(symbol)
            frame = ticker.history(period=period, auto_adjust=False, timeout=12, raise_errors=True)
            bars = []
            for stamp, row in frame.iterrows():
                prices = [float(row[k]) for k in ("Open", "High", "Low", "Close")]
                if not all(math.isfinite(v) and v > 0 for v in prices):
                    continue
                volume = float(row.get("Volume", 0))
                bars.append({
                    "date": stamp.date().isoformat(), "open": prices[0], "high": prices[1],
                    "low": prices[2], "close": prices[3],
                    "volume": int(volume) if math.isfinite(volume) else 0,
                })
            metadata = ticker.history_metadata or {}
            quote = _quote(symbol, metadata.get("longName") or NAMES.get(symbol, (symbol,))[0],
                           metadata.get("currency"), metadata.get("exchangeName", "Yahoo Finance"),
                           "live", "Yahoo Finance · daily bars, not executable quotes", bars)
        except Exception:  # noqa: BLE001 -- the provider boundary must not expose raw SDK credentials/errors.
            # SDK exceptions may contain authentication headers, URLs or proxy values.
            raise MarketUnavailable(
                "Yahoo Finance data is unavailable. Check the symbol, network access and provider availability. "
                "No demo prices were substituted."
            ) from None
        with self._lock:
            if len(self._cache) >= 100:
                self._cache.pop(next(iter(self._cache)))
            self._cache[key] = (time.monotonic(), quote)
        return quote
