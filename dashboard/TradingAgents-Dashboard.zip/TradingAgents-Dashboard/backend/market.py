"""Market adapter: explicit synthetic mode, never a silent data fallback."""

import hashlib
import math
import random
import threading
import time
from datetime import UTC, date, datetime, timedelta
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from .models import today

PERIODS = {"1mo": 23, "3mo": 66, "6mo": 132, "1y": 252}
_METADATA_KEYS = (
    "symbol", "longName", "shortName", "currency", "fullExchangeName", "exchangeName",
    "exchangeTimezoneName", "regularMarketPrice", "regularMarketTime", "exchangeDataDelayedBy",
    "currentTradingPeriod",
)
NAMES = {
    "AAPL": ("Apple Inc.", 248.0), "NVDA": ("NVIDIA Corporation", 178.0),
    "MSFT": ("Microsoft Corporation", 512.0), "GOOGL": ("Alphabet Inc.", 237.0),
    "AMZN": ("Amazon.com Inc.", 218.0), "TSLA": ("Tesla Inc.", 362.0),
    "META": ("Meta Platforms Inc.", 734.0), "SPY": ("SPDR S&P 500 ETF", 651.0),
    "BTC-USD": ("Bitcoin / US Dollar", 112_400.0), "ETH-USD": ("Ethereum / US Dollar", 4_120.0),
}


class MarketUnavailable(Exception):
    """Public, credential-free error for a failed remote data request."""


def _utc_now() -> datetime:
    return datetime.now(UTC)


def _positive(value) -> float | None:
    if isinstance(value, bool):
        return None
    try:
        parsed = float(value)
    except (TypeError, ValueError, OverflowError):
        return None
    return parsed if math.isfinite(parsed) and parsed > 0 else None


def _utc_timestamp(value) -> datetime | None:
    """Yahoo returns epoch numbers; yfinance may format them as aware Timestamps."""
    if isinstance(value, bool) or value is None:
        return None
    try:
        if isinstance(value, datetime):
            return value.astimezone(UTC) if value.tzinfo is not None else None
        if isinstance(value, str):
            parsed = datetime.fromisoformat(value)
            return parsed.astimezone(UTC) if parsed.tzinfo is not None else None
        number = float(value)
        if not math.isfinite(number) or number <= 0:
            return None
        return datetime.fromtimestamp(number, UTC)
    except (ValueError, TypeError, OverflowError, OSError):
        return None


def _iso(stamp: datetime | None) -> str | None:
    return stamp.isoformat() if stamp is not None else None


def _zone(name) -> ZoneInfo | None:
    try:
        return ZoneInfo(name) if isinstance(name, str) else None
    except (ZoneInfoNotFoundError, ValueError):
        return None


def _session(metadata: dict, at: datetime) -> tuple[str, datetime | None, datetime | None]:
    periods = metadata.get("currentTradingPeriod") or {}
    if not isinstance(periods, dict):
        return "unknown", None, None
    regular = periods.get("regular") or {}
    start, end = _utc_timestamp(regular.get("start")), _utc_timestamp(regular.get("end"))
    for key in ("regular", "pre", "post"):
        period = periods.get(key) or {}
        begin, finish = _utc_timestamp(period.get("start")), _utc_timestamp(period.get("end"))
        if begin is not None and finish is not None and begin <= at < finish:
            return key, start, end
    return ("closed" if start is not None and end is not None else "unknown"), start, end


def _provenance(base: dict, now: datetime) -> dict:
    """Recompute age on cache hits, without pretending the provider quote advanced."""
    result = {key: value for key, value in base.items() if not key.startswith("_")}
    timestamp = _utc_timestamp(base.get("quote_as_of"))
    state, _, _ = _session(base.get("_metadata", {}), now)
    age = (now - timestamp).total_seconds() if timestamp else None
    result.update(session_state=state, quote_age_seconds=max(0, round(age)) if age is not None else None)
    if timestamp is None:
        status, stale, note = "timestamp_unavailable", None, (
            "Only a dated daily bar is available. An exact quote time could not be verified; "
            "this is not a current-price feed."
        )
    elif age < -300:
        status, stale, note = "clock_warning", None, (
            "The provider quote time is ahead of this computer's clock. Check Windows date/time."
        )
    elif age > 7 * 86400 and state != "regular":
        status, stale, note = "old_quote", None, (
            "This provider quote is more than seven calendar days old. Long market closures can explain a gap, "
            "but current pricing has not been confirmed. Refresh and check the instrument against your broker."
        )
    elif state == "regular":
        delay = base.get("market_delay_minutes")
        tolerance = max(30, (delay or 0) + 10) * 60
        stale = age > tolerance
        status = "stale_during_session" if stale else "regular_session"
        note = ("This quote is older than expected during the provider's current regular session. Refresh and compare with your broker."
                if stale else "Provider regular-session quote. It may be delayed and is not an executable broker quote.")
    elif state == "unknown":
        status, stale, note = "session_status_unknown", None, (
            "The provider's market-session status is unavailable. Use the quote timestamp to judge its age."
        )
    else:
        status, stale, note = "outside_regular_hours", False, (
            "Latest provider regular-session quote; the market is outside regular hours. "
            "It can differ from pre-market or after-hours prices. Weekends and holidays do not create new regular-session quotes."
        )
    result.update(freshness=status, freshness_note=note, stale=stale)
    return result


def _live_quote(symbol: str, frame, metadata: dict, fetched_at: datetime) -> dict:
    returned_symbol = metadata.get("symbol")
    if returned_symbol and str(returned_symbol).upper() != symbol.upper():
        raise MarketUnavailable("Yahoo Finance returned a different instrument. Check the exact ticker and exchange suffix.")
    exchange_zone = _zone(metadata.get("exchangeTimezoneName"))
    bars_by_date = {}
    discarded = 0
    for stamp, row in frame.iterrows():
        prices = [_positive(row.get(key)) for key in ("Open", "High", "Low", "Close")]
        if any(value is None for value in prices):
            discarded += 1
            continue
        opening, high, low, close = prices
        if low > min(opening, close) or high < max(opening, close) or low > high:
            discarded += 1
            continue
        try:
            volume = float(row.get("Volume", 0))
        except (TypeError, ValueError):
            volume = 0
        local_stamp = stamp.tz_convert(exchange_zone) if exchange_zone is not None and getattr(stamp, "tzinfo", None) is not None else stamp
        day = local_stamp.date().isoformat()
        bars_by_date[day] = {"date": day, "open": opening, "high": high, "low": low, "close": close,
                             "volume": int(volume) if math.isfinite(volume) and volume >= 0 else 0}
    bars = [bars_by_date[day] for day in sorted(bars_by_date)]
    if not bars:
        raise MarketUnavailable("Yahoo Finance returned no valid price history for this symbol. No demo prices were substituted.")
    latest_bar = bars[-1]
    provider_price = _positive(metadata.get("regularMarketPrice"))
    timestamp = _utc_timestamp(metadata.get("regularMarketTime"))
    # A price without an exact provider timestamp cannot be represented as a current quote.
    regular_quote = provider_price is not None and timestamp is not None
    quote_date = timestamp.astimezone(exchange_zone or UTC).date().isoformat() if regular_quote else latest_bar["date"]
    # A stale metadata quote must not replace a newer historical bar.
    if quote_date < latest_bar["date"]:
        regular_quote, timestamp = False, None
        quote_date = latest_bar["date"]
    price = provider_price if regular_quote else latest_bar["close"]
    previous_bars = [bar for bar in bars if bar["date"] < quote_date]
    previous = previous_bars[-1]["close"] if previous_bars else price
    state, regular_start, regular_end = _session(metadata, fetched_at)
    local_today = fetched_at.astimezone(exchange_zone or UTC).date().isoformat()
    complete_bars = [bar for bar in bars if bar["date"] < local_today]
    if regular_start is not None and regular_end is not None and exchange_zone is not None:
        session_day = regular_start.astimezone(exchange_zone).date().isoformat()
        if fetched_at >= regular_end + timedelta(minutes=5):
            # A lagging schedule must not discard newer bars already known to
            # precede today; it can only add the session it confirms finished.
            completed_dates = {bar["date"] for bar in complete_bars}
            completed_dates.update(bar["date"] for bar in bars if bar["date"] <= session_day)
            complete_bars = [bar for bar in bars if bar["date"] in completed_dates]
    last_complete = complete_bars[-1] if complete_bars else None
    latest_complete = latest_bar in complete_bars
    if not latest_complete:
        latest_date = latest_bar["date"]
        covers_latest_date = (
            exchange_zone is not None and regular_start is not None and regular_end is not None
            and regular_start.astimezone(exchange_zone).date().isoformat() == latest_date
        )
        # If the provider omitted today's schedule or already rolled it to the
        # next session, do not pretend we know whether today's bar is final.
        if not covers_latest_date:
            latest_complete = None
    delay = metadata.get("exchangeDataDelayedBy")
    try:
        delay = int(delay) if delay is not None and math.isfinite(float(delay)) and float(delay) >= 0 else None
    except (ValueError, TypeError, OverflowError):
        delay = None
    return {
        "symbol": symbol, "name": metadata.get("longName") or metadata.get("shortName") or symbol,
        "currency": metadata.get("currency"), "exchange": metadata.get("fullExchangeName") or metadata.get("exchangeName") or "Yahoo Finance",
        "mode": "live", "provider": "Yahoo Finance", "source": "Yahoo Finance · provider quote and historical daily bars",
        "as_of": _iso(timestamp) if regular_quote else latest_bar["date"],
        "quote_as_of": _iso(timestamp) if regular_quote else None, "quote_date": quote_date,
        "exchange_timezone": metadata.get("exchangeTimezoneName") if exchange_zone is not None else None,
        "quote_date_timezone": metadata.get("exchangeTimezoneName") if exchange_zone is not None else "UTC",
        "price": price, "price_type": "Yahoo regular-session quote (may be delayed)" if regular_quote else "Daily-bar price; exact quote time unavailable",
        "quote_kind": "regular_session" if regular_quote else "daily_bar", "regular_session_price": provider_price if regular_quote else None,
        "change": round(price - previous, 4), "change_percent": round((price / previous - 1) * 100, 4) if previous else 0,
        "previous_close": previous, "bars": bars, "delayed": True, "market_delay_minutes": delay,
        "fetched_at": _iso(fetched_at), "cache_age_seconds": 0,
        "latest_bar_date": latest_bar["date"], "latest_bar_close": latest_bar["close"], "latest_bar_complete": latest_complete,
        "last_completed_close": last_complete["close"] if last_complete else None,
        "last_completed_session_date": last_complete["date"] if last_complete else None,
        "regular_session_close": last_complete["close"] if last_complete else None,
        "invalid_bars_discarded": discarded, "_metadata": metadata, "session_state": state,
    }


def demo_market(symbol: str, period: str = "3mo", end: date | None = None) -> dict:
    # Fixed anchor keeps the current quote identical for every requested period.
    anchor = today()
    seed = int(hashlib.sha256(symbol.encode()).hexdigest()[:12], 16)
    rng = random.Random(seed)
    name, base = NAMES.get(symbol, (symbol, float(70 + seed % 300)))
    days = []
    cursor = anchor - timedelta(days=540)
    price = base * 0.75
    i = 0
    while cursor <= anchor:
        if cursor.weekday() < 5:
            change = 0.0009 + 0.0018 * math.sin(i / 13) + rng.gauss(0, 0.009)
            opening = max(0.01, price * (1 + rng.gauss(0, 0.002)))
            price = max(0.01, price * (1 + change))
            spread = abs(rng.gauss(0.005, 0.002))
            days.append({
                "date": cursor.isoformat(), "open": round(opening, 2),
                "high": round(max(opening, price) * (1 + spread), 2),
                "low": round(min(opening, price) * (1 - spread), 2),
                "close": round(price, 2), "volume": rng.randint(8_000_000, 90_000_000),
            })
            i += 1
        cursor += timedelta(days=1)
    if end is not None:
        days = [bar for bar in days if bar["date"] <= end.isoformat()]
    bars = days[-PERIODS[period]:]
    return _quote(symbol, name, "USD", "SIMULATED", "demo", "Synthetic demo data", bars)


def _quote(symbol: str, name: str, currency: str | None, exchange: str, mode: str, source: str, bars: list[dict]) -> dict:
    if not bars:
        raise MarketUnavailable("No price history is available for this symbol and period.")
    last = bars[-1]
    previous = bars[-2]["close"] if len(bars) > 1 else last["close"]
    return {
        "symbol": symbol, "name": name, "currency": currency, "exchange": exchange,
        "mode": mode, "source": source, "as_of": last["date"], "delayed": True,
        "price": last["close"], "change": round(last["close"] - previous, 4),
        "change_percent": round((last["close"] / previous - 1) * 100, 4) if previous else 0,
        "bars": bars, "price_type": "synthetic daily close" if mode == "demo" else "latest available daily bar price",
    }


class MarketService:
    def __init__(self):
        self._cache: dict[str, tuple[float, dict]] = {}
        self._lock = threading.Lock()
        # A bounded set of striped locks prevents duplicate concurrent downloads
        # without retaining an unbounded lock for every invalid symbol requested.
        self._fetch_locks = [threading.Lock() for _ in range(32)]

    def get(self, symbol: str, mode: str = "live", period: str = "3mo", force_refresh: bool = False) -> dict:
        if period not in PERIODS:
            raise MarketUnavailable("Choose a supported chart range: 1mo, 3mo, 6mo or 1y.")
        symbol = symbol.upper()
        if mode == "demo":
            return demo_market(symbol, period)
        if mode != "live":
            raise MarketUnavailable("Select real market data or the separate demonstration mode.")
        lock = self._fetch_locks[int(hashlib.sha256(symbol.encode()).hexdigest()[:8], 16) % len(self._fetch_locks)]
        with lock:
            with self._lock:
                cached = self._cache.get(symbol)
            if not force_refresh and cached and time.monotonic() - cached[0] < 60:
                return self._response(cached, period)
            try:
                import yfinance as yf

                ticker = yf.Ticker(symbol)
                # One base history and metadata snapshot keeps the current quote
                # identical while the user switches between chart ranges.
                frame = ticker.history(period="1y", interval="1d", auto_adjust=False, prepost=False,
                                       timeout=12, raise_errors=True)
                raw_metadata = ticker.history_metadata or {}
                # yfinance's HistoryMetadata is a lazy Mapping: dict(mapping)
                # also requests intraday tradingPeriods and can fail after the
                # required daily data succeeded. Read only the base keys needed.
                metadata = {key: raw_metadata.get(key) for key in _METADATA_KEYS}
                quote = _live_quote(symbol, frame, metadata, _utc_now())
            except MarketUnavailable:
                raise
            except Exception:  # noqa: BLE001 -- SDK exceptions can contain proxy or credential details.
                raise MarketUnavailable(
                    "Yahoo Finance data is unavailable. Check the symbol, Internet connection and provider availability. "
                    "No demo prices were substituted."
                ) from None
            cached = (time.monotonic(), quote)
            with self._lock:
                if symbol not in self._cache and len(self._cache) >= 100:
                    self._cache.pop(next(iter(self._cache)))
                self._cache[symbol] = cached
            return self._response(cached, period)

    @staticmethod
    def _response(cached: tuple[float, dict], period: str) -> dict:
        result = _provenance(cached[1], _utc_now())
        result["bars"] = [dict(bar) for bar in cached[1]["bars"][-PERIODS[period]:]]
        result["cache_age_seconds"] = max(0, round(time.monotonic() - cached[0]))
        return result
