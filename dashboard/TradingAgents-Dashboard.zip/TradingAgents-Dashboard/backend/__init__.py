"""Private TradingAgents research dashboard."""
