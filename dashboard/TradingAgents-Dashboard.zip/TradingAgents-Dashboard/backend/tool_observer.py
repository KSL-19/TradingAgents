"""Observe tool availability across private analyst graphs without retaining data.

The upstream analyst graphs return reports only, so final-state messages cannot
reconstruct their tool results. Bind this handler to the root graph's runnable
config. Only fixed tool names and outcome markers survive each callback.
"""

import threading
from collections.abc import Mapping
from uuid import UUID

from langchain_core.callbacks import BaseCallbackHandler

from .coverage import _TOOLS, summarize_source_coverage

_MARKERS = {
    "output": "Observed tool output; financial facts were not independently verified.",
    "unavailable": "DATA_UNAVAILABLE: upstream tool did not provide usable data.",
    "empty": "",
}


def _run_key(value):
    if isinstance(value, UUID):
        return value.int
    if isinstance(value, str) and len(value) <= 36:
        try:
            return UUID(value).int
        except ValueError:
            pass
    return None


def _safe_name(value):
    return value if isinstance(value, str) and value in _TOOLS else "unrecognized_tool"


class ToolObserver(BaseCallbackHandler):
    """Bounded, thread-safe callback collector for tool outcome metadata only."""

    run_inline = True

    def __init__(self, max_records=2000, max_inflight=512):
        self._max_records = min(max(1, int(max_records)), 2000)
        self._max_inflight = min(max(1, int(max_inflight)), 512)
        self._lock = threading.Lock()
        self._inflight = {}
        self._records = []
        self._dropped = 0
        self._unclassified = 0

    def on_tool_start(self, serialized, input_str, *, run_id, **kwargs):
        # Inputs, descriptions, metadata, parent IDs and tool arguments are not kept.
        key = _run_key(run_id)
        if key is None:
            return
        supplied = serialized.get("name") if isinstance(serialized, Mapping) else None
        name = _safe_name(supplied)
        with self._lock:
            if len(self._inflight) >= self._max_inflight and key not in self._inflight:
                self._dropped += 1
                return
            self._inflight[key] = name

    def _finish_name(self, run_id, output=None):
        key = _run_key(run_id)
        with self._lock:
            name = self._inflight.pop(key, None) if key is not None else None
        if name is not None:
            return name
        supplied = output.get("name") if isinstance(output, Mapping) else getattr(output, "name", None)
        return _safe_name(supplied)

    def _record(self, name, state):
        with self._lock:
            if len(self._records) >= self._max_records:
                self._dropped += 1
                return
            self._records.append({"type": "tool", "name": name, "content": _MARKERS[state]})

    def on_tool_end(self, output, *, run_id, **kwargs):
        name = self._finish_name(run_id, output)
        if isinstance(output, Mapping) and (output.get("type") == "tool" or output.get("role") == "tool"):
            content, status = output.get("content"), output.get("status")
        elif getattr(output, "type", None) == "tool":
            content, status = getattr(output, "content", None), getattr(output, "status", None)
        else:
            content, status = output, None
        try:
            # Classify on the stack, then discard the actual body immediately.
            summary = summarize_source_coverage([
                {"type": "tool", "name": name, "content": content, "status": status}
            ], [])
            state = "unavailable" if summary["unavailable_tools"] else "empty" if summary["empty_output_tools"] else "output"
        except Exception:  # noqa: BLE001 -- observability must not interrupt a paid analysis.
            state = "output"
            with self._lock:
                self._unclassified += 1
        self._record(name, state)

    def on_tool_error(self, error, *, run_id, **kwargs):
        # Never read or retain the exception's text/body/URL.
        self._record(self._finish_name(run_id), "unavailable")

    def summary(self, selected_analysts, *, configured_sources=None):
        with self._lock:
            records = [dict(item) for item in self._records]
            dropped, pending, unclassified = self._dropped, len(self._inflight), self._unclassified
        result = summarize_source_coverage(records, selected_analysts, configured_sources=configured_sources)
        result["observation_method"] = "graph_tool_callbacks"
        result["observation_truncated"] = bool(dropped)
        if dropped or pending or unclassified:
            result["summary_status"] = "incomplete"
        if dropped:
            result["limitations"].append("The bounded tool-observation limit was reached; this summary is incomplete.")
        if pending:
            result["limitations"].append("Some tool calls had no observed terminal event when this summary was recorded.")
        if unclassified:
            result["limitations"].append("Some observed tool outputs could not be classified; their source availability is not established.")
        return result
