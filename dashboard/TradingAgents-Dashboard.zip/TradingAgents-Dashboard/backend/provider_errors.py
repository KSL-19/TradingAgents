"""Credential-free classifications for provider and analysis failures.

SDK exception strings and response bodies are intentionally never returned. Only
fixed messages and codes from this module may cross the process/API boundary.
"""

from collections.abc import Mapping
from dataclasses import dataclass

_STAGES = frozenset({
    "analysis", "initialization", "quick_model_probe", "deep_model_probe",
    "market_preflight", "worker_start", "worker_exit", "graph_execution",
    "report_output", "model_preflight",
})

# code: (message, recovery action, retryable without changing configuration)
_FAILURES = {
    "credential_missing": (
        "No API key is configured for this dashboard.",
        "Open Connections & settings, enter your OpenAI API key locally, and save and test the connection.", False),
    "connection_changed": (
        "The provider credential or model selection changed during the check.",
        "Review the current saved models and test the connection again before retrying.", True),
    "authentication_failed": (
        "OpenAI rejected the API credential used for this request.",
        "Open Connections & settings, replace or check the API key, and test the connection again.", False),
    "billing_quota_exceeded": (
        "The API account has no usable generation quota or has reached its billing limit.",
        "Check API billing, available credits and project usage limits in your OpenAI platform account. A ChatGPT subscription does not supply API credits.", False),
    "rate_limited": (
        "OpenAI temporarily limited the request rate for this account or model.",
        "Wait before retrying. Use fewer simultaneous requests or check the model's rate limits.", True),
    "permission_denied": (
        "The API account or project denied permission for this generation request.",
        "Check the key's project and model permissions, or select another available analysis model.", False),
    "model_not_available": (
        "The selected model or required API route was not available to this request.",
        "Refresh the available models in Connections & settings, select supported analyst and decision models, and retry.", False),
    "unsupported_model_parameter": (
        "The selected model rejected a setting or capability required by the analysis request.",
        "Choose a model that supports text, tool calls and structured output, then test AI execution before retrying.", False),
    "context_limit_exceeded": (
        "The research input exceeded the selected model's context limit.",
        "Try one analyst and one debate round, or choose a model with a larger supported context window.", False),
    "output_limit_exceeded": (
        "The model reached its output limit before producing a usable result.",
        "Try a focused analysis or another model. Reasoning models need enough output budget for reasoning and the final answer.", False),
    "empty_model_output": (
        "The model request finished without a usable analysis response.",
        "Test the selected models' execution, then retry a focused analysis or choose another model.", False),
    "invalid_model_output": (
        "The model did not return the response format required by this analysis step.",
        "Test AI execution with a supported text model and try one analyst before adding a larger research team.", False),
    "tool_call_unavailable": (
        "The model did not return the tool call required by the connection check.",
        "Choose an analyst model with tool-calling support. Being listed in the account does not prove this capability.", False),
    "structured_output_unavailable": (
        "The model did not return the structured response required by the connection check.",
        "Choose a decision model that supports the framework's structured-output requests.", False),
    "content_rejected": (
        "The provider declined to produce a response for this request.",
        "Review the selected input and provider restrictions, then try a supported research request.", False),
    "provider_timeout": (
        "The provider request did not finish within its time limit.",
        "Check the connection and provider availability, then retry with fewer analysts or a faster model.", True),
    "analysis_timeout": (
        "The analysis exceeded the dashboard's execution time limit and was stopped.",
        "Try one analyst and one debate round, or select a faster model.", True),
    "provider_connection_failed": (
        "The dashboard could not complete a secure connection to the AI provider.",
        "Check Internet access, proxy or firewall settings and provider availability, then test the connection again.", True),
    "provider_unavailable": (
        "The AI provider temporarily could not complete the request.",
        "Wait and retry. Check the provider's service status if the problem continues.", True),
    "market_data_unavailable": (
        "The required real market data could not be retrieved or validated.",
        "Refresh the symbol's real market data and check its source and timestamp before starting analysis.", True),
    "worker_crashed": (
        "The isolated analysis process exited before it returned a result.",
        "Restart the dashboard and retry one technical analyst. If it repeats, share the credential-free diagnostic file.", True),
    "analysis_failed": (
        "The analysis could not finish at this step.",
        "Run the selected-model execution check and retry a focused analysis. If it repeats, share the credential-free diagnostic file.", False),
}


@dataclass(frozen=True)
class Failure:
    code: str
    message: str
    action: str
    stage: str
    retryable: bool

    def as_dict(self) -> dict:
        # Rebuild from the registry even if a caller directly constructed Failure.
        safe = failure_for(self.code, self.stage)
        return {"code": safe.code, "message": safe.message, "action": safe.action,
                "stage": safe.stage, "retryable": safe.retryable}

    def as_job_fields(self) -> dict:
        safe = failure_for(self.code, self.stage)
        return {"error_code": safe.code, "error": safe.message, "error_action": safe.action,
                "error_stage": safe.stage, "retryable": safe.retryable}


def failure_for(code: str, stage: str = "analysis") -> Failure:
    selected = code if isinstance(code, str) and code in _FAILURES else "analysis_failed"
    stage = stage if isinstance(stage, str) and stage in _STAGES else "analysis"
    message, action, retryable = _FAILURES[selected]
    return Failure(selected, message, action, stage, retryable)


class AnalysisFailure(Exception):
    """An intentional failure whose contents come only from the fixed registry."""

    def __init__(self, code: str | Failure, stage: str = "analysis"):
        self.failure = failure_for(code.code, code.stage) if isinstance(code, Failure) else failure_for(code, stage)
        super().__init__(self.failure.message)


def _attribute(value, name, default=None):
    try:
        return getattr(value, name, default)
    except Exception:  # noqa: BLE001 -- an exception property can itself fail.
        return default


def _mapping_get(value, name):
    try:
        return value.get(name) if isinstance(value, Mapping) else None
    except Exception:  # noqa: BLE001 -- untrusted exception payload.
        return None


def _word(value) -> str:
    return value.lower().strip() if isinstance(value, str) and len(value) <= 150 else ""


def _facts(exc) -> tuple[set[str], int | None, set[str]]:
    """Read bounded SDK metadata. Raw text is not used or returned."""
    # A parameter name such as max_output_tokens is not an output-limit error:
    # it may instead be the *unsupported* parameter named by a 400 response.
    words = {_word(_attribute(exc, key)) for key in ("code", "type", "finish_reason")}
    body = _attribute(exc, "body")
    for _ in range(3):
        if not isinstance(body, Mapping):
            break
        words.update(_word(_mapping_get(body, key)) for key in ("code", "type", "finish_reason"))
        body = _mapping_get(body, "error")
    status = _attribute(exc, "status_code")
    if not isinstance(status, int) or isinstance(status, bool):
        status = _attribute(_attribute(exc, "response"), "status_code")
    if not isinstance(status, int) or isinstance(status, bool) or not 100 <= status <= 599:
        status = None
    names = {base.__name__ for base in type(exc).__mro__[:8]}
    return words, status, names


def _classify_one(exc) -> str | None:
    words, status, names = _facts(exc)
    if words & {"insufficient_quota", "billing_hard_limit_reached", "billing_limit_reached", "billing_not_active",
                "quota_exceeded", "credit_balance_too_low", "credits_exhausted", "monthly_limit_exceeded"}:
        return "billing_quota_exceeded"
    if status == 401 or "AuthenticationError" in names or "invalid_api_key" in words:
        return "authentication_failed"
    if status == 403 or "PermissionDeniedError" in names:
        return "permission_denied"
    if status == 404 or "model_not_found" in words or "model_not_available" in words:
        return "model_not_available"
    if status == 429 or "RateLimitError" in names or "rate_limit_exceeded" in words:
        return "rate_limited"
    if words & {"context_length_exceeded", "max_context_length_exceeded", "prompt_too_long"}:
        return "context_limit_exceeded"
    if ("LengthFinishReasonError" in names or words & {"length", "max_output_tokens", "max_tokens_exceeded", "output_limit_exceeded"}):
        return "output_limit_exceeded"
    if words & {"unsupported_parameter", "unsupported_value", "unsupported_model", "parameter_not_supported", "model_not_supported"}:
        return "unsupported_model_parameter"
    if "ContentFilterFinishReasonError" in names or words & {"content_filter", "content_policy_violation"}:
        return "content_rejected"
    if names & {"APITimeoutError", "TimeoutError", "TimeoutException", "ReadTimeout", "ConnectTimeout", "WriteTimeout", "PoolTimeout"}:
        return "provider_timeout"
    if names & {"APIConnectionError", "ConnectError", "NetworkError", "ProxyError", "ConnectionError", "ConnectionResetError"}:
        return "provider_connection_failed"
    if "MarketUnavailable" in names:
        return "market_data_unavailable"
    if names & {"OutputParserException", "JSONDecodeError", "ValidationError", "APIResponseValidationError"}:
        return "invalid_model_output"
    if names & {"BrokenProcessPool", "ChildProcessError", "BrokenPipeError", "EOFError"}:
        return "worker_crashed"
    if status is not None and status >= 500:
        return "provider_unavailable"
    if status in {400, 422}:
        return "unsupported_model_parameter"
    return None


def classify_failure(exc: BaseException, stage: str = "analysis") -> Failure:
    """Classify a bounded exception chain without ever exposing provider text."""
    current, visited = exc, set()
    for _ in range(5):
        if not isinstance(current, BaseException) or id(current) in visited:
            break
        visited.add(id(current))
        if isinstance(current, AnalysisFailure):
            return failure_for(current.failure.code, current.failure.stage)
        code = _classify_one(current)
        if code is not None:
            return failure_for(code, stage)
        current = _attribute(current, "__cause__") or _attribute(current, "__context__")
    return failure_for("analysis_failed", stage)
