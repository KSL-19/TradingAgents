"""Explicit, bounded paid checks of the same installed model adapter used by research.

This module is called only from a user-triggered endpoint. It executes no market
tools or trades and never returns provider response text or credentials.
"""

import copy
import hashlib
import logging
import os
from pathlib import Path

from pydantic import BaseModel

from .connections import ConnectionSettings
from .provider_errors import AnalysisFailure, classify_failure
from .store import now


class ProbeResponse(BaseModel):
    ready: bool


TOOL_SCHEMA = {
    "type": "function",
    "function": {
        "name": "dashboard_readiness_check",
        "description": "Return readiness for a harmless dashboard connection test. No trade or external action occurs.",
        "parameters": {
            "type": "object", "properties": {"ready": {"type": "boolean"}},
            "required": ["ready"], "additionalProperties": False,
        },
    },
}


def execute_probe(data_dir: str, models: dict, expected_fingerprint: str, output):
    """Run at most two provider requests in a disposable spawned process."""
    results = []
    requests = 0
    previous_disable = logging.root.manager.disable
    try:
        logging.disable(logging.CRITICAL)
        key = ConnectionSettings(Path(data_dir)).get_key()
        if not key:
            raise AnalysisFailure("credential_missing", "model_preflight")
        if hashlib.sha256(key.encode()).hexdigest() != expected_fingerprint:
            raise AnalysisFailure("connection_changed", "model_preflight")
        os.environ["OPENAI_API_KEY"] = key
        # Upstream's structured fallback logs raw exceptions. No raw SDK error
        # belongs in this local dashboard terminal or its exported diagnostics.
        from tradingagents.default_config import DEFAULT_CONFIG
        from tradingagents.llm_clients import create_tier_client

        config = copy.deepcopy(DEFAULT_CONFIG)
        config.update(
            llm_provider="openai", backend_url=None, quick_think_provider=None, deep_think_provider=None,
            quick_think_backend_url=None, deep_think_backend_url=None,
            quick_think_llm=models["quick_model"], deep_think_llm=models["deep_model"],
            max_tokens=4096, llm_max_retries=0, temperature=None, openai_reasoning_effort=None,
        )
        stop = False
        for role, check in (("quick", "tool_call"), ("deep", "structured_output")):
            stage = role + "_model_probe"
            record = {"role": role, "model": models[role + "_model"], "check": check,
                      "error_stage": stage, "retryable": False,
                      "error_code": None, "error_action": None}
            if stop:
                results.append(dict(record, status="skipped", message="Not requested after the earlier account-level failure."))
                continue
            try:
                llm = create_tier_client(config, role, timeout=35).get_llm()
                if role == "quick":
                    bound = llm.bind_tools([TOOL_SCHEMA], tool_choice="dashboard_readiness_check")
                    requests += 1
                    result = bound.invoke("Call dashboard_readiness_check once with ready=true. This is a connection test, not financial research.")
                    calls = getattr(result, "tool_calls", None) or []
                    valid = any(call.get("name") == "dashboard_readiness_check"
                                and isinstance(call.get("args"), dict) and call["args"].get("ready") is True
                                for call in calls if isinstance(call, dict))
                    if not valid:
                        raise AnalysisFailure("tool_call_unavailable", stage)
                else:
                    bound = llm.with_structured_output(ProbeResponse)
                    requests += 1
                    result = bound.invoke("Return the structured readiness result with ready=true. This is a harmless connection test.")
                    if not ((isinstance(result, ProbeResponse) and result.ready is True)
                            or (isinstance(result, dict) and result.get("ready") is True)):
                        raise AnalysisFailure("structured_output_unavailable", stage)
                results.append(dict(record, status="passed", message="The requested model capability returned the expected check response."))
            except Exception as exc:  # noqa: BLE001 -- only fixed classifications cross the process boundary.
                failure = classify_failure(exc, stage)
                results.append(dict(record, status="failed", message=failure.message,
                                    error_code=failure.code, error_action=failure.action,
                                    retryable=failure.retryable))
                stop = failure.code in {"authentication_failed", "billing_quota_exceeded", "rate_limited", "provider_connection_failed"}
        success = len(results) == 2 and all(item["status"] == "passed" for item in results)
        output.put({"verification_kind": "generation_probe", "tested_at": now(), "success": success,
                    "request_count": requests, "results": results,
                    "message": "Both selected model capabilities passed a small paid check. Full research remains a separate request."
                    if success else "The selected-model execution check found a problem. Follow the action shown for the failed role."})
    except Exception as exc:  # noqa: BLE001 -- no credential or raw SDK text is returned.
        failure = classify_failure(exc, "model_preflight")
        output.put({"verification_kind": "generation_probe", "tested_at": now(), "success": False,
                    "request_count": requests, "results": results, "message": failure.message,
                    **failure.as_job_fields()})
    finally:
        logging.disable(previous_disable)
