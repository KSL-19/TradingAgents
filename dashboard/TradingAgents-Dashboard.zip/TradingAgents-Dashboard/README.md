# TradingAgents Dashboard

A browser dashboard around [Tauric Research TradingAgents](https://github.com/TauricResearch/TradingAgents), pinned to revision `c4544913a14ed3df5f1ed7b9e8483270ce20682a` (0.7.1).

## What you can use

- Interactive daily price charts and a persistent watchlist.
- On-demand TradingAgents analysis, model settings, agent reports, run history, and Markdown downloads.
- A $100,000 paper account with simulated buy/sell orders, holdings, and an order ledger.
- Separate demo and real-market-data paper accounts. Demo prices are synthetic and demo reports are illustrative, not AI output.
- Password protection for a private hosted instance. Credentials stay on the server.

**This app does not connect to a broker or place real orders.** Real-data prices are Yahoo's latest available daily bars, not a real-time execution feed. Today's bar may still be forming. Paper fills use those prices without commissions, slippage, market-session checks, or exchange execution. Corporate actions such as splits and dividends are not modeled. This is a research and simulation tool; AI reports can be wrong.

## Run on your computer

Install Python 3.12 from [python.org](https://www.python.org/downloads/). Extract the release ZIP to a regular folder. The package includes the built frontend and the upstream TradingAgents wheel; Git and Node are not needed to use it.

On Windows, double-click `Start Dashboard.bat`. On macOS, open `Start Dashboard.command`, or run the command below in Terminal. On Linux, run the command below. On macOS/Linux, use `python3` instead of `python` if needed.

```bash
python launch.py
```

The launcher verifies the bundled upstream wheel, creates an isolated Python environment, installs dependencies on first use, and opens your browser. The first launch needs an Internet connection and may take a few minutes. Subsequent launches reuse the installed environment. If a firewall prompt appears, local use needs only this computer's loopback interface.

For manual setup instead, from this directory:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python run.py --local --open
```

For manual Windows setup, create the environment with `py -3.12 -m venv .venv` and activate it with `.venv\Scripts\Activate.ps1` in PowerShell, then use the last two manual commands above.

`--local` explicitly enables password-free access and binds only to your computer's loopback interface. `--open` opens your browser. To use a different port, add `--port 8050`. Keep the terminal running; Ctrl+C stops the app.

Start in **Demo** mode to try the chart, reports, and simulated trades without credentials. Switching to real market data does not convert demo holdings or reports into real ones.

Data lives in `.data/` next to this file. Back up this folder while the server is stopped. To choose another durable location, set `DASHBOARD_DATA_DIR` before launch. This is a single-user app: everyone with the password shares watchlists, reports, and paper accounts.

## Enable real data and AI analysis

Yahoo market history needs Internet access. Actual analysis also needs an OpenAI API key, available models, and API billing. Set credentials in your operating system or hosting provider's secret settings; do not paste them into chat or commit them to the project.

The server accepts `TRADINGAGENTS_OPENAI_API_KEY` or the SDK's standard `OPENAI_API_KEY`. In Codex cloud environment settings, use the custom name `TRADINGAGENTS_OPENAI_API_KEY` because the standard name is reserved. The UI displays credential availability only and never receives the key.

Default model names come from the pinned upstream version. If your OpenAI account does not offer those models, enter available model IDs in the analysis settings. Provider usage is billed by OpenAI. One analysis runs at a time; the server rejects additional runs while it is busy.

Research runs analyze the selected symbol and date; they do not read or rebalance your dashboard paper holdings. You choose paper orders independently. Start with the market analyst. Additional analysts can need additional sources:

| Workflow | HTTPS destinations / configuration |
| --- | --- |
| OpenAI analysis | `api.openai.com`; OpenAI API key |
| Yahoo daily bars, news, and indicators | `query1.finance.yahoo.com`, `query2.finance.yahoo.com`, `fc.yahoo.com`, `finance.yahoo.com`, `guce.yahoo.com`, `consent.yahoo.com` |
| SEC company fundamentals | `www.sec.gov`, `data.sec.gov`; set a real contact in `SEC_EDGAR_USER_AGENT` |
| Social analyst | `api.stocktwits.com`, `www.reddit.com`; source availability may vary |
| Optional macro/prediction sources | `api.stlouisfed.org` with `FRED_API_KEY`, and `gamma-api.polymarket.com` |

Network failures are shown as errors; the app never substitutes fabricated data for an unavailable real-data request. Historical analyst reports have the limitations of their underlying sources; upstream's point-in-time checks are not a guarantee of a bias-free backtest. Paper positions currently support verified USD instruments only; other quote currencies can be charted but are rejected for orders.

## Private hosted access

This cloud onboarding workspace does not provide a public browser preview. Starting the server here validates the app but does not make it reachable from your computer. Use your own computer as above, or deploy to a hosting account. No hosting account or public deployment was provisioned by this project.

The `Dockerfile`, `compose.yaml`, and optional `render.yaml` prepare a private single-user deployment. Set a strong `DASHBOARD_PASSWORD` with at least 12 characters; the app refuses non-local startup without one. Put the app behind HTTPS, set `DASHBOARD_PUBLIC_ORIGIN` to its exact public origin (scheme and hostname, without a path), and set `DASHBOARD_SECURE_COOKIES=1` for HTTPS. Keep the `.data` or `/data` directory on a persistent volume. A generated hosting URL must be added to `DASHBOARD_PUBLIC_ORIGIN` before use. A hosting plan and disk may cost money.

For a self-managed Docker host, set `DASHBOARD_PASSWORD` securely, then run `docker compose up --build -d`. Compose exposes the app only to the host's loopback interface for a reverse proxy to forward. Its default cookie setting is for that local HTTP hop; set `DASHBOARD_SECURE_COOKIES=1` when using HTTPS in the browser. Do not expose the port directly to the Internet without HTTPS.

`render.yaml` is an optional Render Blueprint with a persistent disk. Import this project into your own repository, deploy the Blueprint in your Render account, supply the secret settings, then set the public origin to the URL Render assigns. Review the plan and disk cost before deploying. No changes to the original TradingAgents repository are required.

## Development and verification

```bash
python -m pip install -r requirements-dev.txt
cd frontend
npm ci
npm run build
cd ..
python -m pytest backend/tests -q
python tests/browser_smoke.py  # Requires Chromium; uses its own temporary server/database
python run.py --local
```

The FastAPI server serves the built frontend and the API from the same origin. During frontend development, `npm run dev` proxies API requests to the backend. Demo mode works without upstream credentials. Use one Uvicorn worker: the job gate and login sessions are process-local.

For this managed cloud environment, activation and startup instructions are saved with the environment configuration. Future tasks should use the existing isolated checkouts rather than creating Git worktrees.

See `THIRD_PARTY_NOTICES.md` and `LICENSE-TradingAgents` for upstream attribution.
