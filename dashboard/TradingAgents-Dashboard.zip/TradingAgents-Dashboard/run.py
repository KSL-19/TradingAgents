"""Launch the dashboard from a built release, locally or on a private server."""

from __future__ import annotations

import argparse
import os
from pathlib import Path
import threading
import webbrowser


def main() -> None:
    parser = argparse.ArgumentParser(description="TradingAgents research and paper-trading dashboard")
    parser.add_argument("--local", action="store_true", help="Explicitly enable password-free loopback-only access")
    parser.add_argument("--open", action="store_true", help="Open the local dashboard in your browser")
    parser.add_argument("--port", type=int, default=int(os.environ.get("PORT", "8000")))
    args = parser.parse_args()
    if not 1 <= args.port <= 65535:
        parser.error("--port must be between 1 and 65535")
    root = Path(__file__).resolve().parent
    if not (root / "frontend" / "dist" / "index.html").is_file():
        parser.error("Build the frontend first: cd frontend && npm ci && npm run build")
    if args.local:
        os.environ["DASHBOARD_LOCAL_MODE"] = "1"
        host = "127.0.0.1"
    else:
        # An explicit password is mandatory before exposing any non-loopback port.
        if not os.environ.get("DASHBOARD_PASSWORD"):
            parser.error("Set DASHBOARD_PASSWORD for private hosting, or pass --local for your computer")
        os.environ.pop("DASHBOARD_LOCAL_MODE", None)
        host = "0.0.0.0"
    os.environ.setdefault("DASHBOARD_DATA_DIR", str(root / ".data"))
    if args.open:
        if not args.local:
            parser.error("--open is only supported with --local")
        threading.Timer(1.5, lambda: webbrowser.open(f"http://127.0.0.1:{args.port}")).start()
    import uvicorn

    uvicorn.run("backend.app:app", host=host, port=args.port, log_level="info", access_log=False,
                proxy_headers=False, app_dir=str(root))


if __name__ == "__main__":
    main()
