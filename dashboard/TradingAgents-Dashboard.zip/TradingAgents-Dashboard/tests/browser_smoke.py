"""Run an isolated, offline UI test: python tests/browser_smoke.py.

Uses a temporary database and a disposable local server. Real-data failures are
stubbed at the HTTP boundary; no provider credentials or paid AI calls are used.
Requires requirements-dev.txt and Chromium (CHROMIUM_BIN or /usr/bin/chromium).
"""

import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import tempfile
import time
import urllib.request

from playwright.sync_api import expect, sync_playwright

ROOT = Path(__file__).resolve().parent.parent


def main():
    with tempfile.TemporaryDirectory(prefix="trading-dashboard-browser-") as folder:
        with socket.socket() as listener:
            listener.bind(("127.0.0.1", 0))
            port = listener.getsockname()[1]
        base = f"http://127.0.0.1:{port}"
        child_env = dict(os.environ, DASHBOARD_LOCAL_MODE="1", DASHBOARD_DATA_DIR=folder)
        for name in ("DASHBOARD_PASSWORD", "DASHBOARD_PUBLIC_ORIGIN", "OPENAI_API_KEY", "TRADINGAGENTS_OPENAI_API_KEY"):
            child_env.pop(name, None)
        with open(Path(folder) / "server.log", "w") as log:
            process = subprocess.Popen(
                [sys.executable, "-m", "uvicorn", "backend.app:app", "--host", "127.0.0.1",
                 "--port", str(port), "--no-access-log", "--no-proxy-headers"],
                cwd=ROOT, env=child_env, stdout=log, stderr=log,
            )
            try:
                for _ in range(100):
                    try:
                        with urllib.request.urlopen(base + "/api/health", timeout=1):
                            break
                    except OSError:
                        if process.poll() is not None:
                            raise RuntimeError("Test server failed to start")
                        time.sleep(0.1)
                else:
                    raise RuntimeError("Test server was not ready in time")
                exercise(base)
            finally:
                process.terminate()
                try:
                    process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait()


def exercise(base):
    output = Path(os.getenv("DASHBOARD_TEST_ARTIFACTS", str(ROOT / "browser-results")))
    output.mkdir(parents=True, exist_ok=True)
    with sync_playwright() as p:
        browser = p.chromium.launch(
            executable_path=os.getenv("CHROMIUM_BIN", "/usr/bin/chromium"), headless=True,
            args=["--no-sandbox", "--disable-dev-shm-usage"],
        )
        errors = []
        page = browser.new_page(viewport={"width": 1440, "height": 1000})
        page.on("pageerror", lambda error: errors.append(str(error)))

        def market_failure(route):
            if "mode=live" in route.request.url:
                route.fulfill(status=503, content_type="application/json", body=json.dumps({
                    "detail": "Yahoo Finance data is unavailable. No demo prices were substituted."
                }))
            else:
                route.continue_()

        page.route("**/api/market/**", market_failure)
        page.goto(base, wait_until="networkidle")
        expect(page.get_by_role("heading", name="Markets at a glance.")).to_be_visible()
        assert page.locator("canvas").count() >= 4
        page.screenshot(path=str(output / "overview.png"), full_page=True)
        page.get_by_role("button", name="1Y", exact=True).click()
        expect(page.get_by_role("button", name="1Y", exact=True)).to_have_class("selected")
        page.get_by_role("button", name="Add symbol to watchlist").click()
        page.get_by_label("Symbol", exact=True).fill("TSLA")
        page.locator(".watchlist-add").get_by_role("button").click()
        expect(page.locator(".ticket-instrument strong")).to_have_text("TSLA")
        page.locator("#trade-quantity").fill("2")
        page.get_by_role("button", name="Simulate buy order").click()
        expect(page.get_by_text("Simulated buy:", exact=False)).to_be_visible()
        portfolio = page.request.get(base + "/api/portfolio?mode=demo").json()
        assert portfolio["positions"][0]["quantity"] == 2
        assert round(portfolio["cash"] + portfolio["orders"][0]["total"], 2) == 100000
        page.get_by_role("button", name="Sell", exact=True).click()
        page.locator("#trade-quantity").fill("1")
        page.get_by_role("button", name="Simulate sell order").click()
        expect(page.get_by_text("Simulated sell:", exact=False)).to_be_visible()
        page.locator("#trade-quantity").fill("999")
        page.get_by_role("button", name="Simulate sell order").click()
        expect(page.get_by_role("alert")).to_contain_text("Insufficient shares")
        page.get_by_role("button", name="Run demo analysis").click()
        expect(page.get_by_text("Illustrative demo report.", exact=False)).to_be_visible()
        expect(page.get_by_text("Complete", exact=True)).to_be_visible(timeout=10000)
        expect(page.get_by_role("tab", name="Risk debate")).to_be_visible()
        page.get_by_role("tab", name="Technical analysis").click()
        expect(page.locator(".report-content")).to_contain_text("synthetic data, no LLM analysis")
        with page.expect_download() as info:
            page.get_by_role("link", name="Download research report").click()
        info.value.save_as(output / "demo-report.md")
        assert "DEMONSTRATION" in (output / "demo-report.md").read_text()
        page.screenshot(path=str(output / "research.png"), full_page=True)
        page.get_by_role("button", name="Paper portfolio", exact=True).click()
        expect(page.get_by_role("heading", name="Your paper portfolio")).to_be_visible()
        expect(page.locator("tbody").first).to_contain_text("TSLA")
        page.reload(wait_until="networkidle")
        portfolio = page.request.get(base + "/api/portfolio?mode=demo").json()
        assert portfolio["positions"][0]["quantity"] == 1
        assert len(portfolio["orders"]) == 2
        page.get_by_role("button", name="Market data", exact=True).click()
        expect(page.get_by_text("Yahoo Finance data is unavailable.", exact=False)).to_be_visible()
        assert page.locator("canvas").count() == 0
        assert page.request.get(base + "/api/portfolio?mode=live").json()["cash"] == 100000
        expect(page.get_by_role("button", name="Run AI analysis")).to_be_disabled()
        page.get_by_role("button", name="Demo", exact=True).click()
        expect(page.get_by_role("button", name="Simulate buy order")).to_be_enabled()
        assert not errors, errors

        mobile = browser.new_page(viewport={"width": 390, "height": 844}, is_mobile=True, has_touch=True)
        mobile.on("pageerror", lambda error: errors.append(str(error)))
        mobile.goto(base, wait_until="networkidle")
        assert mobile.evaluate("document.documentElement.scrollWidth <= window.innerWidth+1")
        mobile.get_by_role("button", name="Open navigation").click()
        mobile.get_by_role("button", name="Paper portfolio", exact=True).click()
        expect(mobile.get_by_role("heading", name="Your paper portfolio")).to_be_visible()
        expect(mobile.locator(".sidebar")).not_to_be_in_viewport()
        mobile.screenshot(path=str(output / "mobile-portfolio.png"), full_page=True)
        assert not errors, errors
        browser.close()
    print("Browser checks passed: charts, watchlist, paper orders, error handling, reports/downloads, persistence, mode isolation, mobile layout; no JavaScript errors.")


if __name__ == "__main__":
    main()
