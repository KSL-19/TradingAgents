This dashboard wraps TradingAgents by Tauric Research, licensed under Apache License 2.0.

Upstream: https://github.com/TauricResearch/TradingAgents

Tested revision: c4544913a14ed3df5f1ed7b9e8483270ce20682a (package version 0.7.1).

The dashboard does not modify upstream source. The included pure-Python wheel was built
from the clean source tree at that revision. Its SHA-256 and provenance are recorded in
vendor/UPSTREAM.json. The original Apache 2.0 license is included in the wheel and in
LICENSE-TradingAgents.

Other open-source dependencies and their licenses are declared in the Python and frontend
package metadata. See frontend/THIRD_PARTY_LICENSES.txt for frontend dependency licenses.
