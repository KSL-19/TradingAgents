"""One-command local setup and browser launch. Never accepts or stores API keys."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys


def main() -> None:
    parser = argparse.ArgumentParser(description="Install and open your local TradingAgents dashboard")
    parser.add_argument("--no-browser", action="store_true")
    parser.add_argument("--port", type=int, default=8000)
    args = parser.parse_args()
    if sys.version_info < (3, 11):
        parser.error("Install Python 3.12 (or later) from python.org, then launch again")
    root = Path(__file__).resolve().parent
    os.chdir(root)
    if not (root / "frontend/dist/index.html").is_file():
        parser.error("The frontend is missing. Use the built release package, or run npm ci and npm run build in frontend")
    provenance = json.loads((root / "vendor/UPSTREAM.json").read_text())
    wheel = root / "vendor" / provenance["wheel"]
    if hashlib.sha256(wheel.read_bytes()).hexdigest() != provenance["sha256"]:
        parser.error("The bundled upstream wheel failed its integrity check. Extract a fresh copy of the package")
    venv_dir = root / ".venv"
    interpreter = venv_dir / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
    if not interpreter.is_file():
        print("Creating a Python environment for your dashboard…", flush=True)
        subprocess.run([sys.executable, "-m", "venv", str(venv_dir)], check=True)
    signature = hashlib.sha256(
        (root / "requirements.txt").read_bytes() + (root / "constraints.txt").read_bytes()
    ).hexdigest()
    marker = venv_dir / ".dashboard-installed"
    if not marker.is_file() or marker.read_text().strip() != signature:
        print("Installing verified dashboard dependencies. First launch needs Internet access…", flush=True)
        if subprocess.run([str(interpreter), "-m", "pip", "--version"], stdout=subprocess.DEVNULL,
                          stderr=subprocess.DEVNULL).returncode:
            subprocess.run([str(interpreter), "-m", "ensurepip", "--upgrade"], check=True)
        subprocess.run([str(interpreter), "-m", "pip", "install", "--disable-pip-version-check",
                        "-r", "requirements.txt"], check=True)
        marker.write_text(signature + "\n")
    command = [str(interpreter), str(root / "run.py"), "--local", "--port", str(args.port)]
    if not args.no_browser:
        command.append("--open")
    print("Opening your private local dashboard. Keep this window open; Ctrl+C stops it.", flush=True)
    try:
        subprocess.run(command, check=True)
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    try:
        main()
    except subprocess.CalledProcessError as exc:
        print("Setup or startup failed. Read the error above, then try again after correcting it.", file=sys.stderr)
        raise SystemExit(exc.returncode) from None
