@echo off
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 goto use_python
py -3.12 -c "import sys" >nul 2>nul
if not errorlevel 1 goto launch_py
echo Python 3.12 is needed. Asking the Python install manager to install it...
py install 3.12
if errorlevel 1 goto missing_python
:launch_py
py -3.12 launch.py
if errorlevel 1 goto stopped
exit /b 0
:use_python
python -c "import sys; raise SystemExit(0 if sys.version_info[:2] == (3,12) else 1)" >nul 2>nul
if errorlevel 1 goto missing_python
python launch.py
if errorlevel 1 goto stopped
exit /b 0
:missing_python
echo Install Python 3.12 from python.org, then open this file again.
echo With the Python install manager, the command is: py install 3.12
:stopped
echo The dashboard stopped. Keep the error text above for troubleshooting.
pause
