@echo off
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel% equ 0 (
    py -3.12 launch.py
) else (
    python launch.py
)
if %errorlevel% neq 0 pause
