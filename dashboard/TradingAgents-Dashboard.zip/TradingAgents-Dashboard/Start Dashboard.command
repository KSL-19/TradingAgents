#!/bin/bash
cd "$(dirname "$0")" || exit 1
python3 launch.py
result=$?
if [ "$result" -ne 0 ]; then
  read -r -p "Press Enter to close this window."
fi
exit "$result"
