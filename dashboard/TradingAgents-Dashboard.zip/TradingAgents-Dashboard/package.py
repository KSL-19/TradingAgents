"""Build a portable source + prebuilt frontend ZIP without local data or secrets."""

from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

ROOT = Path(__file__).resolve().parent
EXCLUDED = {".venv", "node_modules", ".data", ".git", ".pytest_cache", "__pycache__", "browser-results"}


def build(destination: Path) -> None:
    if not (ROOT / "frontend/dist/index.html").is_file():
        raise SystemExit("Build the frontend before packaging")
    with ZipFile(destination, "w", ZIP_DEFLATED) as archive:
        for path in sorted(ROOT.rglob("*")):
            relative = path.relative_to(ROOT)
            if any(part in EXCLUDED or part.startswith(".env") for part in relative.parts):
                continue
            if path.is_file() and path.suffix not in {".pyc", ".log", ".zip"}:
                archive.write(path, Path("TradingAgents-Dashboard") / relative)
    print(f"Created {destination.name}: {destination.stat().st_size:,} bytes")


if __name__ == "__main__":
    build(ROOT.parent / "TradingAgents-Dashboard.zip")
