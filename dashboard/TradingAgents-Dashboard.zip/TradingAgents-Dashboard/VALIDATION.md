# Validation — Dashboard 1.2

Tested on Linux with Python 3.12.14 and Chromium.

- **165 backend tests passed.** They cover authentication, persistence, paper accounting, quote provenance, local key privacy/storage boundaries, account-derived model selection, modality filtering, expired-list recovery, sanitized error classification, execution probe and job lifecycle, source coverage, and tool callbacks.
- **Integrated browser smoke passed:** real-data default, no synthetic fallback, local setup, explicit demo flow, chart/watchlist interactions, paper orders, report downloads, persistence, isolation and mobile layout.
- **Model UI contract passed:** account-only Sol/Astra choices, no invented defaults or embedding options, recommendations, explicit billed probe, free readiness check, actionable failed-run quota diagnostics, secret-free diagnostics/manual retry, expired-list recovery, key privacy, unavailable-family messages and mobile layout. No JavaScript errors were observed. Remote responses in these checks are fixtures.
- **Real installed adapter wire checks passed:** the actual TradingAgents/LangChain/OpenAI adapter serialized a Sol tool-call request and an Astra structured-output request to the native Responses API route, used capped output-token parameters, and parsed fixture responses through a local HTTP mock. This verifies adapter mechanics, not actual API model availability, generation permissions, billing or response quality.
- **Actual upstream graph offline check passed** with a fixture model and the dashboard's configuration. The original base URL setting was valid; no intrinsic graph failure was reproduced.
- **Production frontend build passed**, app version 1.2.0, Vite 7.3.7. No runtime dependency changes were needed.
- **Fresh version 1.2 ZIP install/start passed** from a path containing spaces: new virtual environment, pinned dependencies, correct app version, real-data default, empty key setup and no fabricated model defaults. Startup took about 23 seconds in this environment.
- The bundled upstream 0.7.1 wheel remains unchanged; its 95 source/asset files matched the pristine official revision recorded in vendor/UPSTREAM.json.

Version 1.2 increases the per-call output cap to 8192 tokens and applies a 120-second SDK timeout and a 15-minute overall analysis limit. Optional model probes use at most two bounded requests and do not run automatically. Higher model budgets can increase API usage.

**Remaining real-service verification:** the user's API key is stored on their own Windows computer and was not shared here. This cloud instance has no API key or applicable Yahoo/OpenAI outbound access. No actual paid model call or current market price was verified here. The exact original account-side failure remains unknown because the previous version discarded its underlying exception. API billing, quota, permissions, compatibility and network failures are now distinguished when safe provider metadata supports a classification.

Windows DPAPI was tested via mocked boundaries and source review, not actual Windows APIs on this Linux machine. The user previously confirmed that Windows installation, real charts and key setup worked. No broker execution or guaranteed error-free future provider service is claimed.

Run checks with `python -m pytest backend/tests -q`, `python tests/browser_smoke.py`, and `python frontend/tests/real_data_browser.py` after installing development requirements and Chromium. Browser checks use temporary state and explicit remote fixtures; they do not submit paid requests.
