# Validation

Tested in the managed Linux environment with Python 3.12.14 and Chromium.

- **26 backend tests passed**: authentication/CSRF, cookie settings, API validation, mode isolation, durable state, async jobs and exports, server-priced orders, fractional quantities, cost basis, insufficient cash/shares, currency rejection, and atomic concurrent transactions.
- **Browser smoke passed**: interactive charts and range controls, watchlist changes, paper buy/sell and oversell errors, demo research, report tabs/downloads, page reload persistence, explicit unavailable-data behavior, mode isolation, and mobile navigation/layout. No JavaScript errors were observed. These tests use synthetic data and a stubbed real-data error; they do not validate a real provider response.
- **Fresh ZIP launch passed**: extracted into a path containing spaces; the launcher verified the upstream wheel, created a fresh virtual environment, installed runtime dependencies, started the server, and served the frontend and demo API. First startup took about 30 seconds in this environment; download time varies.
- **Production frontend build passed** with patched Vite 7.3.7. Full npm audit, including development dependencies, reported zero known vulnerabilities at validation time.
- **Docker build and functional smoke passed**: non-root process, private login, CSRF rejection, paper-account accounting, report jobs/downloads, and state persistence across restart. The installed upstream graph imported successfully.
- The bundled wheel's **95 source/asset files match the pristine tracked upstream tree** at the revision in `vendor/UPSTREAM.json`. Its SHA-256 is verified by the local launcher.

Actual OpenAI model calls and real Yahoo data were not validated because no OpenAI credential or applicable network access was available in the running cloud instance. The adapter uses the real upstream graph; its boundary tests mock remote execution. Demo reports are explicitly illustrative, not model output.

Windows and macOS launchers are included but were not executed in this Linux environment. The app requires Python and Internet access for initial dependency installation. No broker connection or real-money order execution is included.

Reproduce backend checks with `python -m pytest backend/tests -q`. Reproduce browser checks with `python tests/browser_smoke.py` after installing the development requirements and Chromium. The browser script creates its own temporary database and server and does not alter a user's account.
