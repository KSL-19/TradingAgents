# Validation — Dashboard 1.1

Tested on Linux with Python 3.12.14 and Chromium.

- **88 backend tests passed**: original API/auth/ledger coverage plus 15 quote-provenance tests, 25 local-connection tests, and 22 source-coverage tests. Quote/provider responses are fixtures, not live market verification.
- Quote tests distinguish the completed daily close from a newer regular-session quote, preserve provider timestamps and exchange timezone, handle missing timestamps and old quotes, avoid false weekend warnings, validate OHLC/symbol consistency, and keep one consistent snapshot across chart ranges.
- Connection tests prove secret input is not returned or placed in jobs, protect local file permissions, preserve environment bindings, classify authentication/rate/network errors, expire model-list verification, prevent stale credential verification, preflight market access before model execution, and require a real SEC contact. Windows DPAPI branches were tested using mocked protection helpers; actual Windows APIs were not executed on this Linux machine.
- Source-coverage tests summarize observed tool availability without persisting raw bodies, URLs or secrets. They distinguish no data, empty results, and selected analysts with no observed tools. They do not verify financial facts or cover upstream sentiment prefetches outside tool history.
- **Integrated browser smoke passed**: real-data default ignores legacy demo preference; real provider failures show no synthetic quote; local setup screen, explicit demo charts, watchlists, paper orders, reports/downloads, persistence, account isolation and mobile navigation/layout passed without JavaScript errors.
- **Frontend contract checks passed** with fixture provider responses: distinct close/quote timestamps, refresh, connection setup, key field clearing/no browser storage, verified model-ID gating, source-gap banners, desktop and mobile layout. Screenshots of fixtures are not evidence of actual current prices.
- **Production frontend build passed**, version 1.1.0, Vite 7.3.7.
- The bundled upstream wheel remains unchanged and matched 95 tracked source/asset files at the official commit in vendor/UPSTREAM.json.

A fresh version 1.1 ZIP installation passed from a directory containing spaces: the launcher created a new environment, installed the pinned runtime dependencies, started the server, and returned version 1.1.0 with real data as the default and AI access unverified until setup. Explicit demo requests remained separate. Installation and startup took about 23 seconds in this environment. The previous version's Docker package also passed functional checks; Docker was not rebuilt for this update. This version's Windows runtime-helper changes and real DPAPI behavior still require actual Windows execution.

**Outstanding real-service validation:** no OpenAI key is configured in this cloud instance and its current outbound policy blocks the applicable Yahoo/OpenAI destinations. Therefore no actual model generation or current NVIDIA price was verified here. The user's reported $217.89 close was not hardcoded. After local setup, verify Yahoo source/session date against the broker, run the real model-list connection check, and run an actual analyst report before relying on the workflow.

No broker connection or real-money order execution is included. Research reports are snapshots and may have incomplete source coverage; the app has no trial expiry, but provider availability and API credits still apply.

Reproduce with `python -m pytest backend/tests -q`, `python tests/browser_smoke.py`, and `python frontend/tests/real_data_browser.py` after installing development requirements and Chromium. Browser checks create temporary state or use explicit HTTP fixtures; they do not submit paid model requests.
