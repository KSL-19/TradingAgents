# Real research on Windows

This version opens in **Real market data** mode. It is a research application with no trial expiry. It does not submit orders to a broker.

## Update your existing copy

1. Stop the old dashboard by closing its black command window.
2. Download the latest `TradingAgents-Dashboard.zip` from the GitHub download branch and extract it into a **new folder**.
3. Double-click `Start Dashboard.bat` inside the new extracted folder.
4. Keep the command window open. The browser opens after dependencies are ready.

Your old folder contains your old reports and practice account. To preserve those, with both app versions stopped, copy the old folder's `.data` directory into the new folder. Do not copy the old `.venv`, `frontend`, or `backend` directories over the new version. A new folder otherwise starts a separate account. Local saved keys protected by Windows can only be decrypted by the Windows account that saved them.

## Check prices first

1. Confirm the header says **Real market data**, not Demo.
2. Select a ticker such as `NVDA` and click **Refresh prices**.
3. Read **Last completed daily close**, its **session date**, and the **Yahoo Finance** source. A newer regular-session quote is shown separately with its provider timestamp.
4. Compare the same ticker, currency and completed session with your broker. An uncompleted bar, a previous session, after-hours data, adjustments, or provider delays can produce different values. If dates or source coverage are unavailable, the app marks that limitation rather than inventing a current price.

Yahoo data is not guaranteed real-time exchange data. The displayed close is a provider daily-bar close, not a certified exchange closing-auction price. Prices should be checked at your broker before you place your manual order.

## Connect the real AI team

1. Open [OpenAI API keys](https://platform.openai.com/api-keys) in your browser and sign in.
2. Complete the platform's project and API billing setup if prompted. A ChatGPT subscription does **not** include OpenAI API usage.
3. Create a secret API key. Do not send it in chat, screenshots, email, or a public repository.
4. In the dashboard, open **Connections & settings**. Paste the key into the local provider form and save/test it.
5. Choose model IDs from the models actually available to your key. The connection test verifies the model-list endpoint; it does not generate an analysis or guarantee quota for every later model call.
6. For SEC fundamentals, enter your real name/contact email in the SEC contact field. Do not use example contact details.
7. Return to **AI research**, select the ticker and analysis date, choose your analysts, and run the analysis. Start with the technical/market analyst.

Actual analysis consumes API credits. Review your OpenAI usage regularly. Provider errors or unavailable sources are surfaced in the app; a completed AI report does not prove every selected source returned useful data. Check the source-coverage notes and underlying reports.

The key is saved locally on Windows with Windows Data Protection API encryption, not inside the ZIP or GitHub repository. The app never returns the saved key to the browser after entry. If an environment-provided key exists, that key takes priority and cannot be deleted by the dashboard.

## Day-to-day use

Launch the same extracted folder each day to retain settings and reports. Real prices refresh while the tab is visible, and manual refresh requests fresh provider data. Market-close/session dates come from provider data, not just today's computer date. Research reports remain snapshots; rerun when you need a fresh analysis.

Place actual trades yourself in your broker account. The dashboard's optional paper account uses virtual money and is separate from your broker balance. No position, return, or order in that paper account represents a real broker transaction.
